#!/bin/bash
# ============================================================
# install.sh - install NiCad++ into a NiCad 6.2 folder
#
#   1. unzip this package INTO your NiCad folder (the one with tools/ scripts/ config/)
#   2. cd to the NiCad folder and run:   bash NiCadPP/install.sh
#
# It copies scripts/, tools/ and config/type3.cfg into NiCad, removes Windows line
# endings, makes the scripts executable, compiles the two clone-pair programs and
# checks txl, gcc, python and git.
# ============================================================
set -u
pkg="$(cd "$(dirname "$0")" && pwd)"
root="$(pwd)"
say()  { echo "  $*"; }
warn() { echo "  [!] $*"; }

# ---- NiCad folder? ---------------------------------------------------------------
if [ ! -d "$root/tools" ] || [ ! -d "$root/scripts" ] || [ ! -f "$root/scripts/Extract" ]; then
    echo "*** Error: run this from your NiCad 6.2 folder (the one with tools/, scripts/, config/):"
    echo "      cd /cygdrive/d/NiCad-6.2 && bash NiCadPP/install.sh"
    exit 1
fi
echo "NiCad folder: $root"
[ -x "$root/tools/clonepairs.x" ]   || warn "tools/clonepairs.x not found - build NiCad first (make)"
[ -x "$root/tools/cloneclasses.x" ] || warn "tools/cloneclasses.x not found - build NiCad first (make)"

# ---- copy ------------------------------------------------------------------------
NOEXEC=""
install_file() {        # install_file SRC DEST [exec]
    [ "$1" -ef "$2" ] || cp "$1" "$2"
    sed -i 's/\r$//' "$2"
    if [ "${3:-}" = "exec" ]; then
        chmod +x "$2" 2> /dev/null
        [ -x "$2" ] || NOEXEC="$NOEXEC ${2#$root/}"
    fi
    say "${2#$root/}"
}
echo "Installing"
for f in NiCadInc NiCadCompare FindClonePairs2 git_downloader; do
    install_file "$pkg/scripts/$f" "$root/scripts/$f" exec
done
for f in nicadinc.py git_downloader.py compare_blocks.py; do
    install_file "$pkg/scripts/$f" "$root/scripts/$f"
done
for f in clonepairs_rev.c clonepairs2.c clonepairs2.diff; do
    install_file "$pkg/tools/$f" "$root/tools/$f"
done
mkdir -p "$root/config" "$root/systems"
if [ -f "$root/config/type3.cfg" ]; then
    say "config/type3.cfg exists - kept (the package version is in NiCadPP/config/)"
else
    install_file "$pkg/config/type3.cfg" "$root/config/type3.cfg"
fi
for f in Extract Transform Rename Filter Abstract Normalize FindClonePairs ClusterPairs GetSource MakePairHTML; do
    [ -f "$root/scripts/$f" ] && { sed -i 's/\r$//' "$root/scripts/$f"; chmod +x "$root/scripts/$f" 2> /dev/null; }
done

# ---- compile ---------------------------------------------------------------------
echo "Compiling"
if ! command -v gcc > /dev/null 2>&1; then
    warn "gcc not found (Cygwin: install gcc-core) - NiCadInc will compile the tools when gcc is there"
else
    # clonepairs_rev.x: plain C
    if gcc -O2 -o "$root/tools/clonepairs_rev.x" "$root/tools/clonepairs_rev.c" -lm; then
        [ -f "$root/tools/clonepairs_rev.x.exe" ] && mv -f "$root/tools/clonepairs_rev.x.exe" "$root/tools/clonepairs_rev.x"
        say "tools/clonepairs_rev.x"
    else
        warn "tools/clonepairs_rev.c did not compile"
    fi
    # clonepairs2.x: Turing+-generated C, needs NiCad's runtime (main.c TLI.c TLS.c UNIX64/) from tools/
    t="$root/tools"
    if [ -f "$t/main.c" ] && [ -f "$t/TLI.c" ] && [ -f "$t/TLS.c" ] && [ -d "$t/UNIX64" ]; then
        b="$(mktemp -d)"
        cp -r "$t/main.c" "$t/TLI.c" "$t/TLS.c" "$t"/TL*.h "$t"/UNIX* "$t/clonepairs2.c" "$b/" 2> /dev/null
        [ -f "$b/UNIX64/cinterface" ]   || cp "$b/UNIX64/cinterface.h" "$b/UNIX64/cinterface" 2> /dev/null
        [ -f "$b/UNIX64/cinterface.h" ] || cp "$b/UNIX64/cinterface" "$b/UNIX64/cinterface.h" 2> /dev/null
        extra=""; [ "${OS:-}" = "Windows_NT" ] && extra="-Wl,--stack,0x20000000"
        if ( cd "$b" && gcc -w -ansi -fPIC -O -I . $extra -o clonepairs2.x main.c TLI.c TLS.c clonepairs2.c ); then
            if [ -f "$b/clonepairs2.x" ]; then cp "$b/clonepairs2.x" "$t/clonepairs2.x"; else cp "$b/clonepairs2.x.exe" "$t/clonepairs2.x"; fi
            say "tools/clonepairs2.x"
        else
            warn "tools/clonepairs2.c did not compile (needed for ENGINE=clonepairs2 / NiCadCompare)"
        fi
        rm -rf "$b"
    else
        warn "tools/main.c, TLI.c, TLS.c or UNIX64/ missing: clonepairs2.x not built."
        warn "  They come with the NiCad 6.2 sources (tools/). Copy them into tools/ and run again."
    fi
fi

# ---- checks ----------------------------------------------------------------------
echo "Checks"
if command -v txl > /dev/null 2>&1; then say "$(txl -V 2>&1 | head -1)"; else warn "txl not found in PATH"; fi
py=""
for c in python3 python; do
    command -v "$c" > /dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 6) else 1)' 2> /dev/null && { py="$c"; break; }
done
if [ -n "$py" ]; then say "python: $($py --version 2>&1)"; else warn "Python 3.6+ not found"; fi
if command -v git > /dev/null 2>&1; then say "$(git --version)"; else warn "git not found (needed by git_downloader)"; fi
case "$root" in *" "*) warn "the NiCad path has a space: run everything with relative paths (./scripts/..., systems/...)";; esac
if [ -n "$NOEXEC" ]; then
    warn "these could not be made executable on this drive:$NOEXEC"
    warn "  run them with bash, e.g.  bash scripts/NiCadCompare ..."
fi

echo ""
echo "Done. Next steps (from $root):"
echo "  ./scripts/git_downloader https://github.com/wumpz/jhotdraw.git jhotdraw 2 200 --lang java"
echo "  bash scripts/NiCadCompare functions java systems/jhotdraw type3 2 200"
echo "See NiCadPP/README.md"
