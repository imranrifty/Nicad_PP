/*
 * clonepairs2.c - NiCad clonepairs.c (Turing+ generated C) modified for INCREMENTAL detection
 *
 *   clonepairs2.x previous_blocks.xml new_blocks.xml [ previous_clones.xml ] [ threshold ] [ minclonesize ]
 *                 [ maxclonesize ] [ showsource ] [ nonewnew ]  > clone-pairs.xml
 *
 *   previous_clones.xml  (optional) the clone pairs of the previous revision (its ...-clones-<thr>.xml),
 *                        with the paths already renamed r<N-1>/ -> r<N>/ like previous_blocks.xml.
 *                        Given: the result is the COMPLETE clone-pair file of the revision =
 *                          previous pairs whose two blocks are still in previous_blocks.xml
 *                          (pairs of deleted / modified files are dropped)
 *                          + the new pairs found here, sorted by size (nlines), largest first.
 *                        Not given: only the new pairs.
 *
 *   previous_blocks.xml  pcs[],    npcs  : blocks kept from the previous revision (unchanged files)
 *   new_blocks.xml       newpcs[], mpcs  : blocks of the added / modified files of this revision
 *
 * findclones compares
 *     every new block with every previous block    (mpcs x npcs, never previous x previous)
 *     every new block with the other new blocks     (mpcs x (mpcs-1) / 2, needed: two new files
 *                                                    can contain the same new code)
 * with the unchanged clone() / exact() / nearmiss() / lcs() and threshold logic.
 *
 * Changes to the generated code (search for "NICAD-INC"):
 *   - second array newpcs[] / mpcs, readpcs() reads into either array
 *   - struct CP pc1 / pc2 are block references:  k > 0 -> pcs[k-1],  k < 0 -> newpcs[-k-1]  (PCREF)
 *   - findclones(): __x266 = mpcs; i = 1 ... __x267 = npcs; j = 1   (+ the new x new loop)
 *     clone() is called with the larger block first, exactly as the size-sorted all-pairs loop
 *     of clonepairs.x does; pairs outside its size window are skipped and not counted
 *   - pruneembeddedpairs() and showpairs() use PCREF
 *   - pcid of a previous block = its position in previous_blocks.xml,
 *     pcid of a new block      = npcs + its position in new_blocks.xml
 *     (= position in the file previous_blocks.xml + new_blocks.xml)
 *   - option "nonewnew" (last argument) skips the new x new comparisons
 *   - <runinfo> also has ncompares_full (the comparisons of clonepairs.x on all blocks, counted
 *     with the same size window), npcs_previous / npcs_new, npairs_previous / kept / dropped / new
 *   - options "from=systems/x/r5/ to=systems/x/r6/": paths of previous_clones.xml are read with the
 *     prefix replaced (the previous revision's pair file is used as it is, no relabeled copy)
 *   - readpreviouspairs(): takes over the previous revision's pairs; sortallpairs(): re-sorts
 *   - linetable(): no loop setting the 12,000,000 line-table entries to 0 (the static array is
 *     0 already): that loop cost ~25 ms (Linux) on every run - more than a small incremental run
 *
 * Build like the other NiCad tools (in NiCad's tools/ folder, next to TLI.c, TLS.c, UNIX64/):
 *   gcc -w -ansi -fPIC -O -I . -o clonepairs2.x clonepairs2.c TLI.c TLS.c -lm
 *   (use the same command/flags as NiCad's tools/Makefile uses for clonepairs.x)
 */
#include <UNIX64/cinterface>
extern TLint4	TL_TLI_TLIARC;

extern void TL_TLI_TLIFA ();

extern void TL_TLX_TLXGE ();

extern void TL_TLX_TLXDT ();

extern void TL_TLX_TLXTM ();

extern void TL_TLX_TLXCL ();

extern void TL_TLX_TLXSC ();

extern void time ();

extern void TL_TLX_TLXSYS ();

extern TLint4 getpid ();

extern void TL_TLI_TLIFS ();

extern void TL_TLK_TLKUEXIT ();
extern TLnat4	TL_TLK_TLKTIME;
extern TLnat4	TL_TLK_TLKEPOCH;

extern void TL_TLK_TLKUDMPA ();

extern void TL_TLK_TLKCINI ();
extern TLboolean	TL_TLK_TLKCLKON;
extern TLnat4	TL_TLK_TLKHZ;
extern TLnat4	TL_TLK_TLKCRESO;
extern TLnat4	TL_TLK_TLKTIME;
extern TLnat4	TL_TLK_TLKEPOCH;

extern void TL_TLK_TLKPSID ();

extern TLnat4 TL_TLK_TLKPGID ();

extern void TL_TLK_TLKRSETP ();
static TLstring	pcfile;
static TLstring	newpcfile;	/* NICAD-INC: new_blocks.xml */
static TLstring	prevpairsfile;	/* NICAD-INC: previous_clones.xml ("" = none) */
static TLint4	nprevpairs, nkeptpairs, ndroppedpairs, nnewpairs;	/* NICAD-INC: statistics */
static TLboolean	nonewnew;	/* NICAD-INC: skip new x new */
static char	relabelfrom[4096], relabelto[4096];	/* NICAD-INC: from=<prefix> to=<prefix>: paths of previous_clones.xml r<N-1>/ -> r<N>/ */
static TLreal8	threshold;
static TLint4	minclonelines;
static TLint4	maxclonelines;
static TLboolean	showsource;

static void useerr () {
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Usage :  clonepairs2.x previous_blocks.xml new_blocks.xml [ previous_clones.xml ] [ threshold ] [ minclonesize ] [ maxclonesize ] [ showsource ] [ nonewnew ] [ from=<old path prefix> to=<new path prefix> ] > clone-pairs.xml", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "  e.g.:  clonepairs2.x r2_old.xml r2_new.xml r1-clones-0.30-as-r2.xml 0.3 10 2500 > r2-clones-0.30.xml", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "    threshold = difference threshold, 0.0 .. 0.9 (optional, default 0.0 (exact))", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "    minclonesize = minimum clone size (optional, default 5 lines)", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "    maxclonesize = maximum clone size (optional, default 2500 lines, max 20000 lines)", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "    showsource = embed pc source in results (optional, argument present = yes, default no)", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
}

static void getprogramarguments ();
typedef	TLchar	linetable___x224[600000001];
static linetable___x224	linetable_lineText;
static TLint4	linetable_lineTextSize;
typedef	TLint4	linetable___x227[12000000];
static linetable___x227	linetable_lineTable;
static TLint4	linetable_lineTableSize;
typedef	TLnat4	linetable_LN;

static TLnat4 linetable_hash (s)
TLstring	s;
{
   typedef	TLnat1	__x231[256];
   typedef	__x231	nat256;
   register TLnat4	h;
   register TLnat4	j;
   h = TL_TLS_TLSLEN(s);
   if (h > 255) {
	h = 255;
   };
   j = h - 1;
   if (h > 0) {
	{
	    register TLint4	i;
	    TLint4	__x233;
	    __x233 = h >> 1;
	    i = 0;
	    if (i <= __x233) {
		for(;;) {
		    h += ((TLint4) h << 1) + ((* (nat256 *) s)[i]);
		    h += ((TLint4) h << 1) + ((* (nat256 *) s)[j]);
		    j -= 1;
		    if (i == __x233) break;
		    i++;
		}
	    };
	};
   };
   return (h);
   /* NOTREACHED */
}
static TLint4	linetable_secondaryHash;
typedef	TLint4	linetable___x238[10];
static linetable___x238	linetable_primes = 
   {1021, 2027, 4091, 8191, 16381, 32003, 65003, 131009, 262007, 524047};
typedef	TLboolean	linetable___x242[256];
static linetable___x242	linetable_spaceP;

static void linetable_strip (rawline, __x82)
TLstring	rawline;
TLstring	__x82;
{
   TLstring	line;
   TLint4	rawlinelength;
   TLint4	first;
   TLint4	last;
   TLSTRASS(4095, line, rawline);
   rawlinelength = TL_TLS_TLSLEN(rawline);
   first = 1;
   for(;;) {
	{
	    TLchar	__x246[2];
	    if ((first > rawlinelength) || ((TL_TLS_TLSBX(__x246, (TLint4) first, line), !(linetable_spaceP[((TLnat4) TLCVTTOCHR(__x246))])))) {
		break;
	    };
	};
	first += 1;
   };
   last = rawlinelength;
   for(;;) {
	{
	    TLchar	__x247[2];
	    if ((last < first) || ((TL_TLS_TLSBX(__x247, (TLint4) last, line), !(linetable_spaceP[((TLnat4) TLCVTTOCHR(__x247))])))) {
		break;
	    };
	};
	last -= 1;
   };
   {
	TLstring	__x248;
	TL_TLS_TLSBXX(__x248, (TLint4) last, (TLint4) first, line);
	TLSTRASS(4095, line, __x248);
   };
   {
	TLSTRASS(4095, __x82, line);
	return;
   };
   /* NOTREACHED */
}

static linetable_LN linetable_install (line)
TLstring	line;
{
   TLnat4	lineIndex;
   TLnat4	startIndex;
   TLint4	linelength;
   lineIndex = linetable_hash(line);
   if (lineIndex >= 12000000) {
	lineIndex = lineIndex % 12000000;
   };
   startIndex = lineIndex;
   linelength = TL_TLS_TLSLEN(line);
   for(;;) {
	if ((linetable_lineTable[lineIndex]) == 0) {
	    if (((linetable_lineTextSize + linelength) + 1) > 600000000) {
		TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		TL_TLI_TLIPS ((TLint4) 0, "*** Error: too much total unique line text ( > ", (TLint2) 0);
		TL_TLI_TLIPI ((TLint4) 0, (TLint4) 600000000, (TLint2) 0);
		TL_TLI_TLIPS ((TLint4) 0, " chars)", (TLint2) 0);
		TL_TLI_TLIPK ((TLint2) 0);
		TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
	    };
	    TLSTRASS(4095, (* (TLstring *) &linetable_lineText[linetable_lineTextSize - 1]), line);
	    linetable_lineTable[lineIndex] = linetable_lineTextSize;
	    linetable_lineTextSize += linelength + 1;
	    linetable_lineTableSize += 1;
	    break;
	};
	if (strcmp((* (TLstring *) &linetable_lineText[(linetable_lineTable[lineIndex]) - 1]), line) == 0) {
	    break;
	};
	lineIndex += linetable_secondaryHash;
	if (lineIndex >= 12000000) {
	    lineIndex = lineIndex % 12000000;
	};
	if (lineIndex == startIndex) {
	    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	    TL_TLI_TLIPS ((TLint4) 0, "*** Error: too many unique lines ( > ", (TLint2) 0);
	    TL_TLI_TLIPI ((TLint4) 0, (TLint4) 12000000, (TLint2) 0);
	    TL_TLI_TLIPS ((TLint4) 0, ")", (TLint2) 0);
	    TL_TLI_TLIPK ((TLint2) 0);
	    TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
	};
   };
   return (lineIndex);
   /* NOTREACHED */
}

static void linetable_gettext (lineIndex, __x93)
linetable_LN	lineIndex;
TLstring	__x93;
{
   {
	TLSTRASS(4095, __x93, (* (TLstring *) &linetable_lineText[(linetable_lineTable[lineIndex]) - 1]));
	return;
   };
   /* NOTREACHED */
}

static void linetable_printstats () {
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Used ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) linetable_lineTextSize, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, "/", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) 600000000, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " unique line text chars", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " and ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) linetable_lineTableSize, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, "/", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) 12000000, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " unique lines", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
}

static void linetable () {
   linetable_lineTextSize = 1;
   linetable_lineTableSize = 0;
   /* NICAD-INC: the loop that set all 12,000,000 entries of lineTable to 0 is left out:
      lineTable is a static array, which C initializes to 0 already; the loop only touched
      48 MB of memory on every run (a fixed cost that is larger than a small incremental run) */
   TLSTRASS(4095, (* (TLstring *) &linetable_lineText[0]), " ");
   linetable_lineTextSize += 2;
   linetable_lineTable[0] = 2;
   linetable_lineTableSize = 1;
   linetable_secondaryHash = 11;
   {
	register TLint4	i;
	for (i = 1; i <= 10; i++) {
	    if ((i == 10) || ((linetable_primes[i - 1]) > 12000000)) {
		break;
	    };
	    linetable_secondaryHash = linetable_primes[i - 1];
	};
   };
   {
	register TLint4	c;
	for (c = 0; c <= 255; c++) {
	    linetable_spaceP[c] = 0;
	};
   };
   linetable_spaceP[32] = 1;
   linetable_spaceP[9] = 1;
   linetable_spaceP[12] = 1;
}
struct	PC {
   TLint4	num;
   linetable_LN	info;
   linetable_LN	srcfile;
   TLint4	srcstartline, srcendline;
   TLint4	firstline;
   TLint4	nlines;
   TLint4	nomlines;
   TLint4	embedding;
};
typedef	struct PC	__x253[6000000];
static __x253	pcs;		/* previous blocks */
static TLint4	npcs;
/* NICAD-INC: new / modified blocks */
#define MAXNEWPCS 2000000
typedef	struct PC	__x253new[MAXNEWPCS];
static __x253new	newpcs;
static TLint4	mpcs;
/* NICAD-INC: a block reference, k > 0: pcs[k-1] (previous), k < 0: newpcs[-k-1] (new) */
#define PCREF(k) ((k) > 0 ? &pcs[(k) - 1] : &newpcs[-(k) - 1])
typedef	linetable_LN	__x254[100000000];
static __x254	lines;
static TLint4	nlines;
struct	CP {
   TLint4	pc1, pc2;	/* NICAD-INC: block references, see PCREF */
   TLint4	nlines;
   TLint1	similarity;
};
typedef	struct CP	__x255[20000000];
static __x255	clonepairs;
static TLint4	npairs;
static TLint4	ncompares;
static TLint4	nclones;
static TLint4	nfragments;

static void readpcs (fname, pcarray, pccount, maxpcs)
TLstring	fname;
struct PC	*pcarray;	/* NICAD-INC: pcs or newpcs */
TLint4	*pccount;	/* NICAD-INC: npcs or mpcs */
TLint4	maxpcs;
{
   TLint4	pcf;
   TL_TLI_TLIOF ((TLnat2) 2, fname, &pcf);
   if (pcf == 0) {
	useerr();
   };
   {
	register TLint4	i;
	for (i = 1; i <= maxpcs; i++) {
	    TLBIND((*pc), struct PC);
	    TLstring	sourceheader;
	    TLint4	sfindex;
	    TLint4	sfend;
	    TLint4	slindex;
	    TLint4	slend;
	    TLint4	elindex;
	    TLint4	elend;
	    TLint4	nomlines;
	    if ((i % 1000) == 1) {
		TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
	    };
	    if (TL_TLI_TLIEOF((TLint4) pcf)) {
		break;
	    };
	    (*pccount) += 1;
	    pc = &(pcarray[(*pccount) - 1]);
	    (*pc).num = i;
	    (*pc).embedding = 0;
	    TL_TLI_TLISS ((TLint4) pcf, (TLint2) 1);
	    TL_TLI_TLIGSS((TLint4) 4095, sourceheader, (TLint2) pcf);
	    (*pc).info = linetable_install(sourceheader);
	    if (TL_TLS_TLSIND(sourceheader, "<source ") != 1) {
		TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		TL_TLI_TLIPS ((TLint4) 0, "*** Error: synchronization error on pc file", (TLint2) 0);
		TL_TLI_TLIPK ((TLint2) 0);
		TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
	    };
	    sfindex = (TL_TLS_TLSIND(sourceheader, "file=") + TL_TLS_TLSLEN("file=")) + 1;
	    sfend = TL_TLS_TLSIND(sourceheader, " startline=") - 2;
	    {
		TLstring	__x256;
		TL_TLS_TLSBXX(__x256, (TLint4) sfend, (TLint4) sfindex, sourceheader);
		(*pc).srcfile = linetable_install(__x256);
	    };
	    slindex = (TL_TLS_TLSIND(sourceheader, "startline=") + TL_TLS_TLSLEN("startline=")) + 1;
	    slend = TL_TLS_TLSIND(sourceheader, " endline=") - 2;
	    {
		TLstring	__x257;
		TL_TLS_TLSBXX(__x257, (TLint4) slend, (TLint4) slindex, sourceheader);
		(*pc).srcstartline = TL_TLS_TLSVSI(__x257, (TLint4) 10);
	    };
	    elindex = (TL_TLS_TLSIND(sourceheader, "endline=") + TL_TLS_TLSLEN("endline=")) + 1;
	    elend = TL_TLS_TLSLEN(sourceheader) - 2;
	    {
		TLstring	__x258;
		TL_TLS_TLSBXX(__x258, (TLint4) elend, (TLint4) elindex, sourceheader);
		(*pc).srcendline = TL_TLS_TLSVSI(__x258, (TLint4) 10);
	    };
	    (*pc).firstline = nlines;
	    nomlines = 0;
	    for(;;) {
		TLstring	line;
		if (TL_TLI_TLIEOF((TLint4) pcf)) {
		    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		    TL_TLI_TLIPS ((TLint4) 0, "*** Error: synchronization error on pc file", (TLint2) 0);
		    TL_TLI_TLIPK ((TLint2) 0);
		    TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
		};
		TL_TLI_TLISS ((TLint4) pcf, (TLint2) 1);
		TL_TLI_TLIGSS((TLint4) 4095, line, (TLint2) pcf);
		if (strcmp(line, "</source>") == 0) {
		    break;
		};
		{
		    TLstring	__x259;
		    linetable_strip(line, __x259);
		    TLSTRASS(4095, line, __x259);
		};
		if (((strcmp(line, "") != 0) && (strcmp(line, "INDENT") != 0)) && (strcmp(line, "DEDENT") != 0)) {
		    nomlines += 1;
		    if (strcmp(line, "}") != 0) {
			nlines += 1;
			if (nlines > 100000000) {
			    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
			    TL_TLI_TLIPS ((TLint4) 0, "*** Error: too many total lines ( > ", (TLint2) 0);
			    TL_TLI_TLIPI ((TLint4) 0, (TLint4) 100000000, (TLint2) 0);
			    TL_TLI_TLIPS ((TLint4) 0, ")", (TLint2) 0);
			    TL_TLI_TLIPK ((TLint2) 0);
			    TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
			};
			lines[nlines - 1] = linetable_install(line);
		    };
		};
	    };
	    (*pc).nlines = nlines - ((*pc).firstline);
	    (*pc).nomlines = nomlines;
	    if ((nomlines < minclonelines) || (nomlines > maxclonelines)) {
		(*pc).nlines = 0;
		(*pc).nomlines = 0;
		nlines = (*pc).firstline;
	    };
	};
   };
   if (!TL_TLI_TLIEOF((TLint4) pcf)) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, "*** Error: too many potential clones ( > ", (TLint2) 0);
	TL_TLI_TLIPI ((TLint4) 0, (TLint4) maxpcs, (TLint2) 0);
	TL_TLI_TLIPS ((TLint4) 0, ")", (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
   };
   TL_TLI_TLICL ((TLint4) pcf);
}

static void swappcs (i, j)
TLint4	i;
TLint4	j;
{
   struct PC	t;
   TLSTRCTASS(t, pcs[i - 1], struct PC);
   TLSTRCTASS(pcs[i - 1], pcs[j - 1], struct PC);
   TLSTRCTASS(pcs[j - 1], t, struct PC);
}
static TLint4	depth;

static void sortpcs (first, last)
TLint4	first;
TLint4	last;
{
   depth = depth + 1;
   if ((depth % 1000) == 1) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
   };
   if (first < last) {
	TLint4	low;
	TLint4	high;
	TLint4	pivot;
	low = first;
	high = last + 1;
	pivot = low;
	for(;;) {
	    for(;;) {
		high -= 1;
		if (low == high) {
		    break;
		};
		if ((pcs[high - 1].nlines) > (pcs[pivot - 1].nlines)) {
		    break;
		};
	    };
	    if (low == high) {
		break;
	    };
	    for(;;) {
		low += 1;
		if (low == high) {
		    break;
		};
		if ((pcs[pivot - 1].nlines) > (pcs[low - 1].nlines)) {
		    break;
		};
	    };
	    if (low == high) {
		break;
	    };
	    swappcs((TLint4) low, (TLint4) high);
	};
	swappcs((TLint4) high, (TLint4) pivot);
	sortpcs((TLint4) first, (TLint4) (high - 1));
	sortpcs((TLint4) (high + 1), (TLint4) last);
   };
   depth = depth - 1;
}
static TLnat2	*dpmatrix;
static TLint4	__x260;

static TLint4 lcs (pc1, pc2, m, n, difflimit)
struct PC	*pc1;
struct PC	*pc2;
TLint4	m;
TLint4	n;
TLint4	difflimit;
{
   TLint4	bi;
   {
	register TLint4	i;
	for (i = 0; i <= 1; i++) {
	    dpmatrix[((0) + __x260 * (i))] = 0;
	};
   };
   {
	register TLint4	j;
	TLint4	__x262;
	__x262 = n;
	j = 0;
	if (j <= __x262) {
	    for(;;) {
		dpmatrix[((j) + __x260 * (0))] = 0;
		if (j == __x262) break;
		j++;
	    }
	};
   };
   bi = 0;
   {
	register TLint4	i;
	TLint4	__x263;
	__x263 = m;
	i = 1;
	if (i <= __x263) {
	    for(;;) {
		bi = i % 2;
		{
		    register TLint4	j;
		    TLint4	__x264;
		    __x264 = n;
		    j = 1;
		    if (j <= __x264) {
			for(;;) {
			    if ((lines[(((*pc1).firstline) + i) - 1]) == (lines[(((*pc2).firstline) + j) - 1])) {
				dpmatrix[((j) + __x260 * (bi))] = (dpmatrix[((j - 1) + __x260 * (1 - bi))]) + 1;
			    } else {
				if ((dpmatrix[((j) + __x260 * (1 - bi))]) >= (dpmatrix[((j - 1) + __x260 * (bi))])) {
				    dpmatrix[((j) + __x260 * (bi))] = dpmatrix[((j) + __x260 * (1 - bi))];
				} else {
				    dpmatrix[((j) + __x260 * (bi))] = dpmatrix[((j - 1) + __x260 * (bi))];
				};
			    };
			    if (j == __x264) break;
			    j++;
			}
		    };
		};
		if ((i - (dpmatrix[((n) + __x260 * (bi))])) > difflimit) {
		    return (0);
		};
		if (i == __x263) break;
		i++;
	    }
	};
   };
   return (dpmatrix[((n) + __x260 * (bi))]);
   /* NOTREACHED */
}

static TLboolean exact (pc1, pc2)
struct PC	*pc1;
struct PC	*pc2;
{
   {
	register TLint4	i;
	TLint4	__x265;
	__x265 = (*pc1).nlines;
	i = 1;
	if (i <= __x265) {
	    for(;;) {
		if ((lines[(((*pc1).firstline) + i) - 1]) != (lines[(((*pc2).firstline) + i) - 1])) {
		    return (0);
		};
		if (i == __x265) break;
		i++;
	    }
	};
   };
   return (1);
   /* NOTREACHED */
}

static TLint4 nearmiss (pc1, pc2)
struct PC	*pc1;
struct PC	*pc2;
{
   TLint4	difflimit;
   TLint4	pc1pc2lcs;
   if (((((*pc2).srcfile) == ((*pc1).srcfile)) && (((*pc2).srcstartline) >= ((*pc1).srcstartline))) && (((*pc2).srcendline) <= ((*pc1).srcendline))) {
	return (0);
   };
   difflimit = TL_TLA_TLA8RD((TLreal8) ((((*pc1).nlines) * threshold) + 0.000001));
   pc1pc2lcs = lcs(&((*pc1)), &((*pc2)), (TLint4) ((*pc1).nlines), (TLint4) ((*pc2).nlines), (TLint4) difflimit);
   if (((((TLreal8) (((*pc1).nlines) - pc1pc2lcs))  / ((TLreal8) ((*pc1).nlines))) <= (threshold + 0.000001)) && ((((TLreal8) (((*pc2).nlines) - pc1pc2lcs))  / ((TLreal8) ((*pc2).nlines))) <= (threshold + 0.000001))) {
	return (TL_TLA_TLA8RD((TLreal8) (((((TLreal8) pc1pc2lcs)  / ((TLreal8) ((*pc1).nlines))) * 100) + 0.000001)));
   } else {
	return (0);
   };
   /* NOTREACHED */
}

static TLint4 clone (pc1, pc2, threshold)
struct PC	*pc1;
struct PC	*pc2;
TLreal8	threshold;
{
   ncompares += 1;
   if ((threshold + 0.000001) < 0.01) {
	if (exact(&((*pc1)), &((*pc2)))) {
	    nclones += 1;
	    nfragments += 1;
	    return (100);
	};
   } else {
	TLint4	sameness;
	sameness = nearmiss(&((*pc1)), &((*pc2)));
	if ((100 - sameness) <= TL_TLA_TLA8RD((TLreal8) ((threshold * 100) + 0.000001))) {
	    nclones += 1;
	    nfragments += 1;
	    return (sameness);
	};
   };
   return (0);
   /* NOTREACHED */
}

/* NICAD-INC: record a clone pair of two block references */
static void addpair (r1, r2, similarity)
TLint4	r1;
TLint4	r2;
TLint4	similarity;
{
   TLBIND((*cp), struct CP);
   npairs += 1;
   if (npairs > 20000000) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, "*** Error: too many clone pairs", (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
	TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
   };
   cp = &(clonepairs[npairs - 1]);
   (*cp).pc1 = r1;
   (*cp).pc2 = r2;
   (*cp).similarity = similarity;
   (*cp).nlines = ((((*PCREF(r1)).nomlines) + ((*PCREF(r2)).nomlines)) + 1) / 2;
}

/* NICAD-INC: compare two blocks as the size-sorted loop of clonepairs.x does:
   the larger block is pc1, and only blocks within its difference limit are compared */
static void comparepair (ra, rb)
TLint4	ra;
TLint4	rb;
{
   struct PC	*a;
   struct PC	*b;
   TLint4	t;
   TLint4	difflimit;
   TLint4	similarity;
   a = PCREF(ra);
   b = PCREF(rb);
   if (((*a).nlines == 0) || ((*b).nlines == 0)) {
	return;
   };
   if ((*b).nlines > (*a).nlines) {
	t = ra; ra = rb; rb = t;
	a = PCREF(ra);
	b = PCREF(rb);
   };
   difflimit = TL_TLA_TLA8RD((TLreal8) ((((*a).nlines) * threshold) + 0.000001));
   if (((*b).nlines) < (((*a).nlines) - difflimit)) {
	return;		/* outside the size window: clonepairs.x never compares these */
   };
   similarity = clone(&((*a)), &((*b)), (TLreal8) threshold);
   if (similarity != 0) {
	addpair((TLint4) ra, (TLint4) rb, (TLint4) similarity);
   };
}

/* NICAD-INC: the previous blocks are sorted by size (sortpcs, as in clonepairs.x). For a new
   block of x lines only previous blocks of lower..upper lines can be in clonepairs.x's size
   window (the larger block's difference limit): the loop starts at the first block of <= upper
   lines and stops at the first block of < lower lines - like the "exit when" of the original.
   The skipped blocks are the ones clone() is never called for anyway (same pairs, same ncompares). */
static TLint4 difflimitof (n)
TLint4	n;
{
   return (TL_TLA_TLA8RD((TLreal8) ((n * threshold) + 0.000001)));
}

static TLint4 windowstart (x, upper)		/* first j (1-based) with pcs[j-1].nlines <= upper */
TLint4	x;
TLint4	upper;
{
   TLint4	lo, hi, mid;
   lo = 1; hi = npcs + 1;
   while (lo < hi) {
	mid = (lo + hi) / 2;
	if (pcs[mid - 1].nlines <= upper) hi = mid; else lo = mid + 1;
   }
   return (lo);
}

static void findclones () {
   /* NICAD-INC: every new block against every previous block: mpcs x npcs
      (only the previous blocks inside the size window are visited, see windowstart) */
   {
	register TLint4	i;
	TLint4	__x266;
	__x266 = mpcs;
	i = 1;
	if (i <= __x266) {
	    for(;;) {
		if ((i % 1000) == 0) {
		    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		    TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
		};
		if ((newpcs[i - 1].nlines) != 0) {
		    TLint4	x, lower, upper;
		    x = newpcs[i - 1].nlines;
		    lower = x - difflimitof(x);			/* new block is the larger one */
		    upper = x;					/* previous block is the larger one */
		    while ((upper < pcs[0].nlines) && (((upper + 1) - difflimitof(upper + 1)) <= x)) {
			upper += 1;
		    };
		    {
			register TLint4	j;
			TLint4	__x267;
			__x267 = npcs;
			j = windowstart(x, upper);		/* = 1 when the largest block is in the window */
			if (j <= __x267) {
			    for(;;) {
				if ((pcs[j - 1].nlines) < lower) {
				    break;			/* all further blocks are smaller: no clones */
				};
				comparepair((TLint4) -i, (TLint4) j);		/* newpcs[i-1] x pcs[j-1] */
				if (j == __x267) break;
				j++;
			    }
			};
		    };
		    /* NICAD-INC: and against the other new blocks: mpcs x (mpcs-1) / 2 */
		    if (!nonewnew) {
			register TLint4	j;
			TLint4	__x267n;
			__x267n = mpcs;
			j = i + 1;
			if (j <= __x267n) {
			    for(;;) {
				comparepair((TLint4) -i, (TLint4) -j);	/* newpcs[i-1] x newpcs[j-1] */
				if (j == __x267n) break;
				j++;
			    }
			};
		    };
		};
		if (i == __x266) break;
		i++;
	    }
	};
   };
}
typedef	TLint4	__x268[20000000];
static __x268	clonepairmap;

static void swapclonepairmap (i, j)
TLint4	i;
TLint4	j;
{
   TLint4	t;
   t = clonepairmap[i - 1];
   clonepairmap[i - 1] = clonepairmap[j - 1];
   clonepairmap[j - 1] = t;
}
static TLint4	cdepth;

static void sortclonepairmapbyfile (first, last)
TLint4	first;
TLint4	last;
{
   cdepth = cdepth + 1;
   if ((cdepth % 1000) == 1) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
   };
   if (first < last) {
	TLint4	low;
	TLint4	high;
	TLint4	pivot;
	low = first;
	high = last + 1;
	pivot = low;
	for(;;) {
	    for(;;) {
		high -= 1;
		if (low == high) {
		    break;
		};
		if ((((*PCREF(clonepairs[(clonepairmap[high - 1]) - 1].pc1)).srcfile) > ((*PCREF(clonepairs[(clonepairmap[pivot - 1]) - 1].pc1)).srcfile)) || ((((*PCREF(clonepairs[(clonepairmap[high - 1]) - 1].pc1)).srcfile) == ((*PCREF(clonepairs[(clonepairmap[pivot - 1]) - 1].pc1)).srcfile)) && ((clonepairs[(clonepairmap[high - 1]) - 1].nlines) > (clonepairs[(clonepairmap[pivot - 1]) - 1].nlines)))) {
		    break;
		};
	    };
	    if (low == high) {
		break;
	    };
	    for(;;) {
		low += 1;
		if (low == high) {
		    break;
		};
		if ((((*PCREF(clonepairs[(clonepairmap[pivot - 1]) - 1].pc1)).srcfile) > ((*PCREF(clonepairs[(clonepairmap[low - 1]) - 1].pc1)).srcfile)) || ((((*PCREF(clonepairs[(clonepairmap[pivot - 1]) - 1].pc1)).srcfile) == ((*PCREF(clonepairs[(clonepairmap[low - 1]) - 1].pc1)).srcfile)) && ((clonepairs[(clonepairmap[pivot - 1]) - 1].nlines) > (clonepairs[(clonepairmap[low - 1]) - 1].nlines)))) {
		    break;
		};
	    };
	    if (low == high) {
		break;
	    };
	    swapclonepairmap((TLint4) low, (TLint4) high);
	};
	swapclonepairmap((TLint4) high, (TLint4) pivot);
	sortclonepairmapbyfile((TLint4) first, (TLint4) (high - 1));
	sortclonepairmapbyfile((TLint4) (high + 1), (TLint4) last);
   };
   cdepth = cdepth - 1;
}

static void pruneembeddedpairs () {
   TLint4	embeddedpairs;
   TLint4	p;
   {
	register TLint4	i;
	TLint4	__x271;
	__x271 = npairs;
	i = 1;
	if (i <= __x271) {
	    for(;;) {
		if ((((*PCREF(clonepairs[i - 1].pc1)).srcfile) > ((*PCREF(clonepairs[i - 1].pc2)).srcfile)) || ((((*PCREF(clonepairs[i - 1].pc1)).srcfile) == ((*PCREF(clonepairs[i - 1].pc2)).srcfile)) && (((*PCREF(clonepairs[i - 1].pc1)).srcstartline) > ((*PCREF(clonepairs[i - 1].pc2)).srcstartline)))) {
		    TLint4	opc1;
		    opc1 = clonepairs[i - 1].pc1;
		    clonepairs[i - 1].pc1 = clonepairs[i - 1].pc2;
		    clonepairs[i - 1].pc2 = opc1;
		};
		if (i == __x271) break;
		i++;
	    }
	};
   };
   {
	register TLint4	i;
	TLint4	__x272;
	__x272 = npairs;
	i = 1;
	if (i <= __x272) {
	    for(;;) {
		clonepairmap[i - 1] = i;
		if (i == __x272) break;
		i++;
	    }
	};
   };
   sortclonepairmapbyfile((TLint4) 1, (TLint4) npairs);
   embeddedpairs = 0;
   {
	register TLint4	i;
	for (i = npairs; i >= 1; i--) {
	    TLBIND((*pc1), struct PC);
	    TLBIND((*pc2), struct PC);
	    if ((i % 1000) == 1) {
		TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
	    };
	    pc1 = &((*PCREF(clonepairs[(clonepairmap[i - 1]) - 1].pc1)));
	    pc2 = &((*PCREF(clonepairs[(clonepairmap[i - 1]) - 1].pc2)));
	    {
		register TLint4	j;
		for (j = i - 1; j >= 1; j--) {
		    TLBIND((*bpc1), struct PC);
		    TLBIND((*bpc2), struct PC);
		    bpc1 = &((*PCREF(clonepairs[(clonepairmap[j - 1]) - 1].pc1)));
		    bpc2 = &((*PCREF(clonepairs[(clonepairmap[j - 1]) - 1].pc2)));
		    if (((*bpc1).srcfile) != ((*pc1).srcfile)) {
			break;
		    };
		    if ((((((*bpc1).srcfile) == ((*pc1).srcfile)) && (((*bpc2).srcfile) == ((*pc2).srcfile))) && ((((*bpc1).srcstartline) <= ((*pc1).srcstartline)) && (((*bpc1).srcendline) >= ((*pc1).srcendline)))) && ((((*bpc2).srcstartline) <= ((*pc2).srcstartline)) && (((*bpc2).srcendline) >= ((*pc2).srcendline)))) {
			embeddedpairs += 1;
			clonepairs[(clonepairmap[i - 1]) - 1].pc1 = 0;
			clonepairs[(clonepairmap[i - 1]) - 1].pc2 = 0;
			break;
		    };
		};
	    };
	};
   };
   npairs -= embeddedpairs;
   p = 1;
   {
	register TLint4	i;
	TLint4	__x273;
	__x273 = npairs;
	i = 1;
	if (i <= __x273) {
	    for(;;) {
		for(;;) {
		    if ((clonepairs[p - 1].pc1) != 0) {
			break;
		    };
		    p += 1;
		};
		TLSTRCTASS(clonepairs[i - 1], clonepairs[p - 1], struct CP);
		p += 1;
		if (i == __x273) break;
		i++;
	    }
	};
   };
}


/* ------------------------------------------------------------------------------------ */
/* NICAD-INC: take over the clone pairs of the previous revision                        */
/* ------------------------------------------------------------------------------------ */

/* find a string in the line table without adding it (-1 if it is not there) */
static TLint4 linetable_lookup (line)
TLstring	line;
{
   TLnat4	lineIndex;
   TLnat4	startIndex;
   lineIndex = linetable_hash(line);
   if (lineIndex >= 12000000) {
	lineIndex = lineIndex % 12000000;
   };
   startIndex = lineIndex;
   for(;;) {
	if ((linetable_lineTable[lineIndex]) == 0) {
	    return (-1);
	};
	if (strcmp((* (TLstring *) &linetable_lineText[(linetable_lineTable[lineIndex]) - 1]), line) == 0) {
	    return ((TLint4) lineIndex);
	};
	lineIndex += linetable_secondaryHash;
	if (lineIndex >= 12000000) {
	    lineIndex = lineIndex % 12000000;
	};
	if (lineIndex == startIndex) {
	    return (-1);
	};
   };
}

/* previous blocks by (srcfile, startline, endline) - open addressing */
static TLint4	*blockhash = 0;
static TLint4	blockhashsize = 0;

static TLnat4 blockkey (srcfile, sl, el)
TLint4	srcfile;
TLint4	sl;
TLint4	el;
{
   TLnat4	h;
   h = (TLnat4) srcfile * 2654435761u;
   h ^= (TLnat4) sl * 40503u + ((TLnat4) el << 7);
   h ^= h >> 15;
   return (h);
}

static void buildblockhash () {
   TLint4	i;
   TLnat4	k;
   blockhashsize = 16;
   while (blockhashsize < 2 * npcs + 16) blockhashsize *= 2;
   blockhash = (TLint4 *) malloc(sizeof(TLint4) * blockhashsize);
   for (i = 0; i < blockhashsize; i++) blockhash[i] = 0;
   for (i = 1; i <= npcs; i++) {
	k = blockkey((TLint4) pcs[i - 1].srcfile, pcs[i - 1].srcstartline, pcs[i - 1].srcendline) & (blockhashsize - 1);
	while (blockhash[k] != 0) k = (k + 1) & (blockhashsize - 1);
	blockhash[k] = i;
   }
}

static TLint4 findblock (srcfile, sl, el)		/* -> index into pcs (1-based), 0 = not there */
TLint4	srcfile;
TLint4	sl;
TLint4	el;
{
   TLnat4	k;
   k = blockkey(srcfile, sl, el) & (blockhashsize - 1);
   while (blockhash[k] != 0) {
	struct PC	*p;
	p = &pcs[blockhash[k] - 1];
	if (((TLint4) (*p).srcfile == srcfile) && ((*p).srcstartline == sl) && ((*p).srcendline == el)) {
	    return (blockhash[k]);
	};
	k = (k + 1) & (blockhashsize - 1);
   }
   return (0);
}

/* <source file="F" startline="S" endline="E" pcid="P"></source>  ->  previous block (1-based) or 0 */
static TLint4 blockofsourceline (line)
char	*line;
{
   char	*a;
   char	*b;
   char	*e;
   TLstring	fname;
   TLint4	srcfile;
   size_t	n;
   a = strstr(line, "file=\"");
   b = a ? strstr(a + 6, "\" startline=\"") : 0;
   e = b ? strstr(b, "endline=\"") : 0;
   if (!a || !b || !e) {
	return (-1);
   };
   n = (size_t) (b - (a + 6));
   if (n > 4095) {
	return (0);
   };
   memcpy(fname, a + 6, n);
   fname[n] = 0;
   /* NICAD-INC: from=/to=: the previous revision's path r<N-1>/... is r<N>/... now */
   if ((relabelfrom[0] != 0) && (strncmp(fname, relabelfrom, strlen(relabelfrom)) == 0)) {
	size_t	lf = strlen(relabelfrom), lt = strlen(relabelto);
	if (n - lf + lt > 4095) {
	    return (0);
	};
	memmove(fname + lt, fname + lf, n - lf + 1);
	memcpy(fname, relabelto, lt);
   };
   srcfile = linetable_lookup(fname);
   if (srcfile < 0) {
	return (0);			/* file not in previous_blocks.xml: deleted or modified */
   };
   return (findblock(srcfile, (TLint4) atoi(b + 13), (TLint4) atoi(e + 9)));
}

static void readpreviouspairs () {
   FILE	*f;
   static char	line[65536];
   TLint4	state;
   TLint4	got;
   TLint4	blk[2];
   TLint4	pnlines;
   TLint4	psim;
   state = 0; got = 0; pnlines = 0; psim = 0;
   f = fopen(prevpairsfile, "r");
   if (f == 0) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, "*** Error: cannot open previous clone pairs file ", (TLint2) 0);
	TL_TLI_TLIPS ((TLint4) 0, prevpairsfile, (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
	TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
   };
   buildblockhash();
   while (fgets(line, sizeof line, f) != 0) {
	char	*p;
	if (strncmp(line, "<clone ", 7) == 0) {
	    p = strstr(line, "nlines=\"");
	    pnlines = p ? atoi(p + 8) : 0;
	    p = strstr(line, "similarity=\"");
	    psim = p ? atoi(p + 12) : 0;
	    state = 1; got = 0; blk[0] = blk[1] = 0;
	} else if ((state == 1) && (strncmp(line, "<source ", 8) == 0) && (got < 2)) {
	    blk[got] = blockofsourceline(line);
	    got += 1;
	} else if ((state == 1) && (strncmp(line, "</clone>", 8) == 0)) {
	    state = 0;
	    if (got != 2) continue;
	    nprevpairs += 1;
	    if ((blk[0] > 0) && (blk[1] > 0) && (pcs[blk[0] - 1].nlines != 0) && (pcs[blk[1] - 1].nlines != 0)) {
		/* both blocks unchanged: the pair is still a clone pair */
		TLBIND((*cp), struct CP);
		npairs += 1;
		if (npairs > 20000000) {
		    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		    TL_TLI_TLIPS ((TLint4) 0, "*** Error: too many clone pairs", (TLint2) 0);
		    TL_TLI_TLIPK ((TLint2) 0);
		    TL_TLE_TLEQUIT ((TLint4) 1, (char *) 0, 0);
		};
		cp = &(clonepairs[npairs - 1]);
		(*cp).pc1 = blk[0];
		(*cp).pc2 = blk[1];
		(*cp).similarity = psim;
		(*cp).nlines = pnlines;
		nkeptpairs += 1;
	    } else {
		ndroppedpairs += 1;		/* a block was deleted or changed */
	    };
	};
   }
   fclose(f);
}

/* pcid of a block reference in the file previous_blocks.xml + new_blocks.xml */
static TLint4 pcidof (r)
TLint4	r;
{
   return ((r > 0) ? pcs[r - 1].num : npcs + newpcs[-r - 1].num);
}

/* re-sort all pairs: size (nlines) largest first, then by pcid */
static int comparecp (x, y)
const void	*x;
const void	*y;
{
   const struct CP	*a;
   const struct CP	*b;
   TLint4	a1, a2, b1, b2;
   a = (const struct CP *) x;
   b = (const struct CP *) y;
   if ((*a).nlines != (*b).nlines) return ((*a).nlines > (*b).nlines) ? -1 : 1;
   a1 = pcidof((*a).pc1); a2 = pcidof((*a).pc2);
   b1 = pcidof((*b).pc1); b2 = pcidof((*b).pc2);
   if (((a1 < a2) ? a1 : a2) != ((b1 < b2) ? b1 : b2)) return (((a1 < a2) ? a1 : a2) < ((b1 < b2) ? b1 : b2)) ? -1 : 1;
   if (((a1 < a2) ? a2 : a1) != ((b1 < b2) ? b2 : b1)) return (((a1 < a2) ? a2 : a1) < ((b1 < b2) ? b2 : b1)) ? -1 : 1;
   return (0);
}

static void sortallpairs () {
   qsort((void *) clonepairs, (size_t) npairs, sizeof(struct CP), comparecp);
}

/* NICAD-INC: the comparisons the original clonepairs.x makes on ALL blocks (previous + new):
   blocks sorted by size, block i compared with every later block j whose size is within
   i's difference limit (the loop of the original findclones()); counted, not compared */
static int cmpdesc (x, y)
const void	*x;
const void	*y;
{
   TLint4	a = *(const TLint4 *) x, b = *(const TLint4 *) y;
   return ((a > b) ? -1 : ((a < b) ? 1 : 0));
}

static double fullcompares () {
   TLint4	*v;
   TLint4	n, i, k, lo, hi, mid, low;
   double	total;
   v = (TLint4 *) malloc(sizeof(TLint4) * (size_t) (npcs + mpcs + 1));
   if (v == 0) return (-1.0);
   n = 0;
   for (i = 0; i < npcs; i++) if (pcs[i].nlines != 0) v[n++] = pcs[i].nlines;
   for (i = 0; i < mpcs; i++) if (newpcs[i].nlines != 0) v[n++] = newpcs[i].nlines;
   qsort((void *) v, (size_t) n, sizeof(TLint4), cmpdesc);
   total = 0.0;
   for (i = 0; i < n; i++) {
	low = v[i] - difflimitof(v[i]);
	lo = i; hi = n - 1;		/* last k with v[k] >= low */
	while (lo < hi) {
	    mid = (lo + hi + 1) / 2;
	    if (v[mid] >= low) lo = mid; else hi = mid - 1;
	};
	k = lo;
	total += (double) (k - i);
   };
   free(v);
   return (total);
}

static void showpairs () {
   TLint4	slashindex;
   TLstring	systeminfo;
   TLint4	usindex;
   TLstring	systemname;
   TLstring	granularity;

   extern TLint4 clock ();
   TLint4	cputime;
   slashindex = TL_TLS_TLSLEN(pcfile);
   for(;;) {
	TLchar	pcfchar;
	{
	    TLchar	__x274[2];
	    TL_TLS_TLSBX(__x274, (TLint4) slashindex, pcfile);
	    pcfchar = (* (TLchar *) __x274);
	};
	if ((slashindex == 0) || (pcfchar == '/')) {
	    break;
	};
	slashindex -= 1;
   };
   {
	TLstring	__x276;
	TL_TLS_TLSBXS(__x276, (TLint4) 0, (TLint4) (slashindex + 1), pcfile);
	TLSTRASS(4095, systeminfo, __x276);
   };
   usindex = TL_TLS_TLSLEN(systeminfo);
   for(;;) {
	TLchar	sichar;
	{
	    TLchar	__x277[2];
	    TL_TLS_TLSBX(__x277, (TLint4) usindex, systeminfo);
	    sichar = (* (TLchar *) __x277);
	};
	if ((usindex == 2) || (sichar == '_')) {
	    break;
	};
	usindex -= 1;
   };
   {
	TLstring	__x279;
	TL_TLS_TLSBXX(__x279, (TLint4) (usindex - 1), (TLint4) 1, systeminfo);
	TLSTRASS(4095, systemname, __x279);
   };
   {
	TLstring	__x280;
	TL_TLS_TLSBXX(__x280, (TLint4) (TL_TLS_TLSIND(systeminfo, ".xml") - 1), (TLint4) (usindex + 1), systeminfo);
	TLSTRASS(4095, granularity, __x280);
   };
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "<clones>", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "<systeminfo processor=\"nicad6\" system=\"", (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, systemname, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\" granularity=\"", (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, granularity, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\" threshold=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) TL_TLA_TLA8RD((TLreal8) ((threshold * 100) + 0.000001)), (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "%\" minlines=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) minclonelines, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\" maxlines=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) maxclonelines, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\"/>", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "<cloneinfo npcs=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) (npcs + mpcs), (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\" npairs=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) npairs, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\"/>", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
   cputime = clock();
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "<runinfo ncompares=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) ncompares, (TLint2) -1);
   TL_TLI_TLIPS ((TLint4) 0, "\" cputime=\"", (TLint2) -1);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) cputime, (TLint2) -1);
   {
	/* NICAD-INC: what this incremental run did, next to what a full run would do */
	char	info[512];
	sprintf(info, "\" ncompares_full=\"%.0f\" npcs_previous=\"%d\" npcs_new=\"%d\" npairs_previous=\"%d\" npairs_kept=\"%d\" npairs_dropped=\"%d\" npairs_new=\"%d",
	    fullcompares(), (int) npcs, (int) mpcs, (int) nprevpairs, (int) nkeptpairs, (int) ndroppedpairs, (int) nnewpairs);
	TL_TLI_TLIPS ((TLint4) 0, info, (TLint2) -1);
   };
   TL_TLI_TLIPS ((TLint4) 0, "\"/>", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
   {
	register TLint4	i;
	TLint4	__x281;
	__x281 = npairs;
	i = 1;
	if (i <= __x281) {
	    for(;;) {
		TLBIND((*cp), struct CP);
		TLBIND((*pc1), struct PC);
		TLBIND((*pc2), struct PC);
		if ((i % 1000) == 1) {
		    TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
		    TL_TLI_TLIPS ((TLint4) 0, ".", (TLint2) 0);
		};
		cp = &(clonepairs[i - 1]);
		TL_TLI_TLISSO ();
		TL_TLI_TLIPS ((TLint4) 0, "<clone nlines=\"", (TLint2) -1);
		TL_TLI_TLIPI ((TLint4) 0, (TLint4) ((*cp).nlines), (TLint2) -1);
		TL_TLI_TLIPS ((TLint4) 0, "\" similarity=\"", (TLint2) -1);
		TL_TLI_TLIPI ((TLint4) 0, (TLint4) ((*cp).similarity), (TLint2) -1);
		TL_TLI_TLIPS ((TLint4) 0, "\">", (TLint2) -1);
		TL_TLI_TLIPK ((TLint2) -1);
		pc1 = PCREF((*cp).pc1);
		pc2 = PCREF((*cp).pc2);
		{
		    TLstring	__x283;
		    linetable_gettext((linetable_LN) ((*pc1).info), __x283);
		    {
			TLstring	__x282;
			TL_TLS_TLSBXS(__x282, (TLint4) -1, (TLint4) 1, __x283);
			TL_TLI_TLISSO ();
			TL_TLI_TLIPS ((TLint4) 0, __x282, (TLint2) -1);
			TL_TLI_TLIPS ((TLint4) 0, " pcid=\"", (TLint2) -1);
			TL_TLI_TLIPI ((TLint4) 0, (TLint4) (((*cp).pc1 > 0) ? (*pc1).num : npcs + (*pc1).num), (TLint2) -1);
			TL_TLI_TLIPS ((TLint4) 0, "\">", (TLint2) -1);
		    };
		};
		if (showsource) {
		    TL_TLI_TLISSO ();
		    TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) -1);
		    TL_TLI_TLIPK ((TLint2) -1);
		    {
			register TLint4	k;
			TLint4	__x284;
			__x284 = (*pc1).nlines;
			k = 1;
			if (k <= __x284) {
			    for(;;) {
				{
				    TLstring	__x285;
				    linetable_gettext((linetable_LN) (lines[(((*pc1).firstline) + k) - 1]), __x285);
				    TL_TLI_TLISSO ();
				    TL_TLI_TLIPS ((TLint4) 0, __x285, (TLint2) -1);
				    TL_TLI_TLIPK ((TLint2) -1);
				};
				if (k == __x284) break;
				k++;
			    }
			};
		    };
		};
		TL_TLI_TLISSO ();
		TL_TLI_TLIPS ((TLint4) 0, "</source>", (TLint2) -1);
		TL_TLI_TLIPK ((TLint2) -1);
		{
		    TLstring	__x287;
		    linetable_gettext((linetable_LN) ((*pc2).info), __x287);
		    {
			TLstring	__x286;
			TL_TLS_TLSBXS(__x286, (TLint4) -1, (TLint4) 1, __x287);
			TL_TLI_TLISSO ();
			TL_TLI_TLIPS ((TLint4) 0, __x286, (TLint2) -1);
			TL_TLI_TLIPS ((TLint4) 0, " pcid=\"", (TLint2) -1);
			TL_TLI_TLIPI ((TLint4) 0, (TLint4) (((*cp).pc2 > 0) ? (*pc2).num : npcs + (*pc2).num), (TLint2) -1);
			TL_TLI_TLIPS ((TLint4) 0, "\">", (TLint2) -1);
		    };
		};
		if (showsource) {
		    TL_TLI_TLISSO ();
		    TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) -1);
		    TL_TLI_TLIPK ((TLint2) -1);
		    {
			register TLint4	k;
			TLint4	__x288;
			__x288 = (*pc2).nlines;
			k = 1;
			if (k <= __x288) {
			    for(;;) {
				{
				    TLstring	__x289;
				    linetable_gettext((linetable_LN) (lines[(((*pc2).firstline) + k) - 1]), __x289);
				    TL_TLI_TLISSO ();
				    TL_TLI_TLIPS ((TLint4) 0, __x289, (TLint2) -1);
				    TL_TLI_TLIPK ((TLint2) -1);
				};
				if (k == __x288) break;
				k++;
			    }
			};
		    };
		};
		TL_TLI_TLISSO ();
		TL_TLI_TLIPS ((TLint4) 0, "</source>", (TLint2) -1);
		TL_TLI_TLIPK ((TLint2) -1);
		TL_TLI_TLISSO ();
		TL_TLI_TLIPS ((TLint4) 0, "</clone>", (TLint2) -1);
		TL_TLI_TLIPK ((TLint2) -1);
		TL_TLI_TLISSO ();
		TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) -1);
		TL_TLI_TLIPK ((TLint2) -1);
		if (i == __x281) break;
		i++;
	    }
	};
   };
   TL_TLI_TLISSO ();
   TL_TLI_TLIPS ((TLint4) 0, "</clones>", (TLint2) -1);
   TL_TLI_TLIPK ((TLint2) -1);
}

static void getprogramarguments () {
   /* NICAD-INC: previous_blocks.xml new_blocks.xml [previous_clones.xml] [threshold] [min] [max] [showsource] [nonewnew] */
   TLint4	a;		/* argument number of the threshold */
   TLint4	n;
   if (TL_TLI_TLIARC < 2) {
	useerr();
   };
   {
	TLstring	__x290;
	TL_TLI_TLIFA((TLint4) 1, __x290);
	TLSTRASS(4095, pcfile, __x290);
	TL_TLI_TLIFA((TLint4) 2, __x290);
	TLSTRASS(4095, newpcfile, __x290);
   };
   prevpairsfile[0] = 0;
   a = 3;
   if (TL_TLI_TLIARC > 2) {
	TLstring	__x296;
	TL_TLI_TLIFA((TLint4) 3, __x296);
	n = strlen(__x296);
	/* a third file name (not a number): the previous revision's clone pairs */
	if (((n > 4) && (strcmp(__x296 + n - 4, ".xml") == 0)) || (strcmp(__x296, "-") == 0)) {
	    if (strcmp(__x296, "-") != 0) {
		TLSTRASS(4095, prevpairsfile, __x296);
	    };
	    a = 4;
	};
   };
   if (TL_TLI_TLIARC >= a) {
	{
	    TLstring	__x291;
	    TL_TLI_TLIFA((TLint4) a, __x291);
	    threshold = TL_TLS_TLSVS8(__x291);
	};
	if ((threshold < 0.0) || (threshold > 1.0)) {
	    useerr();
	};
   };
   if (TL_TLI_TLIARC >= a + 1) {
	{
	    TLstring	__x292;
	    TL_TLI_TLIFA((TLint4) (a + 1), __x292);
	    minclonelines = TL_TLS_TLSVSI(__x292, (TLint4) 10);
	};
	if ((minclonelines < 1) || (minclonelines > 100)) {
	    useerr();
	};
   };
   if (TL_TLI_TLIARC >= a + 2) {
	{
	    TLstring	__x293;
	    TL_TLI_TLIFA((TLint4) (a + 2), __x293);
	    maxclonelines = TL_TLS_TLSVSI(__x293, (TLint4) 10);
	};
	if ((maxclonelines < minclonelines) || (maxclonelines > 20000)) {
	    useerr();
	};
   };
   for (n = a + 3; n <= TL_TLI_TLIARC; n++) {
	TLstring	__x294;
	TL_TLI_TLIFA((TLint4) n, __x294);
	if (strcmp(__x294, "nonewnew") == 0) {
	    nonewnew = 1;
	} else if (strncmp(__x294, "from=", 5) == 0) {
	    strncpy(relabelfrom, __x294 + 5, sizeof relabelfrom - 1);
	} else if (strncmp(__x294, "to=", 3) == 0) {
	    strncpy(relabelto, __x294 + 3, sizeof relabelto - 1);
	} else {
	    showsource = 1;
	};
   };
}
static TLint4	oldnpairs;
void TProg () {
   threshold = 0.0;
   minclonelines = 5;
   maxclonelines = 2500;
   showsource = 0;
   nonewnew = 0;
   nprevpairs = 0; nkeptpairs = 0; ndroppedpairs = 0; nnewpairs = 0;
   getprogramarguments();
   linetable();
   npcs = 0;
   mpcs = 0;
   nlines = 0;
   npairs = 0;
   ncompares = 0;
   nclones = 0;
   nfragments = 0;
   depth = 0;
   __x260 = TLDYN(maxclonelines - -1);
   TL_TLB_TLBALL((TLint4) 2 * (__x260 * 2), &dpmatrix);
   cdepth = 0;
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Processing ", (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, pcfile, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " with difference threshold ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) TL_TLA_TLA8RD((TLreal8) ((threshold * 100) + 0.000001)), (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, "%, clone size ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) minclonelines, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " .. ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) maxclonelines, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " lines", (TLint2) 0);
   if (showsource) {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, ", with pc source", (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
   } else {
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
   };
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Reading pcs ", (TLint2) 0);
   readpcs(pcfile, pcs, &npcs, (TLint4) 6000000);		/* NICAD-INC: previous blocks */
   readpcs(newpcfile, newpcs, &mpcs, (TLint4) MAXNEWPCS);	/* NICAD-INC: new blocks */
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " done.", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Total ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) npcs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " previous + ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) mpcs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " new potential clones of ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) minclonelines, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " lines or more", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Used ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) nlines, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, "/", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) 100000000, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " total pc lines", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   linetable_printstats();
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Sorting pcs ", (TLint2) 0);
   sortpcs((TLint4) 1, (TLint4) npcs);		/* NICAD-INC: previous blocks by size, as clonepairs.x does */
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " done.", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Finding clones ", (TLint2) 0);
   findclones();
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " done.", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Total ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) ncompares, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " pc comparisons", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Pruning embedded clone pairs ", (TLint2) 0);
   oldnpairs = npairs;
   pruneembeddedpairs();
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " done.", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Pruned ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) (oldnpairs - npairs), (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " embedded clone pairs", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Found ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) npairs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " new clone pairs", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   /* NICAD-INC: + the previous revision's pairs between unchanged blocks, then re-sort */
   nnewpairs = npairs;
   if (prevpairsfile[0] != 0) {
	readpreviouspairs();
	TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
	TL_TLI_TLIPS ((TLint4) 0, "Previous clone pairs ", (TLint2) 0);
	TL_TLI_TLIPI ((TLint4) 0, (TLint4) nprevpairs, (TLint2) 0);
	TL_TLI_TLIPS ((TLint4) 0, ": kept ", (TLint2) 0);
	TL_TLI_TLIPI ((TLint4) 0, (TLint4) nkeptpairs, (TLint2) 0);
	TL_TLI_TLIPS ((TLint4) 0, ", dropped (deleted / modified blocks) ", (TLint2) 0);
	TL_TLI_TLIPI ((TLint4) 0, (TLint4) ndroppedpairs, (TLint2) 0);
	TL_TLI_TLIPK ((TLint2) 0);
   };
   sortallpairs();
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Total ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) npairs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " clone pairs (", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) nkeptpairs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " previous + ", (TLint2) 0);
   TL_TLI_TLIPI ((TLint4) 0, (TLint4) nnewpairs, (TLint2) 0);
   TL_TLI_TLIPS ((TLint4) 0, " new)", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "Generating XML output ", (TLint2) 0);
   showpairs();
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, " done.", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
   TL_TLI_TLISS ((TLint4) 0, (TLint2) 2);
   TL_TLI_TLIPS ((TLint4) 0, "", (TLint2) 0);
   TL_TLI_TLIPK ((TLint2) 0);
}