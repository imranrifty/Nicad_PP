/*
 * clonepairs_rev.c - clone pairs of a revision from the previous revision (exact, fast)
 *
 *   clonepairs_rev.x old.xml new.xml prev-pairs.xml threshold [minsize] [maxsize] [showsource]
 *                 [--name rN_gran.xml] [--allpairs next-pairs.xml] [--relabel FROM TO]
 *                 [--stats file] [--round trunc|nearest] [--quiet]        > clones.xml
 *
 *   clonepairs_rev.x --full pcfile.xml threshold [minsize] [maxsize] [showsource]
 *                 [--allpairs next-pairs.xml] [--stats file] [--round ...]  > clones.xml
 *
 * old.xml        potential clones kept from the previous revision (files not changed),
 *                already transformed / renamed / filtered / abstracted / normalized
 * new.xml        potential clones of the added and modified files of this revision,
 *                normalized the same way
 * prev-pairs.xml all clone pairs of the previous revision before pruning (the file that
 *                --allpairs wrote last time; "-" if there is none)
 *
 * The comparisons are:   new x old  and  new x new.   Never old x old: the decisions
 * between two old fragments are taken from prev-pairs.xml (a pair's decision depends only
 * on its two fragments, which did not change). new x new is needed too: two new files
 * that contain the same new function are a clone pair nobody else can find.
 *
 * The result is the clone-pair file of the revision (old + new), written exactly as
 * clonepairs.x would write it for the file old.xml + new.xml (same pairs, similarity,
 * pcids, order and pruning of embedded pairs); <runinfo ncompares> counts the
 * comparisons that were needed (those involving a new fragment).
 *
 * How:
 *   - clonepairs.x logic unchanged: size window, exact() for threshold 0, nearmiss() with
 *     LCS for threshold > 0, the embedded-fragment test, pruneembeddedpairs;
 *   - its line table, quicksort and ordering are reproduced exactly, so the output order,
 *     pair orientation and pruning ties are the same;
 *   - lines are hashed/interned; LCS is bit-parallel; a new fragment is only compared with
 *     fragments that share one of its rarest lines, and pairs whose shared-line count is
 *     below the threshold are rejected without LCS (both filters are exact);
 *   - two nested fragments of the same file with the same number of lines are the only
 *     decision clonepairs.x takes differently depending on the input order; such pairs are
 *     decided again on every run.
 *   - round(): the Turing+ -> C translation of the NiCad tools defines round(x) as (int)x.
 *     Default is that (trunc); use --round nearest if your clonepairs.x rounds.
 *
 * Build:  gcc -O2 -o clonepairs_rev.x clonepairs2.c -lm
 */
#define _POSIX_C_SOURCE 200809L
#define memmem nicad_memmem
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>

static void *nicad_memmem(const void *h, size_t hl, const void *n, size_t nl) {
    const char *p = h;
    if (nl == 0) return (void *)h;
    for (size_t i = 0; i + nl <= hl; i++)
        if (p[i] == *(const char *)n && memcmp(p + i, n, nl) == 0) return (void *)(p + i);
    return NULL;
}

#define EPS 0.000001
#define NT_SIZE 12000000u              /* line table size of clonepairs.x */
#define NT_SECONDARY 262007u           /* its secondary hash step */

/* ------------------------------------------------------------------------- */
/* utilities                                                                 */
/* ------------------------------------------------------------------------- */
static int quiet = 0;

static void die(const char *msg) {
    fprintf(stderr, "*** Error: %s\n", msg);
    exit(1);
}
static void *xmalloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) die("out of memory"); return p; }
static void *xcalloc(size_t n, size_t s) { void *p = calloc(n ? n : 1, s ? s : 1); if (!p) die("out of memory"); return p; }
static void *xrealloc(void *p, size_t n) { p = realloc(p, n ? n : 1); if (!p) die("out of memory"); return p; }
static char *xstrndup(const char *s, size_t n) { char *p = xmalloc(n + 1); memcpy(p, s, n); p[n] = 0; return p; }
static size_t cnt(long n) { return (size_t)(n > 0 ? n : 1); }

/* round() of clonepairs.x. The Turing+ -> C translation used for the NiCad tools defines
   round(x) as (int)x (truncation); a build with a real round() gives floor(x + 0.5).
   --round trunc|nearest (or NICADPP_ROUND) selects it; default: trunc. */
static int round_nearest = 0;
static int tround(double x) { return round_nearest ? (int)floor(x + 0.5) : (int)x; }

static uint64_t fnv64(const void *data, size_t n, uint64_t h) {
    const unsigned char *p = data;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}
static uint64_t mix64(uint64_t x) {
    x ^= x >> 33; x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33; return x;
}
static uint64_t poly64(const void *data, size_t n, uint64_t h) {   /* second, independent hash */
    const unsigned char *p = data;
    for (size_t i = 0; i < n; i++) { h = (h ^ p[i]) * 0x9E3779B97F4A7C15ULL; h = (h << 29) | (h >> 35); }
    return h;
}

/* ------------------------------------------------------------------------- */
/* interned strings (lines, headers, file names)                             */
/* ------------------------------------------------------------------------- */
typedef struct {
    char **str; uint32_t *len; uint64_t *hash; int32_t *ln;   /* ln: slot in NiCad's table, -1 = not installed */
    int n, cap;
    int32_t *slot; uint64_t mask;
} LineTab;
static LineTab LT;

static void lt_init(void) {
    LT.n = 0; LT.cap = 1024;
    LT.str = xmalloc(sizeof(char *) * LT.cap);
    LT.len = xmalloc(sizeof(uint32_t) * LT.cap);
    LT.hash = xmalloc(sizeof(uint64_t) * LT.cap);
    LT.ln = xmalloc(sizeof(int32_t) * LT.cap);
    LT.mask = 4095;
    LT.slot = xmalloc(sizeof(int32_t) * (LT.mask + 1));
    memset(LT.slot, 0xff, sizeof(int32_t) * (LT.mask + 1));
}
static void lt_grow(void) {
    uint64_t nm = (LT.mask + 1) * 2 - 1;
    int32_t *ns = xmalloc(sizeof(int32_t) * (nm + 1));
    memset(ns, 0xff, sizeof(int32_t) * (nm + 1));
    for (int i = 0; i < LT.n; i++) {
        uint64_t k = LT.hash[i] & nm;
        while (ns[k] >= 0) k = (k + 1) & nm;
        ns[k] = i;
    }
    free(LT.slot); LT.slot = ns; LT.mask = nm;
}
static int lt_intern(const char *s, size_t n) {
    uint64_t h = mix64(fnv64(s, n, 14695981039346656037ULL));
    uint64_t k = h & LT.mask;
    while (LT.slot[k] >= 0) {
        int i = LT.slot[k];
        if (LT.hash[i] == h && LT.len[i] == n && memcmp(LT.str[i], s, n) == 0) return i;
        k = (k + 1) & LT.mask;
    }
    if (LT.n == LT.cap) {
        LT.cap *= 2;
        LT.str = xrealloc(LT.str, sizeof(char *) * LT.cap);
        LT.len = xrealloc(LT.len, sizeof(uint32_t) * LT.cap);
        LT.hash = xrealloc(LT.hash, sizeof(uint64_t) * LT.cap);
        LT.ln = xrealloc(LT.ln, sizeof(int32_t) * LT.cap);
    }
    int id = LT.n++;
    LT.str[id] = xstrndup(s, n); LT.len[id] = (uint32_t)n; LT.hash[id] = h; LT.ln[id] = -1;
    LT.slot[k] = id;
    if ((uint64_t)LT.n * 2 > LT.mask) lt_grow();
    return id;
}

/* ---- emulation of the line table of clonepairs.x: gives the same slot numbers */
static int32_t *NT = NULL;                /* slot -> interned id + 1; 0 empty; -1 the initial " " (calloc: no 48 MB memset) */

static uint32_t tl_hash(const char *s, size_t len) {
    const unsigned char *b = (const unsigned char *)s;
    uint32_t h = (uint32_t)(len > 255 ? 255 : len);
    int j = (int)h - 1;
    if (h > 0) {
        uint32_t half = h >> 1;
        for (uint32_t i = 0; i <= half; i++) {
            h += (h << 1) + b[i];
            h += (h << 1) + b[j];
            j--;
        }
    }
    return h;
}
static uint32_t nt_install(int id) {
    if (LT.ln[id] >= 0) return (uint32_t)LT.ln[id];
    uint32_t idx = tl_hash(LT.str[id], LT.len[id]);
    if (idx >= NT_SIZE) idx %= NT_SIZE;
    uint32_t start = idx;
    for (;;) {
        if (NT[idx] == 0) { NT[idx] = id + 1; break; }
        if (NT[idx] == id + 1) break;
        idx += NT_SECONDARY;
        if (idx >= NT_SIZE) idx %= NT_SIZE;
        if (idx == start) die("too many unique lines (line table of clonepairs.x is full)");
    }
    LT.ln[id] = (int32_t)idx;
    return idx;
}

/* ------------------------------------------------------------------------- */
/* fragments (potential clones)                                              */
/* ------------------------------------------------------------------------- */
typedef struct {
    int num;              /* pcid: position in the pc file (1-based) */
    char *header;         /* <source file=... startline=... endline=...> */
    char *file, *rel;     /* file attribute; path inside r<N>/ */
    int fln;              /* slot of the file name in NiCad's line table */
    int start, end;
    int nom, nl;          /* nomlines / comparable lines (both 0 if outside min/max) */
    int *ids, *sids;      /* comparable line ids, in order / sorted */
    uint64_t h1, h2;      /* content hashes of the comparable lines */
    uint64_t khash;       /* hash of the reuse key */
    int changed;          /* new or changed since the cached run */
    int rank;             /* position after sortpcs (1-based) */
} Frag;

static Frag *F = NULL;
static int NF = 0;

static int cmp_int(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

static const char *find_rel(const char *file) {       /* path after .../r<N>/ */
    for (const char *p = file; *p; p++) {
        if ((*p == '/' || *p == '\\') && p[1] == 'r' && p[2] >= '0' && p[2] <= '9') {
            const char *q = p + 2;
            while (*q >= '0' && *q <= '9') q++;
            if (*q == '/' || *q == '\\') return q + 1;
        }
    }
    return file;
}

static uint64_t key_hash(const Frag *f) {
    uint64_t h = fnv64(f->rel, strlen(f->rel), 14695981039346656037ULL);
    int v[3] = { f->start, f->end, f->nom };
    h = fnv64(v, sizeof v, h);
    h = fnv64(&f->h1, 8, h);
    h = fnv64(&f->h2, 8, h);
    return mix64(h);
}

static char *strip_tl(char *s, size_t *n) {   /* blanks, tabs and form feeds at both ends */
    size_t a = 0, b = *n;
    while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\f')) a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\f')) b--;
    *n = b - a;
    return s + a;
}

static void read_pcs_fp(FILE *f, int minl, int maxl) {
    char *buf = NULL; size_t cap = 0; ssize_t len;
    int *tmp = NULL, tcap = 0;
    static int cap_f = 0;                       /* F grows over several calls (old, then new) */
    if (!F) { cap_f = 1024; F = xmalloc(sizeof(Frag) * cap_f); }
    while ((len = getline(&buf, &cap, f)) != -1) {
        if (len > 0 && buf[len - 1] == '\n') buf[--len] = 0;
        if (len == 0) continue;
        if (strncmp(buf, "<source ", 8) != 0) die("synchronization error on pc file");
        if (NF == cap_f) { cap_f *= 2; F = xrealloc(F, sizeof(Frag) * cap_f); }
        Frag *fr = &F[NF];
        memset(fr, 0, sizeof *fr);
        fr->num = ++NF;
        fr->header = xstrndup(buf, (size_t)len);
        nt_install(lt_intern(buf, (size_t)len));                  /* header line */
        char *a = strstr(buf, "file=\"");
        char *b = a ? strstr(a + 6, "\" startline=\"") : NULL;
        char *e = b ? strstr(b, "endline=\"") : NULL;
        if (!a || !b || !e) die("cannot parse pc header");
        fr->file = xstrndup(a + 6, (size_t)(b - (a + 6)));
        fr->start = atoi(b + 13);
        fr->end = atoi(e + 9);
        fr->rel = (char *)find_rel(fr->file);
        fr->fln = (int)nt_install(lt_intern(fr->file, strlen(fr->file)));   /* source file name */
        int n = 0, nom = 0;
        uint64_t h1 = 14695981039346656037ULL, h2 = 0x243F6A8885A308D3ULL;
        for (;;) {
            len = getline(&buf, &cap, f);
            if (len == -1) die("synchronization error on pc file");
            if (len > 0 && buf[len - 1] == '\n') buf[--len] = 0;
            if (strcmp(buf, "</source>") == 0) break;
            size_t sl = (size_t)len;
            char *s = strip_tl(buf, &sl);
            if (sl == 0 || (sl == 6 && memcmp(s, "INDENT", 6) == 0) || (sl == 6 && memcmp(s, "DEDENT", 6) == 0))
                continue;
            nom++;
            if (sl == 1 && s[0] == '}') continue;
            if (n == tcap) { tcap = tcap ? tcap * 2 : 256; tmp = xrealloc(tmp, sizeof(int) * tcap); }
            int id = lt_intern(s, sl);
            nt_install(id);
            tmp[n++] = id;
            h1 = fnv64(s, sl, h1); h1 = fnv64("\n", 1, h1);
            h2 = poly64(s, sl, h2); h2 = poly64("\n", 1, h2);
        }
        if (nom < minl || nom > maxl) { fr->nom = 0; fr->nl = 0; }
        else { fr->nom = nom; fr->nl = n; }
        /* the lines are kept even for filtered fragments (showsource never prints them) */
        fr->ids = xmalloc(sizeof(int) * cnt(n));
        memcpy(fr->ids, tmp, sizeof(int) * n);
        fr->sids = xmalloc(sizeof(int) * cnt(fr->nl));
        memcpy(fr->sids, tmp, sizeof(int) * fr->nl);
        qsort(fr->sids, (size_t)fr->nl, sizeof(int), cmp_int);
        fr->h1 = mix64(h1 ^ (uint64_t)fr->nl);
        fr->h2 = mix64(h2 + (uint64_t)fr->nl * 0x9E3779B97F4A7C15ULL);
        fr->khash = key_hash(fr);
    }
    free(buf); free(tmp);
}

/* ------------------------------------------------------------------------- */
/* the quicksort of clonepairs.x (same partitioning, so same result on ties) */
/*   arr[1..n]; gt(x, y) = key[x] > key[y]; sorts in descending key order    */
/* ------------------------------------------------------------------------- */
static void tl_quicksort(int *arr, int n, const uint64_t *key) {
    long cap = 64, sp = 0;
    int *st = xmalloc(sizeof(int) * 2 * cap);
    st[sp++] = 1; st[sp++] = n;
    while (sp > 0) {
        int last = st[--sp], first = st[--sp];
        if (first >= last) continue;
        /* a non-increasing range is left exactly as it is by this partitioning */
        int mono = 1;
        for (int i = first; i < last; i++) if (key[arr[i + 1]] > key[arr[i]]) { mono = 0; break; }
        if (mono) continue;
        int low = first, high = last + 1, pivot = first;
        for (;;) {
            do high--; while (!(low == high || key[arr[high]] > key[arr[pivot]]));
            if (low == high) break;
            do low++; while (!(low == high || key[arr[pivot]] > key[arr[low]]));
            if (low == high) break;
            int x = arr[low]; arr[low] = arr[high]; arr[high] = x;
        }
        int x = arr[high]; arr[high] = arr[pivot]; arr[pivot] = x;
        if (sp + 4 > 2 * cap) { cap *= 2; st = xrealloc(st, sizeof(int) * 2 * cap); }
        st[sp++] = first; st[sp++] = high - 1;
        st[sp++] = high + 1; st[sp++] = last;
    }
    free(st);
}

/* ------------------------------------------------------------------------- */
/* LCS: bit-parallel (Hyyroe 2004), b = shorter sequence as bit vector       */
/* ------------------------------------------------------------------------- */
static int *pm_stamp = NULL, *pm_slot = NULL, pm_gen = 0;
static uint64_t *pm_masks = NULL; static size_t pm_cap = 0;
static uint64_t *lcs_v = NULL; static size_t lcs_vcap = 0;

static int lcs_len(const int *a, int na, const int *b, int nb) {
    if (nb > na) { const int *t = a; a = b; b = t; int x = na; na = nb; nb = x; }
    if (nb == 0) return 0;
    int words = (nb + 63) / 64;
    pm_gen++;
    int distinct = 0;
    size_t need = (size_t)nb * words;
    if (need > pm_cap) { pm_cap = need; pm_masks = xrealloc(pm_masks, sizeof(uint64_t) * pm_cap); }
    for (int j = 0; j < nb; j++) {
        int x = b[j];
        if (pm_stamp[x] != pm_gen) {
            pm_stamp[x] = pm_gen; pm_slot[x] = distinct;
            memset(pm_masks + (size_t)distinct * words, 0, sizeof(uint64_t) * words);
            distinct++;
        }
        pm_masks[(size_t)pm_slot[x] * words + j / 64] |= 1ULL << (j % 64);
    }
    if ((size_t)words > lcs_vcap) { lcs_vcap = words; lcs_v = xrealloc(lcs_v, sizeof(uint64_t) * lcs_vcap); }
    uint64_t *V = lcs_v;
    uint64_t lastmask = (nb % 64) ? ((1ULL << (nb % 64)) - 1) : ~0ULL;
    for (int w = 0; w < words; w++) V[w] = ~0ULL;
    V[words - 1] &= lastmask;
    for (int i = 0; i < na; i++) {
        int x = a[i];
        if (pm_stamp[x] != pm_gen) continue;            /* no match: V unchanged */
        const uint64_t *M = pm_masks + (size_t)pm_slot[x] * words;
        uint64_t carry = 0;
        for (int w = 0; w < words; w++) {
            uint64_t v = V[w], u = v & M[w];
            uint64_t t = v + u; uint64_t c1 = t < v;
            uint64_t s = t + carry; uint64_t c2 = s < t;
            carry = c1 | c2;
            V[w] = s | (v & ~u);                       /* (V + U) | (V - U) */
        }
        V[words - 1] &= lastmask;
    }
    int ones = 0;
    for (int w = 0; w < words; w++) ones += __builtin_popcountll(V[w]);
    return nb - ones;
}

/* result of nearmiss() + clone() in clonepairs.x once the embedding test is passed;
   p1 = the fragment with more lines (with equal sizes both give the same result) */
static int nearmiss_value(int n1, int n2, double t, int thr_pct, int lcs) {
    int same;
    if (((double)(n1 - lcs) / (double)n1) <= (t + EPS) && ((double)(n2 - lcs) / (double)n2) <= (t + EPS))
        same = tround(((double)lcs / (double)n1) * 100 + EPS);
    else
        same = 0;
    return (100 - same) <= thr_pct ? same : 0;
}

/* smallest l with (n - l)/n <= t + EPS: every clone of a fragment of n lines needs LCS >= tau(n) */
static int tau_of(int n, double t) {
    for (int l = 0; l <= n; l++)
        if (((double)(n - l) / (double)n) <= (t + EPS)) return l;
    return n + 1;
}

static const int *DF = NULL;                      /* document frequency of line ids */
static int cmp_rarity(const void *pa, const void *pb) {
    int x = *(const int *)pa, y = *(const int *)pb;
    if (DF[x] != DF[y]) return DF[x] < DF[y] ? -1 : 1;
    return (x > y) - (x < y);
}

static int shared_lines(const Frag *a, const Frag *b) {   /* size of the multiset intersection */
    int i = 0, j = 0, c = 0;
    while (i < a->nl && j < b->nl) {
        if (a->sids[i] < b->sids[j]) i++;
        else if (a->sids[i] > b->sids[j]) j++;
        else { c++; i++; j++; }
    }
    return c;
}

static int inside(const Frag *x, const Frag *y) {         /* x embedded in y (same file) */
    return x->fln == y->fln && x->start >= y->start && x->end <= y->end;
}
/* the only decision of clonepairs.x that depends on which fragment is pc1 */
static int order_dependent(const Frag *a, const Frag *b) {
    return a->nl == b->nl && a->fln == b->fln && (inside(a, b) || inside(b, a));
}

/* ------------------------------------------------------------------------- */
/* hash map uint64 -> int                                                    */
/* ------------------------------------------------------------------------- */
typedef struct { uint64_t *k; int *v; uint8_t *used; uint64_t mask; size_t n; } Map;

static void map_init(Map *m, size_t expect) {
    uint64_t sz = 16; while (sz < expect * 2 + 16) sz <<= 1;
    m->mask = sz - 1; m->n = 0;
    m->k = xmalloc(sizeof(uint64_t) * sz); m->v = xmalloc(sizeof(int) * sz); m->used = xcalloc(sz, 1);
}
static void map_free(Map *m) { free(m->k); free(m->v); free(m->used); }
static void map_grow(Map *m);
static int *map_slot(Map *m, uint64_t key, int create) {
    uint64_t i = mix64(key) & m->mask;
    while (m->used[i]) {
        if (m->k[i] == key) return &m->v[i];
        i = (i + 1) & m->mask;
    }
    if (!create) return NULL;
    if ((m->n + 1) * 2 > m->mask) { map_grow(m); return map_slot(m, key, create); }
    m->used[i] = 1; m->k[i] = key; m->v[i] = -1; m->n++;
    return &m->v[i];
}
static void map_grow(Map *m) {
    Map o = *m;
    uint64_t sz = (o.mask + 1) * 2;
    m->mask = sz - 1; m->n = 0;
    m->k = xmalloc(sizeof(uint64_t) * sz); m->v = xmalloc(sizeof(int) * sz); m->used = xcalloc(sz, 1);
    for (uint64_t i = 0; i <= o.mask; i++)
        if (o.used[i]) *map_slot(m, o.k[i], 1) = o.v[i];
    map_free(&o);
}

/* memo: content pair -> similarity (0 = not a clone) */
typedef struct { uint64_t a1, a2, b1, b2; int v; } MemoE;
typedef struct { MemoE *e; uint8_t *used; uint64_t mask; size_t n; } Memo;
static Memo memo;

static void memo_init(size_t expect) {
    uint64_t sz = 1024; while (sz < expect * 2 + 1024) sz <<= 1;
    memo.mask = sz - 1; memo.n = 0; memo.e = xmalloc(sizeof(MemoE) * sz); memo.used = xcalloc(sz, 1);
}
static uint64_t memo_h(uint64_t a1, uint64_t a2, uint64_t b1, uint64_t b2) {
    return mix64(a1 ^ mix64(a2 ^ mix64(b1 ^ (b2 * 31))));
}
static MemoE *memo_get(uint64_t a1, uint64_t a2, uint64_t b1, uint64_t b2) {
    uint64_t i = memo_h(a1, a2, b1, b2) & memo.mask;
    while (memo.used[i]) {
        MemoE *e = &memo.e[i];
        if (e->a1 == a1 && e->a2 == a2 && e->b1 == b1 && e->b2 == b2) return e;
        i = (i + 1) & memo.mask;
    }
    return NULL;
}
static void memo_put(uint64_t a1, uint64_t a2, uint64_t b1, uint64_t b2, int v) {
    if ((memo.n + 1) * 2 > memo.mask) {
        Memo o = memo; uint64_t sz = (o.mask + 1) * 2;
        memo.mask = sz - 1; memo.n = 0; memo.e = xmalloc(sizeof(MemoE) * sz); memo.used = xcalloc(sz, 1);
        for (uint64_t i = 0; i <= o.mask; i++)
            if (o.used[i]) memo_put(o.e[i].a1, o.e[i].a2, o.e[i].b1, o.e[i].b2, o.e[i].v);
        free(o.e); free(o.used);
    }
    uint64_t i = memo_h(a1, a2, b1, b2) & memo.mask;
    while (memo.used[i]) {
        MemoE *e = &memo.e[i];
        if (e->a1 == a1 && e->a2 == a2 && e->b1 == b1 && e->b2 == b2) { e->v = v; return; }
        i = (i + 1) & memo.mask;
    }
    memo.used[i] = 1; memo.e[i] = (MemoE){ a1, a2, b1, b2, v }; memo.n++;
}

static long st_lcs = 0, st_memo = 0;

/* clone decision for two fragments that passed the size window and the embedding test */
static int decide_nearmiss(const Frag *c, const Frag *d, double t, int thr_pct) {
    const Frag *big = c, *small = d;
    if (d->nl > c->nl) { big = d; small = c; }
    uint64_t a1 = big->h1, a2 = big->h2, b1 = small->h1, b2 = small->h2;
    if (big->nl == small->nl && (a1 > b1 || (a1 == b1 && a2 > b2))) {     /* symmetric: canonical order */
        uint64_t x1 = a1, x2 = a2; a1 = b1; a2 = b2; b1 = x1; b2 = x2;
    }
    MemoE *me = memo_get(a1, a2, b1, b2);
    if (me) { st_memo++; return me->v; }
    int l = lcs_len(big->ids, big->nl, small->ids, small->nl);
    st_lcs++;
    int v = nearmiss_value(big->nl, small->nl, t, thr_pct, l);
    memo_put(a1, a2, b1, b2, v);
    return v;
}

/* ------------------------------------------------------------------------- */
/* old + new blocks -> one potential-clones stream, optionally in extraction order */
/* ------------------------------------------------------------------------- */
typedef struct { const char *p; size_t n; const char *file; size_t fl; int isnew; long pos; } Block;
static Block *BL = NULL; static long NB = 0, BCAP = 0;

static char *slurp(const char *path, size_t *n) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "*** Error: cannot open %s\n", path); exit(1); }
    size_t cap = 1 << 20, len = 0; char *b = xmalloc(cap);
    for (;;) {
        if (len == cap) { cap *= 2; b = xrealloc(b, cap); }
        size_t r = fread(b + len, 1, cap - len, f);
        if (r == 0) break;
        len += r;
    }
    fclose(f);
    *n = len;
    return b;
}

static void split_blocks(const char *buf, size_t n, int isnew) {
    size_t i = 0;
    while (i < n) {
        size_t e = i; while (e < n && buf[e] != '\n') e++;          /* line [i, e) */
        if (e - i >= 8 && memcmp(buf + i, "<source ", 8) == 0) {
            size_t start = i, j = e < n ? e + 1 : e;
            for (;;) {                                              /* up to </source> */
                if (j >= n) die("synchronization error on pc file (missing </source>)");
                size_t k = j; while (k < n && buf[k] != '\n') k++;
                int endl = (k - j >= 9 && memcmp(buf + j, "</source>", 9) == 0);
                j = k < n ? k + 1 : k;
                if (endl) break;
            }
            if (NB == BCAP) { BCAP = BCAP ? BCAP * 2 : 4096; BL = xrealloc(BL, sizeof(Block) * BCAP); }
            Block *b = &BL[NB];
            b->p = buf + start; b->n = j - start; b->isnew = isnew; b->pos = NB; NB++;
            const char *a = memmem(buf + start, e - start, "file=\"", 6);
            const char *q = a ? memmem(a + 6, e - (size_t)(a + 6 - buf), "\" startline=\"", 13) : NULL;
            if (!a || !q) die("cannot parse pc header");
            b->file = a + 6; b->fl = (size_t)(q - (a + 6));
            i = j;
        } else {
            if (e - i > 0) die("synchronization error on pc file");
            i = e < n ? e + 1 : e;
        }
    }
}

/* file order: path -> rank (from --order: one path per line, as in the headers) */
static Map ORD; static int have_order = 0;
static long order_of(const Block *b) {
    if (!have_order) return 0;
    int *v = map_slot(&ORD, fnv64(b->file, b->fl, 14695981039346656037ULL), 0);
    return v ? *v : 0x7fffffff;
}
static int cmp_block(const void *x, const void *y) {
    const Block *a = x, *b = y;
    long oa = order_of(a), ob = order_of(b);
    if (oa != ob) return oa < ob ? -1 : 1;
    return (a->pos > b->pos) - (a->pos < b->pos);                /* stable */
}

/* ------------------------------------------------------------------------- */
/* clone pairs                                                               */
/* ------------------------------------------------------------------------- */
typedef struct { int pc1, pc2; int sim; int cpn; int cached; int pruned; } Pair;
static Pair *P = NULL; static int NP = 0, PCAP = 0;

static void add_pair(int a, int b, int sim, int cached) {
    if (NP == PCAP) { PCAP = PCAP ? PCAP * 2 : 1024; P = xrealloc(P, sizeof(Pair) * PCAP); }
    P[NP++] = (Pair){ a, b, sim, 0, cached, 0 };
}

static int cmp_generation(const void *pa, const void *pb) {   /* order in which findclones finds them */
    const Pair *p = pa, *q = pb;
    if (F[p->pc1].rank != F[q->pc1].rank) return F[p->pc1].rank - F[q->pc1].rank;
    return F[p->pc2].rank - F[q->pc2].rank;
}

static int *prune_pos = NULL;
static int cmp_prune_group(const void *pa, const void *pb) {  /* (pc1 file, pc2 file, position) */
    int x = *(const int *)pa, y = *(const int *)pb;
    const Pair *p = &P[x], *q = &P[y];
    if (F[p->pc1].fln != F[q->pc1].fln) return F[p->pc1].fln < F[q->pc1].fln ? -1 : 1;
    if (F[p->pc2].fln != F[q->pc2].fln) return F[p->pc2].fln < F[q->pc2].fln ? -1 : 1;
    return prune_pos[x] - prune_pos[y];
}

/* ------------------------------------------------------------------------- */
/* output (format of clonepairs.x)                                           */
/* ------------------------------------------------------------------------- */
static void system_and_granularity(const char *pcfile, char *sys, char *gran) {
    const char *s = strrchr(pcfile, '/');
    const char *bs = strrchr(pcfile, '\\');
    if (bs && (!s || bs > s)) s = bs;
    const char *info = s ? s + 1 : pcfile;
    int L = (int)strlen(info), us = L;
    while (us > 0 && !(us == 2 || (us >= 1 && info[us - 1] == '_'))) us--;
    snprintf(sys, 4096, "%.*s", us > 1 ? us - 1 : 0, info);
    const char *x = strstr(info, ".xml");
    int ge = x ? (int)(x - info) : L;
    snprintf(gran, 4096, "%.*s", ge > us ? ge - us : 0, info + us);
}

static void write_output(const char *pcfile, double t, int minl, int maxl, int showsource, long nout, long long ncompares) {
    static char sys[4096], gran[4096];
    system_and_granularity(pcfile, sys, gran);
    FILE *o = stdout;
    static char obuf[1 << 20];
    setvbuf(o, obuf, _IOFBF, sizeof obuf);
    fprintf(o, "<clones>\n");
    fprintf(o, "<systeminfo processor=\"nicad6\" system=\"%s\" granularity=\"%s\" threshold=\"%d%%\" minlines=\"%d\" maxlines=\"%d\"/>\n",
            sys, gran, tround(t * 100 + EPS), minl, maxl);
    fprintf(o, "<cloneinfo npcs=\"%d\" npairs=\"%ld\"/>\n", NF, nout);
    fprintf(o, "<runinfo ncompares=\"%lld\" cputime=\"%ld\"/>\n", ncompares, (long)(clock() * 1000.0 / CLOCKS_PER_SEC));
    fprintf(o, "\n");
    for (int i = 0; i < NP; i++) {
        Pair *p = &P[i];
        if (p->pruned) continue;
        fprintf(o, "<clone nlines=\"%d\" similarity=\"%d\">\n", p->cpn, p->sim);
        const Frag *fs[2] = { &F[p->pc1], &F[p->pc2] };
        for (int k = 0; k < 2; k++) {
            const Frag *f = fs[k];
            size_t hl = strlen(f->header);
            fwrite(f->header, 1, hl ? hl - 1 : 0, o);
            fprintf(o, " pcid=\"%d\">", f->num);
            if (showsource) {
                fputc('\n', o);
                for (int j = 0; j < f->nl; j++) { fwrite(LT.str[f->ids[j]], 1, LT.len[f->ids[j]], o); fputc('\n', o); }
            }
            fprintf(o, "</source>\n");
        }
        fprintf(o, "</clone>\n\n");
    }
    fprintf(o, "</clones>\n");
    fflush(o);
}

/* ------------------------------------------------------------------------- */
/* main                                                                      */
/* ------------------------------------------------------------------------- */
static void usage(void) {
    fprintf(stderr,
        "Usage :  clonepairs_rev.x old.xml new.xml prev-pairs.xml threshold [minsize] [maxsize] [showsource]\n"
        "                       [--name rN_gran.xml] [--allpairs next-pairs.xml] [--relabel FROM TO]\n"
        "                       [--stats file] [--round trunc|nearest] [--quiet]  > clones.xml\n"
        "         clonepairs_rev.x --full pcfile.xml threshold [minsize] [maxsize] [showsource] [--allpairs file] ...\n");
    exit(1);
}

/* key of a fragment: file, startline, endline */
static uint64_t frag_key(const char *file, size_t fl, int st, int en) {
    uint64_t h = fnv64(file, fl, 14695981039346656037ULL);
    int v[2] = { st, en };
    return mix64(fnv64(v, sizeof v, h));
}

int main(int argc, char **argv) {
    const char *args[10]; int na = 0, full = 0;
    const char *stats_file = NULL, *allpairs_file = NULL, *name = NULL, *rel_from = NULL, *rel_to = NULL;
    const char *order_file = NULL, *merged_out = NULL;
    const char *rm = getenv("NICADPP_ROUND");
    if (rm && strcmp(rm, "nearest") == 0) round_nearest = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--full") == 0) full = 1;
        else if (strcmp(argv[i], "--quiet") == 0) quiet = 1;
        else if (strcmp(argv[i], "--round") == 0 && i + 1 < argc) {
            i++;
            if (strcmp(argv[i], "nearest") == 0) round_nearest = 1;
            else if (strcmp(argv[i], "trunc") == 0) round_nearest = 0;
            else usage();
        }
        else if (strcmp(argv[i], "--stats") == 0 && i + 1 < argc) stats_file = argv[++i];
        else if (strcmp(argv[i], "--allpairs") == 0 && i + 1 < argc) allpairs_file = argv[++i];
        else if (strcmp(argv[i], "--name") == 0 && i + 1 < argc) name = argv[++i];
        else if (strcmp(argv[i], "--order") == 0 && i + 1 < argc) order_file = argv[++i];
        else if (strcmp(argv[i], "--merged-out") == 0 && i + 1 < argc) merged_out = argv[++i];
        else if (strcmp(argv[i], "--relabel") == 0 && i + 2 < argc) { rel_from = argv[i + 1]; rel_to = argv[i + 2]; i += 2; }
        else if (na < 10) args[na++] = argv[i];
        else usage();
    }
    const char *oldfile = NULL, *newfile = NULL, *prevfile = NULL;
    int ai;
    if (full) { if (na < 2) usage(); newfile = args[0]; ai = 1; }
    else { if (na < 4) usage(); oldfile = args[0]; newfile = args[1]; prevfile = args[2]; ai = 3; }
    double t = strtod(args[ai], NULL);
    int minl = na > ai + 1 ? atoi(args[ai + 1]) : 5;
    int maxl = na > ai + 2 ? atoi(args[ai + 2]) : 2500;
    int showsource = na > ai + 3;
    if (t < 0.0 || t > 1.0 || minl < 1 || minl > 100 || maxl < minl || maxl > 20000) usage();
    if (!name) name = full ? newfile : newfile;

    clock_t c0 = clock();
    int exact_mode = (t + EPS) < 0.01;
    int thr_pct = tround(t * 100 + EPS);

    /* ---- read old, then new: same as reading the file old + new ---------------- */
    lt_init();
    NT = xcalloc(NT_SIZE, sizeof(int32_t));   /* zero pages on demand: no fixed cost */
    NT[0] = -1;                            /* slot 0 is taken in clonepairs.x's table */
    size_t on = 0, nn = 0;
    char *obuf = oldfile ? slurp(oldfile, &on) : NULL;
    char *nbuf = slurp(newfile, &nn);
    if (obuf) split_blocks(obuf, on, 0);
    split_blocks(nbuf, nn, 1);
    if (order_file) {                      /* same order as the extraction of the revision */
        size_t ln = 0; char *lb = slurp(order_file, &ln);
        map_init(&ORD, 1024); have_order = 1;
        long rank = 0; size_t i = 0;
        while (i < ln) {
            size_t e = i; while (e < ln && lb[e] != '\n') e++;
            size_t l = e - i; if (l && lb[i + l - 1] == '\r') l--;
            if (l) { int *v = map_slot(&ORD, fnv64(lb + i, l, 14695981039346656037ULL), 1); if (*v == -1) *v = (int)rank++; }
            i = e + 1;
        }
        qsort(BL, (size_t)NB, sizeof(Block), cmp_block);
    }
    /* one stream old + new (reordered): exactly what the revision's pc file contains */
    size_t tot = 0;
    for (long b = 0; b < NB; b++) tot += BL[b].n;
    char *all = xmalloc(tot + 1); size_t off = 0;
    for (long b = 0; b < NB; b++) { memcpy(all + off, BL[b].p, BL[b].n); off += BL[b].n; }
    if (merged_out) {
        FILE *mf = fopen(merged_out, "wb");
        if (!mf || fwrite(all, 1, tot, mf) != tot || fclose(mf) != 0) die("cannot write --merged-out file");
    }
    FILE *sf0 = fmemopen(all, tot ? tot : 1, "rb");
    if (!sf0) die("fmemopen failed");
    if (tot) read_pcs_fp(sf0, minl, maxl);
    fclose(sf0);
    if (NF != NB) die("block count mismatch");
    int K = 0;                             /* number of old fragments */
    for (long b = 0; b < NB; b++) if (!BL[b].isnew) K++;
    free(NT); NT = NULL;
    pm_stamp = xcalloc((size_t)LT.n + 1, sizeof(int));
    pm_slot = xmalloc(sizeof(int) * ((size_t)LT.n + 1));
    for (int i = 0; i < NF; i++) F[i].changed = full || BL[i].isnew;

    /* ---- sortpcs: ranks ------------------------------------------------------------ */
    int *sorted = xmalloc(sizeof(int) * ((size_t)NF + 1));
    uint64_t *nlkey = xmalloc(sizeof(uint64_t) * cnt(NF));
    for (int i = 0; i < NF; i++) { sorted[i + 1] = i; nlkey[i] = (uint64_t)F[i].nl; }
    tl_quicksort(sorted, NF, nlkey);
    for (int k = 1; k <= NF; k++) F[sorted[k]].rank = k;
    free(nlkey);

    /* comparisons clonepairs.x makes on old + new (size window), and those among old ones */
    long long cmp_all = 0, cmp_old = 0;
    {
        int *oldpos = xmalloc(sizeof(int) * ((size_t)NF + 2));
        oldpos[0] = 0;
        for (int k = 1; k <= NF; k++) oldpos[k] = oldpos[k - 1] + !F[sorted[k]].changed;
        for (int k = 1; k <= NF; k++) {
            int nl = F[sorted[k]].nl;
            if (!nl) break;
            int bound = nl - tround(nl * t + EPS);
            if (bound < 1) bound = 1;
            int lo = k, hi = NF;               /* last position with nl >= bound */
            while (lo < hi) {
                int mid = lo + (hi - lo + 1) / 2;
                if (F[sorted[mid]].nl >= bound) lo = mid; else hi = mid - 1;
            }
            cmp_all += lo - k;
            if (!F[sorted[k]].changed) cmp_old += oldpos[lo] - oldpos[k];
        }
        free(oldpos);
    }
    long long ncompares = cmp_all - cmp_old;

    int nact = 0, nold = 0, nnew = 0;
    for (int i = 0; i < NF; i++) if (F[i].nl) { nact++; if (F[i].changed) nnew++; else nold++; }

    /* ---- decisions between old fragments: from prev-pairs.xml ------------------------ */
    long d_prev = 0, d_kept = 0, d_dropped = 0, d_redecide = 0; int fallback = 0;
    memo_init(1024);
    if (!full && K > 0 && !(prevfile[0] == '-' && prevfile[1] == 0)) {
        Map om; map_init(&om, (size_t)K);
        for (int i = 0; i < NF; i++) {
            if (F[i].changed) continue;
            int *sl = map_slot(&om, frag_key(F[i].file, strlen(F[i].file), F[i].start, F[i].end), 1);
            if (*sl == -1) *sl = i;
            else fallback = 1;                /* two old fragments with the same file and lines */
        }
        size_t rfl = rel_from ? strlen(rel_from) : 0, rtl = rel_to ? strlen(rel_to) : 0;
        FILE *pf = fallback ? NULL : fopen(prevfile, "rb");
        if (!fallback && !pf) fallback = 2;
        if (pf) {
            char *buf = NULL, *path = NULL; size_t cap = 0, pcap = 0; ssize_t len;
            int state = 0, sim = 0, nlines = 0, got = 0, idx[2] = { -1, -1 };
            while ((len = getline(&buf, &cap, pf)) != -1) {
                if (len > 0 && buf[len - 1] == '\n') buf[--len] = 0;
                if (strncmp(buf, "<clone ", 7) == 0) {
                    char *a = strstr(buf, "nlines=\""), *b = strstr(buf, "similarity=\"");
                    if (!a || !b) { fallback = 3; break; }
                    nlines = atoi(a + 8); sim = atoi(b + 12);
                    state = 1; got = 0; idx[0] = idx[1] = -1;
                } else if (state == 1 && strncmp(buf, "<source ", 8) == 0 && got < 2) {
                    char *a = strstr(buf, "file=\"");
                    char *b = a ? strstr(a + 6, "\" startline=\"") : NULL;
                    char *e = b ? strstr(b, "endline=\"") : NULL;
                    if (!a || !b || !e) { fallback = 3; break; }
                    const char *fp = a + 6; size_t fl = (size_t)(b - fp);
                    if (rel_from && fl >= rfl && memcmp(fp, rel_from, rfl) == 0) {    /* r1/ -> r2/ */
                        if (fl - rfl + rtl + 1 > pcap) { pcap = fl - rfl + rtl + 64; path = xrealloc(path, pcap); }
                        memcpy(path, rel_to, rtl); memcpy(path + rtl, fp + rfl, fl - rfl);
                        fl = fl - rfl + rtl; fp = path;
                    }
                    int st = atoi(b + 13), en = atoi(e + 9);
                    int *sl = map_slot(&om, frag_key(fp, fl, st, en), 0);
                    int fi = -1;
                    if (sl && *sl >= 0) {
                        const Frag *o = &F[*sl];
                        if (o->start == st && o->end == en && strlen(o->file) == fl && memcmp(o->file, fp, fl) == 0) fi = *sl;
                    }
                    idx[got++] = fi;
                } else if (state == 1 && strncmp(buf, "</clone>", 8) == 0) {
                    state = 0;
                    if (got != 2) { fallback = 3; break; }
                    d_prev++;
                    if (idx[0] >= 0 && idx[1] >= 0 && F[idx[0]].nl && F[idx[1]].nl) {
                        if ((F[idx[0]].nom + F[idx[1]].nom + 1) / 2 != nlines) { fallback = 4; break; }
                        if (!exact_mode && order_dependent(&F[idx[0]], &F[idx[1]])) d_redecide++;
                        else { add_pair(idx[0], idx[1], sim, 2); d_kept++; }
                    } else d_dropped++;       /* a fragment was deleted or changed */
                }
            }
            free(buf); free(path); fclose(pf);
        }
        map_free(&om);
        if (fallback) {
            static const char *why[] = { "", "two old fragments with the same file and lines",
                "cannot open the previous pairs file", "cannot parse the previous pairs file",
                "previous pairs do not match the old fragments (other minsize/maxsize?)" };
            fprintf(stderr, "[clonepairs_rev] cannot use %s (%s) - comparing all fragments\n", prevfile, why[fallback]);
            NP = 0; d_kept = d_dropped = d_redecide = 0;
            for (int i = 0; i < NF; i++) F[i].changed = 1;
            nnew = nact; nold = 0;
            ncompares = cmp_all;
        }
    } else if (!full && K > 0) {
        /* no previous pairs: all fragments must be compared */
        for (int i = 0; i < NF; i++) F[i].changed = 1;
        nnew = nact; nold = 0; ncompares = cmp_all;
    }

    long ncand = 0, nbound = 0, norder = 0;
    if (exact_mode) {
        /* ---- threshold 0: identical fragments, grouped by content hash --------------- */
        Map grp; map_init(&grp, (size_t)nact);
        int *next = xmalloc(sizeof(int) * cnt(NF));
        for (int i = NF - 1; i >= 0; i--) {
            if (!F[i].nl) continue;
            int *s = map_slot(&grp, F[i].h1 ^ mix64(F[i].h2), 1);
            next[i] = *s; *s = i;
        }
        for (uint64_t g = 0; g <= grp.mask; g++) {
            if (!grp.used[g]) continue;
            for (int i = grp.v[g]; i >= 0; i = next[i])
                for (int j = next[i]; j >= 0; j = next[j]) {
                    if (!F[i].changed && !F[j].changed) continue;       /* old x old: from prev pairs */
                    ncand++;
                    if (F[i].nl == F[j].nl && memcmp(F[i].ids, F[j].ids, sizeof(int) * F[i].nl) == 0)
                        add_pair(i, j, 100, 0);
                }
        }
        free(next); map_free(&grp);
    } else {
        /* ---- new x (old + new) ------------------------------------------------------- */
        int *tau = xmalloc(sizeof(int) * cnt(NF));
        for (int i = 0; i < NF; i++) tau[i] = F[i].nl ? tau_of(F[i].nl, t) : 0;
        if (nnew) {
            int nids = LT.n;
            int *df = xcalloc((size_t)nids + 1, sizeof(int));
            for (int i = 0; i < NF; i++)
                for (int j = 0; j < F[i].nl; j++)
                    if (j == 0 || F[i].sids[j] != F[i].sids[j - 1]) df[F[i].sids[j]]++;
            long *off = xmalloc(sizeof(long) * ((size_t)nids + 1));
            off[0] = 0;
            for (int x = 0; x < nids; x++) off[x + 1] = off[x] + df[x];
            int *post = xmalloc(sizeof(int) * cnt(off[nids]));
            long *fill = xcalloc((size_t)nids + 1, sizeof(long));
            for (int i = 0; i < NF; i++)
                for (int j = 0; j < F[i].nl; j++)
                    if (j == 0 || F[i].sids[j] != F[i].sids[j - 1]) {
                        int x = F[i].sids[j];
                        post[off[x] + fill[x]++] = i;
                    }
            free(fill);
            int *seen = xmalloc(sizeof(int) * cnt(NF));
            for (int i = 0; i < NF; i++) seen[i] = -1;
            int *order = NULL, ocap = 0;
            DF = df;
            for (int ci = 0; ci < NF; ci++) {
                Frag *c = &F[ci];
                if (!c->nl || !c->changed) continue;
                int n = c->nl, tc = tau[ci];
                if (tc > n) continue;
                if (n > ocap) { ocap = n * 2; order = xrealloc(order, sizeof(int) * ocap); }
                memcpy(order, c->ids, sizeof(int) * n);
                qsort(order, (size_t)n, sizeof(int), cmp_rarity);     /* rarest lines first */
                int plen = (tc <= 0) ? n : n - tc + 1;
                for (int pi = 0; pi < plen; pi++) {
                    int x = order[pi];
                    if (pi > 0 && order[pi - 1] == x) continue;
                    for (long q = off[x]; q < off[x + 1]; q++) {
                        int di = post[q];
                        if (di == ci || seen[di] == ci) continue;
                        seen[di] = ci;
                        Frag *d = &F[di];
                        if (d->changed && d->num < c->num) continue;     /* new x new: once */
                        int big_n = n > d->nl ? n : d->nl, small_n = n > d->nl ? d->nl : n;
                        if (small_n < big_n - tround(big_n * t + EPS)) continue;   /* size window */
                        if (order_dependent(c, d)) continue;                   /* below */
                        ncand++;
                        if (n > d->nl ? inside(d, c) : inside(c, d)) continue; /* embedded: not a clone */
                        int sh = shared_lines(c, d);
                        if (sh < tc || sh < tau[di]) { nbound++; continue; }
                        int v = decide_nearmiss(c, d, t, thr_pct);
                        if (v) add_pair(ci, di, v, 0);
                    }
                }
            }
            free(df); free(off); free(post); free(seen); free(order);
        }
        /* ---- nested fragments of one file with the same size: decided on every run,
                with pc1 = the fragment sortpcs puts first, as clonepairs.x does -------- */
        int *byf = xmalloc(sizeof(int) * cnt(NF)); int nb = 0;
        for (int i = 0; i < NF; i++) if (F[i].nl) byf[nb++] = i;
        Map gm; map_init(&gm, (size_t)nb);
        int *gnext = xmalloc(sizeof(int) * cnt(NF));
        for (int k = nb - 1; k >= 0; k--) {
            int i = byf[k];
            int *s = map_slot(&gm, ((uint64_t)(uint32_t)F[i].fln << 32) | (uint32_t)F[i].nl, 1);
            gnext[i] = *s; *s = i;
        }
        for (uint64_t g = 0; g <= gm.mask; g++) {
            if (!gm.used[g]) continue;
            for (int i = gm.v[g]; i >= 0; i = gnext[i])
                for (int j = gnext[i]; j >= 0; j = gnext[j]) {
                    const Frag *a = &F[i], *b = &F[j];
                    if (!(inside(a, b) || inside(b, a))) continue;
                    const Frag *p1 = a->rank < b->rank ? a : b, *p2 = a->rank < b->rank ? b : a;
                    norder++;
                    if (inside(p2, p1)) continue;              /* nearmiss(): embedded -> 0 */
                    int v = decide_nearmiss(p1, p2, t, thr_pct);
                    if (v) add_pair(i, j, v, 0);
                }
        }
        map_free(&gm); free(gnext); free(byf); free(tau);
    }

    /* ---- findclones order and orientation ------------------------------------------ */
    for (int i = 0; i < NP; i++) {
        if (F[P[i].pc1].rank > F[P[i].pc2].rank) { int x = P[i].pc1; P[i].pc1 = P[i].pc2; P[i].pc2 = x; }
        P[i].cpn = (F[P[i].pc1].nom + F[P[i].pc2].nom + 1) / 2;
    }
    qsort(P, (size_t)NP, sizeof(Pair), cmp_generation);

    /* all clone pairs before pruning: prev-pairs.xml of the next revision */
    if (allpairs_file) {
        FILE *af = fopen(allpairs_file, "wb");
        if (!af) die("cannot write the --allpairs file");
        fprintf(af, "<clones>\n<allpairs npcs=\"%d\" npairs=\"%d\"/>\n\n", NF, NP);
        for (int i = 0; i < NP; i++) {
            fprintf(af, "<clone nlines=\"%d\" similarity=\"%d\">\n", P[i].cpn, P[i].sim);
            const Frag *fs[2] = { &F[P[i].pc1], &F[P[i].pc2] };
            for (int k = 0; k < 2; k++) {
                size_t hl = strlen(fs[k]->header);
                fwrite(fs[k]->header, 1, hl ? hl - 1 : 0, af);
                fprintf(af, " pcid=\"%d\"></source>\n", fs[k]->num);
            }
            fprintf(af, "</clone>\n\n");
        }
        fprintf(af, "</clones>\n");
        if (fclose(af) != 0) die("cannot write the --allpairs file");
    }

    /* ---- pruneembeddedpairs (exactly as clonepairs.x, over all pairs) ---------------- */
    for (int i = 0; i < NP; i++) {
        const Frag *a = &F[P[i].pc1], *b = &F[P[i].pc2];
        if (a->fln > b->fln || (a->fln == b->fln && a->start > b->start)) {
            int x = P[i].pc1; P[i].pc1 = P[i].pc2; P[i].pc2 = x;
        }
    }
    int *cmap = xmalloc(sizeof(int) * ((size_t)NP + 1));
    uint64_t *pkey = xmalloc(sizeof(uint64_t) * cnt(NP));
    for (int i = 0; i < NP; i++) {
        cmap[i + 1] = i;
        pkey[i] = ((uint64_t)(uint32_t)F[P[i].pc1].fln << 32) | (uint32_t)P[i].cpn;
    }
    tl_quicksort(cmap, NP, pkey);
    prune_pos = xmalloc(sizeof(int) * cnt(NP));
    for (int k = 1; k <= NP; k++) prune_pos[cmap[k]] = k;
    /* clonepairs.x walks this order from the end; a pair is pruned if a pair before it with
       the same pc1 file and the same pc2 file contains it. Same result, per file pair: */
    int *gidx = xmalloc(sizeof(int) * cnt(NP));
    for (int i = 0; i < NP; i++) gidx[i] = i;
    qsort(gidx, (size_t)NP, sizeof(int), cmp_prune_group);
    long npruned = 0;
    for (int g0 = 0; g0 < NP;) {
        int g1 = g0 + 1;
        while (g1 < NP && F[P[gidx[g1]].pc1].fln == F[P[gidx[g0]].pc1].fln &&
               F[P[gidx[g1]].pc2].fln == F[P[gidx[g0]].pc2].fln) g1++;
        for (int k = g0 + 1; k < g1; k++) {
            Pair *cp = &P[gidx[k]];
            const Frag *p1 = &F[cp->pc1], *p2 = &F[cp->pc2];
            for (int m = g0; m < k; m++) {
                const Pair *bp = &P[gidx[m]];
                const Frag *b1 = &F[bp->pc1], *b2 = &F[bp->pc2];
                if (b1->start <= p1->start && b1->end >= p1->end && b2->start <= p2->start && b2->end >= p2->end) {
                    cp->pruned = 1; npruned++; break;
                }
            }
        }
        g0 = g1;
    }
    free(gidx); free(cmap); free(pkey); free(prune_pos);

    /* ---- output ------------------------------------------------------------------------ */
    write_output(name, t, minl, maxl, showsource, (long)(NP - npruned), ncompares);

    double secs = (double)(clock() - c0) / CLOCKS_PER_SEC;
    if (stats_file) {
        FILE *sf = fopen(stats_file, "w");
        if (sf) {
            fprintf(sf, "pcs=%d\nactive=%d\nold_blocks=%d\nnew_blocks=%d\n", NF, nact, nold, nnew);
            fprintf(sf, "prev_allpairs=%ld\nkept_decisions=%ld\ndropped_decisions=%ld\nredecided=%ld\n",
                    d_prev, d_kept, d_dropped, d_redecide);
            fprintf(sf, "allpairs=%d\nnew_decisions=%ld\npruned=%ld\npairs=%ld\n", NP, (long)(NP - d_kept), npruned, (long)(NP - npruned));
            fprintf(sf, "compares_full=%lld\ncompares=%lld\nexamined=%ld\nbound_rejected=%ld\nlcs=%ld\nmemo=%ld\n",
                    cmp_all, ncompares, ncand + norder, nbound, st_lcs, st_memo);
            fprintf(sf, "fallback=%d\nround=%s\ncpu_ms=%ld\n", fallback, round_nearest ? "nearest" : "trunc", (long)(secs * 1000));
            fclose(sf);
        }
    }
    if (!quiet)
        fprintf(stderr, "[clonepairs_rev] %d pcs (old %d, new %d); old x old decisions taken over %ld (dropped %ld); "
                        "comparisons %lld instead of %lld; LCS %ld; pairs %ld (pruned %ld); %.3fs\n",
                NF, nold, nnew, d_kept, d_dropped, ncompares, cmp_all, st_lcs, (long)(NP - npruned), npruned, secs);
    return 0;
}
