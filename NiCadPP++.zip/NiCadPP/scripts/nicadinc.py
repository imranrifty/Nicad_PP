#!/usr/bin/env python3
"""
nicadinc.py - file helpers for scripts/NiCadInc (incremental NiCad over revisions)

  prepare   one call per incremental revision: split + merge + relabel below, for all files
  finish    one call per revision: counts, pair differences, class-id tracking
  merge     old.xml + new.xml -> one file, blocks in extraction (file) order
  split     previous candidate file -> old.xml (unchanged files, relabeled r<P> -> r<N>)
                                     + copy.xml (blocks of copied files, as new blocks)
  mergepairs  previous revision's clone pairs + clone pairs of the new blocks (clonepairs2.x)
              -> clone pairs of the revision
  relabel   previous all-pairs file  -> paths r<P> -> r<N> (and renamed files)
  track     NiCad classes of r<N> + tracked classes of r<P> -> classes with stable ids
  pairdiff  clone pairs of r<P> vs r<N> (kept / added / removed)
  verify    incremental results vs full NiCad results, per revision

All files are read and written as bytes (no newline or encoding conversion), so the
script behaves the same with Cygwin and Windows Python.
"""
import argparse
import csv
import hashlib
import os
import re
import sys

SRC_RE = re.compile(rb'^<source file="(.*?)" startline="(-?\d+)" endline="(-?\d+)"')
CLASS_RE = re.compile(rb'^<class classid="(\d+)"(.*)$')


# ---------------------------------------------------------------------------
# path relabeling  systems/x/r<P>/path -> systems/x/r<N>/path
# ---------------------------------------------------------------------------
class Relabel(object):
    def __init__(self, sysbase, prev_rev, rev, rename_file=None):
        sb = sysbase.rstrip("/").encode("latin-1")
        self.old = sb + b"/r" + str(prev_rev).encode() + b"/"
        self.new = sb + b"/r" + str(rev).encode() + b"/"
        self.rename = {}
        if rename_file and os.path.exists(rename_file):
            for line in open(rename_file, "rb").read().splitlines():
                if b"\t" in line:
                    a, b = line.split(b"\t", 1)
                    self.rename[a] = b

    def rel(self, path):
        """path inside the revision, or None if it is not below r<P>/"""
        if path.startswith(self.old):
            return path[len(self.old):]
        return None

    def __call__(self, path):
        r = self.rel(path)
        if r is None:
            return path
        return self.new + self.rename.get(r, r)


def read_lines(path):
    if not path or not os.path.exists(path):
        return []
    return open(path, "rb").read().splitlines()


def read_set(path):
    return set(l for l in read_lines(path) if l)


BLOCK_RE = re.compile(rb'^(<source [^\n]*\n)(.*?^</source>[^\n]*(?:\n|\Z))', re.M | re.S)


def blocks(path):
    """yield (header, body_bytes) of a potential-clones file (whole file read at once)"""
    with open(path, "rb") as f:
        data = f.read()
    for m in BLOCK_RE.finditer(data):
        yield m.group(1), m.group(2)


def with_path(header, newpath):
    m = SRC_RE.match(header)
    return header[:m.start(1)] + newpath + header[m.end(1):]


# ---------------------------------------------------------------------------
def cmd_split(a):
    rl = Relabel(a.sysbase, a.prev_rev, a.rev, a.rename)
    purge = read_set(a.purge)
    copies = {}
    for line in read_lines(a.copy):
        if b"\t" in line:
            s, d = line.split(b"\t", 1)
            copies.setdefault(s, []).append(d)
    n_old = n_copy = n_drop = n_other = 0
    with open(a.old, "wb") as fo, open(a.copyout, "wb") as fc:
        for head, body in blocks(a.prev):
            m = SRC_RE.match(head)
            path = m.group(1)
            rel = rl.rel(path)
            if rel is None:
                n_other += 1
                continue
            if rel in copies:
                for d in copies[rel]:
                    fc.write(with_path(head, rl.new + d) + body)
                    n_copy += 1
            if rel in purge:
                n_drop += 1
                continue
            fo.write(with_path(head, rl(path)) + body)
            n_old += 1
    if n_other:
        sys.stderr.write("[nicadinc] warning: %d blocks of %s are not below %s\n"
                         % (n_other, a.prev, rl.old.decode("latin-1")))
    print("%d %d %d" % (n_old, n_copy, n_drop))


def cmd_merge(a):
    order = {}
    if a.order and os.path.exists(a.order):
        for i, l in enumerate(open(a.order, "rb").read().splitlines()):
            l = l.rstrip(b"\r")
            if l and l not in order:
                order[l] = i
    bl = []
    for f in a.inputs:
        for head, body in blocks(f):
            bl.append((order.get(SRC_RE.match(head).group(1), 1 << 40), len(bl), head + body))
    bl.sort(key=lambda x: (x[0], x[1]))
    with open(a.out, "wb") as fo:
        for _, _, b in bl:
            fo.write(b)
    print(len(bl))


def system_and_granularity(pcfile):
    info = os.path.basename(pcfile.replace("\\", "/"))
    us = len(info)
    while us > 0 and not (us == 2 or (us >= 1 and info[us - 1] == "_")):
        us -= 1
    system = info[:us - 1] if us > 1 else ""
    x = info.find(".xml")
    gran = info[us:x] if x >= 0 else info[us:]
    return system, gran


def read_pair_list(path, rl=None):
    """-> [(nlines, sim, key1, key2)] in file order, and the runinfo line"""
    out, cur, runinfo, sysinfo = [], None, b"", b""
    for line in open(path, "rb"):
        if line.startswith(b"<runinfo"):
            runinfo = line
        elif line.startswith(b"<systeminfo"):
            sysinfo = line
        elif line.startswith(b"<clone "):
            n = int(re.search(rb'nlines="(\d+)"', line).group(1))
            sim = int(re.search(rb'similarity="(\d+)"', line).group(1))
            cur = [n, sim, []]
        elif cur is not None and line.startswith(b"<source "):
            k = key_of(line)
            if rl is not None:
                k = (rl(k[0]), k[1], k[2])
            cur[2].append(k)
        elif cur is not None and line.startswith(b"</clone>"):
            if len(cur[2]) == 2:
                out.append((cur[0], cur[1], cur[2][0], cur[2][1]))
            cur = None
    return out, runinfo, sysinfo


def cmd_mergepairs(a):
    rl = Relabel(a.sysbase, a.prev_rev, a.rev, a.rename)
    heads, pcid = {}, {}
    for i, (head, body) in enumerate(blocks(a.pc)):
        k = key_of(head)
        heads[k] = head.rstrip(b"\r\n")
        pcid[k] = i + 1
    old = set(key_of(h) for h, _ in blocks(a.old)) if a.old else set()
    prev, _, _ = read_pair_list(a.prev, rl) if a.prev and os.path.exists(a.prev) else ([], b"", b"")
    new, runinfo, sysinfo = read_pair_list(a.delta)
    kept = [p for p in prev if p[2] in old and p[3] in old]         # both blocks unchanged
    for p in new:
        if p[2] not in pcid or p[3] not in pcid:
            sys.stderr.write("[nicadinc] block of a new pair not in %s\n" % a.pc)
            sys.exit(2)
    allp = []
    for n, sim, k1, k2 in kept + new:
        if pcid[k1] > pcid[k2]:
            k1, k2 = k2, k1
        allp.append((n, sim, k1, k2))
    allp.sort(key=lambda p: (-p[0], pcid[p[2]], pcid[p[3]]))      # re-sorted: size, then position
    system, gran = system_and_granularity(a.pc)
    thr = re.search(rb'threshold="(\d+)%"', sysinfo)
    mn = re.search(rb'minlines="(\d+)"', sysinfo)
    mx = re.search(rb'maxlines="(\d+)"', sysinfo)
    with open(a.out, "wb") as fo:
        fo.write(b"<clones>\n")
        fo.write(b'<systeminfo processor="nicad6" system="%s" granularity="%s" threshold="%s%%" minlines="%s" maxlines="%s"/>\n'
                 % (system.encode("latin-1"), gran.encode("latin-1"), thr.group(1), mn.group(1), mx.group(1)))
        fo.write(b'<cloneinfo npcs="%d" npairs="%d"/>\n' % (len(pcid), len(allp)))
        fo.write(runinfo if runinfo else b'<runinfo ncompares="0" cputime="0"/>\n')
        fo.write(b"\n")
        for n, sim, k1, k2 in allp:
            fo.write(b'<clone nlines="%d" similarity="%d">\n' % (n, sim))
            for k in (k1, k2):
                h = heads[k]
                fo.write(h[:-1] + b' pcid="%d"></source>\n' % pcid[k])
            fo.write(b"</clone>\n\n")
        fo.write(b"</clones>\n")
    print("pairs=%d kept=%d new=%d dropped=%d" % (len(allp), len(kept), len(new), len(prev) - len(kept)))


def cmd_relabel(a):
    rl = Relabel(a.sysbase, a.prev_rev, a.rev, a.rename)
    with open(a.inp, "rb") as fi, open(a.out, "wb") as fo:
        for line in fi:
            if line.startswith(b"<source "):
                m = SRC_RE.match(line)
                if m:
                    line = line[:m.start(1)] + rl(m.group(1)) + line[m.end(1):]
            fo.write(line)


# ---------------------------------------------------------------------------
# clone pairs / classes files
# ---------------------------------------------------------------------------
def key_of(line):
    m = SRC_RE.match(line)
    return (m.group(1), int(m.group(2)), int(m.group(3))) if m else None


def read_pairs(path, rl=None):
    out = set()
    if not path or not os.path.exists(path):
        return out
    cur = None
    for line in open(path, "rb"):
        if line.startswith(b"<clone "):
            cur = [line.strip(), []]
        elif cur is not None and line.startswith(b"<source "):
            k = key_of(line)
            if rl is not None:
                k = (rl(k[0]), k[1], k[2])
            cur[1].append(k)
        elif cur is not None and line.startswith(b"</clone>"):
            if len(cur[1]) == 2:
                sim = re.search(rb'similarity="(\d+)"', cur[0]).group(1)
                out.add((frozenset(cur[1]), int(sim)))
            cur = None
    return out


def read_classes(path):
    """-> header lines, list of [id, attr_bytes, [member lines]]"""
    header, classes, cur = [], [], None
    if not path or not os.path.exists(path):
        return header, classes
    for line in open(path, "rb"):
        if cur is None:
            m = CLASS_RE.match(line)
            if m:
                cur = [int(m.group(1)), m.group(2).rstrip(b"\r\n"), []]
            elif not line.startswith(b"</clones>") and line.strip():
                header.append(line)
        else:
            if line.startswith(b"</class>"):
                classes.append(cur)
                cur = None
            elif line.startswith(b"<source "):
                cur[2].append(line)
    return header, classes


def content_hashes(pcfile):
    """(path, start, end) -> hash of the normalized lines (for tracking moved blocks)"""
    h = {}
    if not pcfile or not os.path.exists(pcfile):
        return h
    for head, body in blocks(pcfile):
        k = key_of(head)
        h[k] = hashlib.sha1(body).digest()
    return h


def cmd_track(a):
    print(track(a))


def track(a):
    header, new = read_classes(a.nicad)
    have_prev = a.prev and os.path.exists(a.prev)
    nextid = 1
    if a.nextid_in and os.path.exists(a.nextid_in):
        nextid = int(open(a.nextid_in).read().split()[0])
    events = []
    if not have_prev:
        # first revision: NiCad's ids are the tracking ids
        out = [(c[0], c[1], c[2], "new", "") for c in new]
        nextid = max([nextid] + [c[0] + 1 for c in new])
        prev_ids = {}
    else:
        rl = Relabel(a.sysbase, a.prev_rev, a.rev, a.rename)
        _, prev = read_classes(a.prev)
        member_id = {}                                  # key in r<N> naming -> previous id
        prev_members = {}
        for cid, _, members in prev:
            ks = set()
            for line in members:
                p, s, e = key_of(line)
                k = (rl(p), s, e)
                member_id[k] = cid
                ks.add(k)
            prev_members[cid] = ks
        # fallback for blocks whose lines moved inside a changed file: same file + same content.
        # Only files that had class members before and now have unmatched blocks are hashed
        # (blocks of added files can never match), so usually no block file is read at all.
        prev_files = set(k[0] for k in member_id)
        need = set()
        for cid, attrs, members in new:
            for l in members:
                k = key_of(l)
                if k not in member_id and k[0] in prev_files:
                    need.add(k[0])
        fallback = None

        def hashes(pcfile, relabel):
            h = {}
            if not need or not pcfile or not os.path.exists(pcfile):
                return h
            for head, body in blocks(pcfile):
                p, st, en = key_of(head)
                if relabel:
                    p = rl(p)
                if p in need:
                    h[(p, st, en)] = hashlib.sha1(body).digest()
            return h

        def lookup(k):
            nonlocal fallback
            if k in member_id:
                return member_id[k]
            if k[0] not in need:
                return None
            if fallback is None:
                fallback = {}
                seen = {}
                for kk, dg in hashes(a.prev_pc, True).items():
                    if kk in member_id:
                        fk = (kk[0], dg)
                        seen[fk] = seen.get(fk, 0) + 1
                        fallback[fk] = member_id[kk]
                for fk, n in seen.items():             # ambiguous content: no fallback
                    if n > 1:
                        fallback.pop(fk, None)
                fallback["__cur__"] = hashes(a.pc, False)
            dg = fallback["__cur__"].get(k)
            if dg is None:
                return None
            return fallback.get((k[0], dg))

        cand = []
        for idx, (cid, attrs, members) in enumerate(new):
            keys = [key_of(l) for l in members]
            votes = {}
            for k in keys:
                pid = lookup(k)
                if pid is not None:
                    votes[pid] = votes.get(pid, 0) + 1
            cand.append((idx, keys, votes))
        # each previous id goes to the new class holding most of its members
        best = {}
        for idx, keys, votes in cand:
            for pid, n in votes.items():
                if pid not in best or n > best[pid][0] or (n == best[pid][0] and idx < best[pid][1]):
                    best[pid] = (n, idx)
        owner = {}                                     # new class idx -> kept id
        for pid, (n, idx) in sorted(best.items()):
            if idx not in owner:
                owner[idx] = pid
            else:
                # the class already keeps an id (merge): keep the one with more members, else smaller id
                cur = owner[idx]
                if (n, -pid) > (best[cur][0], -cur):
                    owner[idx] = pid
        out = []
        used = set()
        for idx, keys, votes in cand:
            cid, attrs, members = new[idx]
            ks = set(keys)
            if idx in owner:
                pid = owner[idx]
                used.add(pid)
                merged = sorted(p for p in votes if p != pid and best[p][1] == idx)
                old = prev_members.get(pid, set())
                added, removed = len(ks - old), len(old - ks)
                if merged:
                    status, info = "merged", "+".join(str(m) for m in merged)
                elif not added and not removed:
                    status, info = "unchanged", ""
                elif added and not removed:
                    status, info = "grown", "+%d" % added
                elif removed and not added:
                    status, info = "shrunk", "-%d" % removed
                else:
                    status, info = "changed", "+%d -%d" % (added, removed)
                out.append((pid, attrs, members, status, info))
            else:
                nid = nextid
                nextid += 1
                split_from = sorted(votes)
                if split_from:
                    out.append((nid, attrs, members, "split", "from " + "+".join(str(p) for p in split_from)))
                else:
                    out.append((nid, attrs, members, "new", ""))
        for pid in sorted(prev_members):
            if pid not in used:
                merged_into = [o[0] for o in out if o[3] == "merged" and str(pid) in o[4].split("+")]
                if merged_into:
                    events.append((pid, "merged-into", str(merged_into[0]), 0, len(prev_members[pid])))
                else:
                    events.append((pid, "removed", "", 0, len(prev_members[pid])))
        prev_ids = prev_members
    out.sort(key=lambda o: o[0])
    # write classes (NiCad format, stable ids, sorted by id)
    with open(a.out, "wb") as fo:
        for line in header:
            if line.startswith(b"<classinfo "):
                line = b'<classinfo nclasses="%d"/>\n' % len(out)
            fo.write(line)
        fo.write(b"\n")
        for cid, attrs, members, status, info in out:
            fo.write(b'<class classid="%d"%s\n' % (cid, attrs))
            for m in members:
                fo.write(m)
            fo.write(b"</class>\n\n")
        fo.write(b"</clones>\n")
    if a.nextid_out:
        open(a.nextid_out, "w").write("%d\n" % nextid)
    counts = {}
    for o in out:
        counts[o[3]] = counts.get(o[3], 0) + 1
    for e in events:
        counts[e[1]] = counts.get(e[1], 0) + 1
    if a.changes:
        with open(a.changes, "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["classid", "status", "detail", "nclones", "prev_nclones"])
            for cid, attrs, members, status, info in out:
                w.writerow([cid, status, info, len(members), len(prev_ids.get(cid, ())) if have_prev else ""])
            for pid, st, info, n, pn in events:
                w.writerow([pid, st, info, n, pn])
    nfr = sum(len(o[2]) for o in out)
    keys = ["new", "unchanged", "grown", "shrunk", "changed", "merged", "split", "removed", "merged-into"]
    return " ".join(["classes=%d" % len(out), "clones=%d" % nfr] + ["%s=%d" % (k.replace("-", "_"), counts.get(k, 0)) for k in keys])


def cmd_pairdiff(a):
    print(pairdiff(a.sysbase, a.prev_rev, a.rev, a.rename, a.prev, a.cur))


def pairdiff(sysbase, prev_rev, rev, rename, prevfile, curfile):
    cur = read_pairs(curfile)
    if not prevfile:
        return "pairs=%d kept=0 added=%d removed=0" % (len(cur), len(cur))
    rl = Relabel(sysbase, prev_rev, rev, rename)
    prev = read_pairs(prevfile, rl)
    pk = set(p for p, _ in prev)
    ck = set(p for p, _ in cur)
    return "pairs=%d kept=%d added=%d removed=%d" % (len(cur), len(pk & ck), len(ck - pk), len(pk - ck))


# ---------------------------------------------------------------------------
# prepare: everything NiCadInc needs between extraction and clone detection, in ONE
# process (a Python start costs 0.1-0.3 s on Windows / Cygwin):
#   previous blocks (raw and normalized) -> unchanged files, paths r<P>/ -> r<N>/
#   blocks of copied files, the revision's raw file (file order of NiCad's Extract),
#   the block files for the clone-pair program, previous pair files relabeled
# ---------------------------------------------------------------------------
def split_prev(prev, rl, purge, copies, old_out, replaced=frozenset(), fixes=None):
    """blocks of r<P> -> (old blocks relabeled [written to old_out], copy blocks [list]).
    replaced: files (path in r<N>) that have new blocks in this revision (extracted or copied):
    their previous blocks are dropped even if the change list missed them, and a block that
    appears twice (same file and lines) is kept once - a file never has its blocks twice."""
    n_old = n_drop = n_other = 0
    copy_blocks = []
    seen = set()
    exists = {}
    with open(old_out, "wb") as fo:
        if prev and os.path.exists(prev):
            for head, body in blocks(prev):
                m = SRC_RE.match(head)
                path = m.group(1)
                rel = rl.rel(path)
                if rel is None:
                    n_other += 1
                    continue
                if rel in copies:
                    for d in copies[rel]:
                        copy_blocks.append(with_path(head, rl.new + d) + body)
                if rel in purge:
                    n_drop += 1
                    continue
                newpath = rl(path)
                key = (newpath, m.group(2), m.group(3))
                if newpath not in exists:                  # the file must still be in r<N>
                    exists[newpath] = os.path.isfile(newpath.decode("utf-8", "surrogateescape"))
                if newpath in replaced or key in seen or not exists[newpath]:
                    n_drop += 1
                    if fixes is not None:
                        fixes[newpath] = fixes.get(newpath, 0) + 1
                    continue
                seen.add(key)
                fo.write(with_path(head, newpath) + body)
                n_old += 1
    if n_other:
        sys.stderr.write("[nicadinc] warning: %d blocks of %s are not below %s\n"
                         % (n_other, prev, rl.old.decode("latin-1")))
    return n_old, n_drop, copy_blocks


FOREIGN = [0]


def copy_dedup(src, fo, fixes, prefix=None):
    """copy the blocks of src to fo, each (file, lines) once (an extractor that lists a file
    twice must not give the revision its blocks twice); returns the number written.
    prefix: every block must be a file of r<N> (counted in FOREIGN otherwise)"""
    n = 0
    seen = set()
    if src and os.path.exists(src):
        for head, body in blocks(src):
            m = SRC_RE.match(head)
            if prefix is not None and not m.group(1).startswith(prefix):
                FOREIGN[0] += 1
            key = (m.group(1), m.group(2), m.group(3))
            if key in seen:
                if fixes is not None:
                    fixes[m.group(1)] = fixes.get(m.group(1), 0) + 1
                continue
            seen.add(key)
            fo.write(head + body)
            n += 1
    return n


def paths_of(pcfile):
    """file paths of the blocks of a potential-clones file (headers only)"""
    out = set()
    if pcfile and os.path.exists(pcfile):
        with open(pcfile, "rb") as f:
            for line in f:
                if line.startswith(b"<source "):
                    m = SRC_RE.match(line)
                    if m:
                        out.add(m.group(1))
    return out


def read_order(path):
    order = {}
    if path and os.path.exists(path):
        for i, l in enumerate(open(path, "rb").read().splitlines()):
            l = l.rstrip(b"\r")
            if l and l not in order:
                order[l] = i
    return order


def merge_files(order, inputs, out):
    bl = []
    for f in inputs:
        if f and os.path.exists(f):
            for head, body in blocks(f):
                bl.append((order.get(SRC_RE.match(head).group(1), 1 << 40), len(bl), head + body))
    bl.sort(key=lambda x: (x[0], x[1]))
    with open(out, "wb") as fo:
        for _, _, b in bl:
            fo.write(b)
    return len(bl)


def count_sources(path):
    n = 0
    if path and os.path.exists(path):
        with open(path, "rb") as f:
            for line in f:
                if line.startswith(b"<source "):
                    n += 1
    return n


def cmd_prepare(a):
    rl = Relabel(a.sysbase, a.prev_rev, a.rev, a.rename)
    purge = read_set(a.purge)
    copies = {}
    for line in read_lines(a.copy):
        if b"\t" in line:
            s, d = line.split(b"\t", 1)
            copies.setdefault(s, []).append(d)
    w = a.work
    # files that get new blocks in r<N>: extracted (staged) files, their blocks, copies
    replaced = paths_of(a.delta_raw)
    for p in read_set(a.staged):
        replaced.add(rl.new + p)
    for ds in copies.values():
        for d in ds:
            replaced.add(rl.new + d)
    fixes = {}
    # raw blocks: unchanged files of r<P> + copied files + extracted (added / modified) files
    n_old, n_drop, copy_raw = split_prev(a.prev_raw, rl, purge, copies, os.path.join(w, "old_raw.xml"),
                                         replaced, fixes)
    new_raw = os.path.join(w, "new_raw.xml")
    with open(new_raw, "wb") as fo:
        for b in copy_raw:
            fo.write(b)
        n_delta = copy_dedup(a.delta_raw, fo, fixes, rl.new)
    order = read_order(a.order)
    if order:
        n_blocks = merge_files(order, [os.path.join(w, "old_raw.xml"), new_raw], a.raw_out)
    else:                                       # no file order asked: previous blocks, then new blocks
        with open(a.raw_out, "wb") as fo:
            for f in (os.path.join(w, "old_raw.xml"), new_raw):
                with open(f, "rb") as fi:
                    fo.write(fi.read())
        n_blocks = n_old + len(copy_raw) + n_delta
    # blocks at the level of the clone detection (after rename etc. if the config has it)
    if a.prev_norm:
        _, _, copy_norm = split_prev(a.prev_norm, rl, purge, copies, a.old_pc, replaced)
        with open(a.new_pc, "wb") as fo:
            for b in copy_norm:
                fo.write(b)
            copy_dedup(a.delta_norm, fo, None)
    else:
        os.replace(os.path.join(w, "old_raw.xml"), a.old_pc)
        os.replace(new_raw, a.new_pc)
    if a.final:
        if a.final_mode == "merge":             # file order: the same file a full NiCad run makes
            merge_files(order, [a.old_pc, a.new_pc], a.final)
        else:                                   # previous blocks, then new blocks (clonepairs2.x pcids)
            with open(a.final, "wb") as fo:
                for f in (a.old_pc, a.new_pc):
                    with open(f, "rb") as fi:
                        fo.write(fi.read())
    for pin, pout in (a.relabel or []):
        with open(pin, "rb") as fi, open(pout, "wb") as fo:
            for line in fi:
                if line.startswith(b"<source "):
                    m = SRC_RE.match(line)
                    if m:
                        line = line[:m.start(1)] + rl(m.group(1)) + line[m.end(1):]
                fo.write(line)
    if fixes:
        with open(os.path.join(w, "dupfix.txt"), "wb") as f:
            for p, n in sorted(fixes.items()):
                f.write(b"%d\t%s\n" % (n, p))
    print("dupfix=%d foreign=%d" % (sum(fixes.values()), FOREIGN[0]), end=" ")
    print("old=%d copies=%d removed=%d new=%d blocks=%d"
          % (n_old, len(copy_raw), n_drop, len(copy_raw) + n_delta, n_blocks))


# ---------------------------------------------------------------------------
# finish: statistics of a revision (+ class-id tracking) in ONE process
#   blocks, comparisons (runinfo), pair diff against r<P>, classes; with --nicad: tracking
# ---------------------------------------------------------------------------
def cmd_finish(a):
    import time
    out = ["blocks=%d" % count_sources(a.raw)]
    nc, ncf = "", ""
    with open(a.pairs, "rb") as f:
        for line in f:
            if line.startswith(b"<runinfo"):
                m = re.search(rb' ncompares="(\d+)"', line)
                nc = m.group(1).decode() if m else ""
                m = re.search(rb' ncompares_full="(\d+)"', line)      # clonepairs2.x
                ncf = m.group(1).decode() if m else ""
                break
            if line.startswith(b"<clone "):
                break
    out.append("ncompares=%s ncompares_full=%s" % (nc, ncf))
    t0 = time.time()
    if a.nicad:
        out.append(track(a))
    elif a.classes and os.path.exists(a.classes):
        _, cl = read_classes(a.classes)
        out.append("classes=%d clones=%d" % (len(cl), sum(len(c[2]) for c in cl)))
    t1 = time.time()
    pd = pairdiff(a.sysbase, a.prev_rev, a.rev, a.rename, a.prev_pairs, a.pairs)
    out.append(pd.replace("kept=", "pairs_kept=").replace("added=", "pairs_added=").replace("removed=", "pairs_removed="))
    t2 = time.time()
    out.append("track_ms=%d stats_ms=%d" % (int((t1 - t0) * 1000) if a.nicad else 0, int((t2 - t1) * 1000)))
    print(" ".join(out))


# ---------------------------------------------------------------------------
def result_files(d, rev, gran, chain, thr):
    base = "r%s_%s%s" % (rev, gran, chain)
    cd = os.path.join(d, base + "-clones")
    return (os.path.join(cd, "%s-clones-%s.xml" % (base, thr)),
            os.path.join(cd, "%s-clones-%s-classes.xml" % (base, thr)))


def class_sets(path):
    _, cl = read_classes(path)
    out = {}
    for cid, attrs, members in cl:
        ks = frozenset(key_of(m) for m in members)
        out[ks] = re.sub(rb'\s+', b' ', attrs.strip())
    return out


def timing(path):
    t = {}
    if path and os.path.exists(path):
        for row in csv.DictReader(open(path, newline="")):
            try:
                t[row["rev"]] = int(row["total_ms"])
            except (KeyError, ValueError):
                pass
    return t


def cmd_verify(a):
    rows = []
    neq = ndiff = nmiss = 0
    ti, tf = timing(a.inc_csv), timing(a.full_csv)
    print("rev    pairs(inc/full)   classes(inc/full)  result")
    for rev in range(a.first, a.last + 1):
        pi, ci = result_files(a.inc, rev, a.gran, a.chain, a.thr)
        pf, cf = result_files(a.full, rev, a.gran, a.chain, a.thr)
        if not (os.path.exists(pi) and os.path.exists(pf)):
            nmiss += 1
            rows.append([rev, "", "", "", "", "missing", "", "", ""])
            continue
        A, B = read_pairs(pi), read_pairs(pf)
        pairs_eq = A == B
        CA, CB = class_sets(ci), class_sets(cf)
        classes_eq = set(CA) == set(CB)
        attrs_eq = classes_eq and all(CA[k] == CB[k] for k in CA)
        ok = pairs_eq and classes_eq
        res = "EQUAL" if ok else "DIFF"
        if ok:
            neq += 1
        else:
            ndiff += 1
        note = ""
        if not pairs_eq:
            note += "pairs only-inc %d only-full %d; " % (len(A - B), len(B - A))
        if not classes_eq:
            note += "classes only-inc %d only-full %d; " % (len(set(CA) - set(CB)), len(set(CB) - set(CA)))
        elif not attrs_eq:
            note += "class attributes differ; "
        rows.append([rev, len(A), len(B), len(CA), len(CB), res, ti.get(str(rev), ""), tf.get(str(rev), ""), note])
        print("r%-5d %7d/%-7d   %6d/%-6d       %s %s" % (rev, len(A), len(B), len(CA), len(CB), res, note))
    with open(a.csv, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["rev", "pairs_inc", "pairs_full", "classes_inc", "classes_full", "result", "inc_ms", "full_ms", "note"])
        w.writerows(rows)
    print("EQUAL %d   DIFF %d   missing %d" % (neq, ndiff, nmiss))
    common = [r for r in ti if r in tf and int(r) != a.first]
    if common:
        si, sf = sum(ti[r] for r in common), sum(tf[r] for r in common)
        print("time over %d revisions (r%d excluded): incremental %.1fs  full %.1fs  -> %.1fx"
              % (len(common), a.first, si / 1000.0, sf / 1000.0, sf / max(si, 1)))
    print("CSV: " + a.csv)
    return 0 if ndiff == 0 else 1



# ---------------------------------------------------------------------------
# three setups: baseline / incremental extraction + baseline detection /
#               incremental extraction + incremental detection
# ---------------------------------------------------------------------------
def rows_by_rev(path):
    out = {}
    if path and os.path.exists(path):
        for row in csv.DictReader(open(path, newline="")):
            out[row["rev"]] = row
    return out


def num(row, key):
    try:
        return int(row.get(key, "") or 0)
    except ValueError:
        return 0


def cmd_compare3(a):
    names = ["baseline", "incext", "inc"]
    titles = {"baseline": "1. baseline (full extraction + full detection)",
              "incext": "2. incremental extraction + baseline detection",
              "inc": "3. incremental extraction + incremental detection"}
    dirs = {"baseline": a.full, "incext": a.incext, "inc": a.inc}
    data = {n: rows_by_rev(os.path.join(dirs[n], a.csvname)) for n in names}
    out_rows = []
    keys = ("extract", "cp", "cl", "book", "track", "total", "compares", "revs")
    tot = {n: dict((k, 0) for k in keys) for n in names}
    base_tot = {n: dict((k, 0) for k in keys) for n in names}
    base_revs = []
    equal = {"incext": [0, 0], "inc": [0, 0]}
    for rev in range(a.first, a.last + 1):
        r = str(rev)
        row = {"rev": rev}
        base_files = result_files(dirs["baseline"], rev, a.gran, a.chain, a.thr)
        B = read_pairs(base_files[0]) if os.path.exists(base_files[0]) else None
        CB = set(class_sets(base_files[1])) if os.path.exists(base_files[1]) else None
        # a revision is compared when setups 2 and 3 both ran it incrementally; the others
        # (the first revision, the first revision with code, huge change sets) are full runs
        # in all three setups
        incremental = all(n in data and r in data[n] for n in names) and \
            data["incext"][r].get("mode") == "inc" and data["inc"][r].get("mode") == "inc"
        if all(r in data[n] for n in names) and not incremental:
            base_revs.append(rev)
        row["kind"] = "incremental" if incremental else "baseline run"
        for n in names:
            d = data[n].get(r)
            if d is None:
                continue
            ext = num(d, "extract_ms") + num(d, "normalize_ms")
            cp = num(d, "clonepairs_ms") if d.get("clonepairs_ms") else num(d, "pairs_ms")
            cl = num(d, "clusterpairs_ms") if d.get("clusterpairs_ms") else num(d, "classes_ms")
            track = num(d, "tracking_ms")
            if d.get("bookkeeping_ms") not in (None, "") and "prepare_ms" in d:
                book = num(d, "bookkeeping_ms")
            else:
                book = num(d, "pairs_ms") + num(d, "classes_ms") - cp - cl
            vals = {"extract": ext, "cp": cp, "cl": cl, "book": book, "track": track,
                    "total": num(d, "total_ms"), "compares": num(d, "compares"), "revs": 1}
            for k in ("extract", "cp", "cl", "book", "track", "total", "compares"):
                row["%s_%s" % (n, {"extract": "extract_ms", "cp": "clonepairs_ms", "cl": "clusterpairs_ms",
                                   "book": "bookkeeping_ms", "track": "tracking_ms", "total": "total_ms",
                                   "compares": "compares"}[k])] = vals[k]
            row["%s_mode" % n] = d.get("mode", "")
            row["%s_pairs" % n] = d.get("pairs", "")
            row["%s_classes" % n] = d.get("classes", "")
            t = tot[n] if incremental else base_tot[n]
            for k in keys:
                t[k] += vals[k]
            if n != "baseline" and B is not None:
                f = result_files(dirs[n], rev, a.gran, a.chain, a.thr)
                if os.path.exists(f[0]):
                    ok = read_pairs(f[0]) == B and (CB is None or set(class_sets(f[1])) == CB)
                    row["%s_vs_baseline" % n] = "EQUAL" if ok else "DIFF"
                    equal[n][0 if ok else 1] += 1
        out_rows.append(row)
    cols = ["rev", "kind"]
    for n in names:
        cols += ["%s_%s" % (n, k) for k in ("mode", "extract_ms", "clonepairs_ms", "clusterpairs_ms", "bookkeeping_ms",
                                            "tracking_ms", "total_ms", "compares", "pairs", "classes")]
        if n != "baseline":
            cols.append("%s_vs_baseline" % n)
    with open(a.csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for row in out_rows:
            w.writerow(row)

    def sec(ms):
        return ("%.2f s" if ms < 10000 else "%.1f s") % (ms / 1000.0)

    def speed(b, x):
        return "%.1fx" % (b / float(x)) if x else "-"
    b = tot["baseline"]
    nrev = b["revs"]
    lines = []
    lines.append("Revisions r%d..r%d: %d incremental revisions compared" % (a.first, a.last, nrev))
    if base_revs:
        lines.append("Baseline runs (full NiCad in all three setups, not in the sums): %s"
                     % ", ".join("r%d" % x for x in base_revs))
    lines.append("")
    lines.append("| setup | extraction + normalization | clone detection | classes | copy / relabel / merge | class-id tracking | total | per revision | comparisons | same result as baseline |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---|")
    for n in names:
        t = tot[n]
        eq = "-" if n == "baseline" else "%d EQUAL, %d DIFF" % tuple(equal[n])
        lines.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            titles[n], sec(t["extract"]), sec(t["cp"]), sec(t["cl"]), sec(t["book"]), sec(t["track"]),
            sec(t["total"]), sec(t["total"] / float(max(t["revs"], 1))), "{:,}".format(t["compares"]), eq))
    lines.append("")
    lines.append("| speedup vs. baseline | extraction | clone detection | total | comparisons |")
    lines.append("|---|---:|---:|---:|---:|")
    for n in names[1:]:
        t = tot[n]
        lines.append("| %s | %s | %s | %s | %s |" % (titles[n], speed(b["extract"], t["extract"]),
                     speed(b["cp"], t["cp"]), speed(b["total"], t["total"]), speed(b["compares"], t["compares"])))
    if base_revs:
        lines.append("")
        lines.append("Baseline runs: " + ", ".join("%s %s" % (n, sec(base_tot[n]["total"])) for n in names))
    lines.append("")
    lines.append("clone detection = the clonepairs program (clonepairs.x / clonepairs2.x), fastest of TIMING_REPEAT runs")
    lines.append("(NiCadCompare: 3); classes = cloneclasses.x;")
    lines.append("copy / relabel / merge = previous blocks and pairs taken over (paths r<N-1> -> r<N>), block files built;")
    lines.append("class-id tracking = stable class ids across revisions (setup 3 only).")
    lines.append("")
    lines.append("Per revision: " + a.csv)
    text = "\n".join(lines)
    print(text)
    if a.md:
        open(a.md, "w").write(text + "\n")

# ---------------------------------------------------------------------------
# coverage: before the comparison - has every revision of the range its results in all
# three setups? If not: what is missing and the command that finishes it.
# ---------------------------------------------------------------------------
def ranges(revs):
    """[1,2,3,7,9,10] -> 'r1..r3, r7, r9..r10'"""
    out, i = [], 0
    revs = sorted(revs)
    while i < len(revs):
        j = i
        while j + 1 < len(revs) and revs[j + 1] == revs[j] + 1:
            j += 1
        out.append("r%d" % revs[i] if i == j else "r%d..r%d" % (revs[i], revs[j]))
        i = j + 1
    if len(out) > 8:
        out = out[:8] + ["... (%d ranges)" % len(out)]
    return ", ".join(out)


def first_line(path):
    try:
        with open(path) as f:
            return f.readline().strip()
    except OSError:
        return None


def cmd_coverage(a):
    titles = {"b": "baseline (full extraction + full detection)",
              "ib": "incremental extraction + baseline detection",
              "ii": "incremental extraction + incremental detection"}
    revs = list(range(a.first, a.last + 1))
    nosnap = [r for r in revs if not os.path.isdir(os.path.join(a.sysbase, "r%d" % r))]
    have = [r for r in revs if r not in set(nosnap)]
    info = {}
    for name, d, fp in a.setup:
        st = os.path.join(d, ".nicadinc")
        done, cached, missing = [], [], []
        for r in have:
            pf = result_files(d, r, a.gran, a.chain, a.thr)[0]
            ok = fp != "-" and os.path.isfile(pf) and os.path.getsize(pf) > 0
            if ok and first_line(os.path.join(st, "done_%s_r%d" % (a.gran, r))) == fp:
                done.append(r)
            elif ok and first_line(os.path.join(st, "cache_%s" % a.gran, "r%d.ok" % r)) == "fp=%s:v2" % fp:
                cached.append(r)
            else:
                missing.append(r)
        info[name] = (done, cached, missing)
    print("results for r%d..r%d (%d revisions):" % (a.first, a.last, len(revs)))
    for name, _, _ in a.setup:
        done, cached, missing = info[name]
        if not done and not cached:
            state = "not run"
        else:
            state = "%d/%d done" % (len(done), len(have))
            if cached:
                state += ", %d finished but not saved (%s)" % (len(cached), ranges(cached))
            if missing:
                state += ", missing %s" % ranges(missing)
        print("  %-3s %-48s %s" % (name, titles.get(name, name), state))
    if nosnap:
        print("  no snapshot systems/.../r<N> for %d revision(s): %s - left out" % (len(nosnap), ranges(nosnap)))
    common = set(have)
    for name in info:
        common &= set(info[name][0])
    todo = [n for n, _, _ in a.setup if info[n][1] or info[n][2]]
    if nosnap:
        repo = ""
        try:
            m = re.search(r'repository="([^"]*)"', open(os.path.join(a.sysbase, "commits.xml"), errors="replace").read(4096))
            repo = m.group(1) if m else ""
        except OSError:
            pass
        print("  To get the missing snapshots:  python scripts/git_downloader.py %s %s %d %d"
              % (repo or "<repository URL>", os.path.basename(a.sysbase.rstrip("/")), a.first, a.last))
    if todo:
        thr = " %s" % a.threads if "b" in todo and a.threads not in ("", "1") else ""
        print("")
        print("*** Not every revision has its results in all three setups.")
        if any(info[n][1] for n in todo):
            print("    'finished but not saved': the baseline run stopped before saving them; running b again")
            print("    saves them without running NiCad on them again.")
        print("    Run (revisions that are done are reused - nothing is extracted or detected twice):")
        print("      %s%s %s" % (a.run_cmd, thr, ",".join(todo)))
    if len(common) == len(have) and have:
        print("all three setups have all %d revisions%s." % (len(have), " that have a snapshot" if nosnap else ""))
        return 0
    if not common:
        print("")
        print("Nothing to compare yet: no revision has results in all three setups.")
        return 4
    print("")
    print("The comparison below uses the %d revision(s) that all three setups have (of %d)." % (len(common), len(have)))
    return 3


# ---------------------------------------------------------------------------
# adopt (MODE=full): revisions whose baseline results are already in the output folder from an
# earlier run that stopped before saving them (no done file). Their times are taken from the
# saved row / the CSV, or from the log line the thread printed when it finished
#   "r11     done   18/200 | blocks 13935 | extract 627.41s, normalize 0.00s, clone pairs 34.04s | 661.45s"
# (only from a log section with the same settings as this run). Prints one line per revision:
#   adopt REV EXT_MS NORM_MS PAIRS_MS CL_MS(-1: unknown) BLOCKS SOURCE | notimes REV | incomplete REV
# ---------------------------------------------------------------------------
DONE_RE = re.compile(r'^r(\d+)\s+done\s+\d+/\d+ \| blocks (\d+) \| extract ([\d.]+)s, normalize ([\d.]+)s, '
                     r'clone pairs ([\d.]+)s')


def tail_bytes(path, n=256):
    with open(path, "rb") as f:
        f.seek(0, 2)
        size = f.tell()
        f.seek(max(0, size - n))
        return f.read()


def count_source_lines(path):
    n = 0
    with open(path, "rb") as f:
        for line in f:
            if line.startswith(b"<source "):
                n += 1
    return n


def csv_rows(path):
    out = {}
    if path and os.path.isfile(path):
        with open(path, newline="") as f:
            for row in csv.DictReader(f):
                if row.get("rev", "").isdigit():
                    out[int(row["rev"])] = row
    return out


def cmd_adopt(a):
    want = set(range(a.first, a.last + 1))
    # times from the log: only sections of a baseline run with the same settings
    logt = {}
    if a.log and os.path.isfile(a.log):
        ok, head = False, 0
        with open(a.log, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.rstrip("\r\n")
                if line.startswith("NiCadInc ("):
                    ok = line.startswith("NiCadInc (full)") and (" %s " % a.gran) in line \
                        and line.endswith("config=" + a.config)
                    head = 1
                    continue
                if head == 1:
                    ok = ok and line == a.settings
                    head = 2
                    continue
                if head == 2:
                    ok = ok and line.startswith(a.settings2)
                    head = 0
                    continue
                m = DONE_RE.match(line)
                if ok and m and int(m.group(1)) in want:
                    ms = [int(round(float(m.group(i)) * 1000)) for i in (3, 4, 5)]
                    logt[int(m.group(1))] = (ms[0], ms[1], ms[2], -1, int(m.group(2)), "log")
    rows = csv_rows(a.csv)
    for rev in sorted(want):
        if os.path.exists(os.path.join(a.state, "done_%s_r%d" % (a.gran, rev))):
            continue                         # saved (or made with other settings: run again)
        if os.path.exists(os.path.join(a.cache, "r%d.ok" % rev)):
            continue
        pf, cf = result_files(a.out, rev, a.gran, a.chain, a.thr)
        raw = os.path.join(a.out, "r%d_%s.xml" % (rev, a.gran))
        fin = os.path.join(a.out, "r%d_%s%s.xml" % (rev, a.gran, a.chain))
        if not os.path.isfile(pf):
            continue                         # nothing there
        if not (os.path.getsize(pf) > 0 and b"</clones>" in tail_bytes(pf)
                and os.path.isfile(raw) and os.path.isfile(fin)):
            print("incomplete %d" % rev)
            continue
        t = None
        rowf = os.path.join(a.rows, "r%d" % rev)
        row = None
        if os.path.isfile(rowf):
            try:
                with open(rowf, newline="") as f:
                    vals = next(csv.reader(f))
                hdr = a.header.split(",")
                if len(hdr) == len(vals):
                    row = dict(zip(hdr, vals))
            except (OSError, StopIteration):
                row = None
        if row is None:
            row = rows.get(rev)
        if row and row.get("mode") == "full":
            try:
                cl = int(row.get("clusterpairs_ms") or row.get("classes_ms") or -1)
                t = (int(row["extract_ms"]), int(row["normalize_ms"]),
                     int(row.get("clonepairs_ms") or row["pairs_ms"]),
                     cl if os.path.isfile(cf) else -1, int(row.get("new_blocks") or row["blocks"]), "csv")
            except (KeyError, ValueError):
                t = None
        if t is None:
            t = logt.get(rev)
        if t is None:
            print("notimes %d" % rev)
            continue
        if t[5] == "log" and count_source_lines(raw) != t[4]:
            print("incomplete %d" % rev)     # the block file is not the one the log line is about
            continue
        print("adopt %d %d %d %d %d %d %s" % ((rev,) + t))
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--sysbase", required=True)
    common.add_argument("--prev-rev", type=int, required=True)
    common.add_argument("--rev", type=int, required=True)
    common.add_argument("--rename")

    p = sp.add_parser("split", parents=[common])
    p.add_argument("--prev", required=True)
    p.add_argument("--purge")
    p.add_argument("--copy")
    p.add_argument("--old", required=True)
    p.add_argument("--copyout", required=True)

    p = sp.add_parser("merge")
    p.add_argument("--order")
    p.add_argument("--out", required=True)
    p.add_argument("inputs", nargs="+")

    p = sp.add_parser("mergepairs", parents=[common])
    p.add_argument("--prev")
    p.add_argument("--delta", required=True)
    p.add_argument("--pc", required=True)
    p.add_argument("--old")
    p.add_argument("--out", required=True)

    p = sp.add_parser("relabel", parents=[common])
    p.add_argument("--in", dest="inp", required=True)
    p.add_argument("--out", required=True)

    p = sp.add_parser("track", parents=[common])
    p.add_argument("--nicad", required=True)
    p.add_argument("--prev")
    p.add_argument("--out", required=True)
    p.add_argument("--changes")
    p.add_argument("--nextid-in")
    p.add_argument("--nextid-out")
    p.add_argument("--pc")
    p.add_argument("--prev-pc")

    p = sp.add_parser("pairdiff", parents=[common])
    p.add_argument("--prev")
    p.add_argument("--cur", required=True)

    p = sp.add_parser("prepare", parents=[common])
    p.add_argument("--purge")
    p.add_argument("--copy")
    p.add_argument("--work", required=True)
    p.add_argument("--staged", help="paths (inside r<N>/) of the files extracted in this revision")
    p.add_argument("--prev-raw", required=True)
    p.add_argument("--delta-raw")
    p.add_argument("--order")
    p.add_argument("--raw-out", required=True)
    p.add_argument("--prev-norm")
    p.add_argument("--delta-norm")
    p.add_argument("--old-pc", required=True)
    p.add_argument("--new-pc", required=True)
    p.add_argument("--final")
    p.add_argument("--final-mode", choices=["merge", "concat"], default="merge")
    p.add_argument("--relabel", nargs=2, action="append", metavar=("IN", "OUT"))

    p = sp.add_parser("finish", parents=[common])
    p.add_argument("--raw", required=True)
    p.add_argument("--pairs", required=True)
    p.add_argument("--prev-pairs")
    p.add_argument("--classes")
    p.add_argument("--nicad")
    p.add_argument("--prev")
    p.add_argument("--out")
    p.add_argument("--changes")
    p.add_argument("--nextid-in")
    p.add_argument("--nextid-out")
    p.add_argument("--pc")
    p.add_argument("--prev-pc")

    p = sp.add_parser("compare3")
    p.add_argument("--full", required=True)
    p.add_argument("--incext", required=True)
    p.add_argument("--inc", required=True)
    p.add_argument("--csvname", required=True)
    p.add_argument("--gran", required=True)
    p.add_argument("--chain", default="")
    p.add_argument("--thr", required=True)
    p.add_argument("--first", type=int, required=True)
    p.add_argument("--last", type=int, required=True)
    p.add_argument("--csv", required=True)
    p.add_argument("--md")

    p = sp.add_parser("adopt")
    for x in ("--out", "--gran", "--thr", "--state", "--cache", "--rows", "--csv", "--log", "--config",
              "--settings", "--settings2", "--header"):
        p.add_argument(x, required=True)
    p.add_argument("--chain", default="")
    p.add_argument("--first", type=int, required=True)
    p.add_argument("--last", type=int, required=True)

    p = sp.add_parser("coverage")
    p.add_argument("--sysbase", required=True)
    p.add_argument("--gran", required=True)
    p.add_argument("--chain", default="")
    p.add_argument("--thr", required=True)
    p.add_argument("--first", type=int, required=True)
    p.add_argument("--last", type=int, required=True)
    p.add_argument("--setup", nargs=3, action="append", metavar=("NAME", "DIR", "FINGERPRINT"), required=True)
    p.add_argument("--threads", default="1")
    p.add_argument("--run-cmd", dest="run_cmd", default="bash scripts/NiCadCompare ...")

    p = sp.add_parser("verify")
    p.add_argument("--inc", required=True)
    p.add_argument("--full", required=True)
    p.add_argument("--gran", required=True)
    p.add_argument("--chain", default="")
    p.add_argument("--thr", required=True)
    p.add_argument("--first", type=int, required=True)
    p.add_argument("--last", type=int, required=True)
    p.add_argument("--csv", required=True)
    p.add_argument("--inc-csv")
    p.add_argument("--full-csv")

    a = ap.parse_args()
    if a.cmd == "split":
        cmd_split(a)
    elif a.cmd == "merge":
        cmd_merge(a)
    elif a.cmd == "mergepairs":
        cmd_mergepairs(a)
    elif a.cmd == "relabel":
        cmd_relabel(a)
    elif a.cmd == "track":
        cmd_track(a)
    elif a.cmd == "pairdiff":
        cmd_pairdiff(a)
    elif a.cmd == "prepare":
        cmd_prepare(a)
    elif a.cmd == "finish":
        cmd_finish(a)
    elif a.cmd == "compare3":
        cmd_compare3(a)
    elif a.cmd == "adopt":
        sys.exit(cmd_adopt(a))
    elif a.cmd == "coverage":
        sys.exit(cmd_coverage(a))
    elif a.cmd == "verify":
        sys.exit(cmd_verify(a))
    else:
        ap.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
