#!/usr/bin/env python3
"""
compare_blocks.py - compare the potential-clone blocks of the three NiCadCompare setups,
one revision at a time (only one revision's blocks are in memory at any moment).

  python scripts/compare_blocks.py systems/greenshot 1000 1200                 (b,ib,ii: all three)
  python scripts/compare_blocks.py systems/greenshot 1000 1200 ib,ii           (only these two)
  python scripts/compare_blocks.py systems/greenshot 1000 1200 b,ii --config type3 --gran functions
  python scripts/compare_blocks.py systems/greenshot 1000 1200 --stage norm --details

setups (comma separated, at least two; default b,ib,ii):
    b   <system>/nicadfull_<config>/r<i>_<gran>.xml      baseline
    ib  <system>/nicadincext_<config>/r<i>_<gran>.xml    incremental extraction + baseline detection
    ii  <system>/nicadinc2_<config>/r<i>_<gran>.xml      incremental extraction + incremental detection
(--stage norm: the normalized file r<i>_<gran>-<...>.xml instead, e.g. r<i>_functions-blind.xml)

A block is identified by its file (path inside r<i>/), start line, end line and its text
(line endings ignored). Per revision:
    blocks of each setup, matched in all chosen setups, unique to each setup (in that setup
    only), in two setups only (three setups chosen), "same place, different text" (same file
    and lines, other text),
    and blocks that occur twice in one setup (the same file, lines and text more than once)
and writes one CSV row, then goes on to the next revision.

Output: <system>/block_compare_<gran>_<config>_<a>_<b>.csv   (+ ..._details.txt with --details)
"""
import argparse
import csv
import glob
import hashlib
import os
import re
import sys
from collections import Counter

# b = baseline, ib = incremental extraction + baseline detection, ii = incremental + incremental
SETUPS = [("b", "nicadfull"), ("ib", "nicadincext"), ("ii", "nicadinc2")]
SRC_RE = re.compile(rb'^<source file="(.*?)" startline="(-?\d+)" endline="(-?\d+)"')
REV_RE = re.compile(rb'(^|/)r\d+/')


def block_keys(path):
    """Counter of (relative path, start, end, sha1 of text) for every <source> block of a file,
    read line by line (the file is never loaded as a whole)."""
    keys = Counter()
    head, h = None, None
    with open(path, "rb") as f:
        for line in f:
            if head is None:
                if line.startswith(b"<source "):
                    m = SRC_RE.match(line)
                    if m:
                        p = m.group(1).replace(b"\\", b"/")
                        r = REV_RE.search(p)                 # path inside r<i>/ (system path spelling ignored)
                        rel = p[r.end():] if r else p
                        head = (rel, int(m.group(2)), int(m.group(3)))
                        h = hashlib.sha1()
                continue
            if line.startswith(b"</source>"):
                keys[head + (h.digest(),)] += 1
                head = None
            else:
                h.update(line.rstrip(b"\r\n") + b"\n")
    return keys


def find_file(folder, rev, gran, stage):
    raw = os.path.join(folder, "r%d_%s.xml" % (rev, gran))
    if stage == "raw":
        return raw if os.path.isfile(raw) else None
    cands = [c for c in glob.glob(os.path.join(folder, "r%d_%s-*.xml" % (rev, gran))) if os.path.isfile(c)]
    if not cands:
        return raw if os.path.isfile(raw) else None       # no normalization in this config
    return max(cands, key=len)                              # the last step of the chain (longest name)


def detect_config(system):
    cfgs = []
    for d in sorted(os.listdir(system)):
        if d.startswith("nicadfull_") and os.path.isdir(os.path.join(system, d)):
            cfgs.append(d[len("nicadfull_"):])
    return cfgs


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("system", help="e.g. systems/greenshot")
    ap.add_argument("first", type=int)
    ap.add_argument("last", type=int)
    ap.add_argument("setups", nargs="*", help="b, ib, ii - comma separated (default: all three)")
    ap.add_argument("--config", help="e.g. type3 (default: the one nicadfull_<config> folder)")
    ap.add_argument("--gran", default="functions", choices=["functions", "blocks"])
    ap.add_argument("--stage", default="raw", choices=["raw", "norm"],
                    help="raw: r<i>_<gran>.xml (default); norm: the renamed/normalized file")
    ap.add_argument("--details", action="store_true", help="also list the differing blocks")
    ap.add_argument("--max-details", type=int, default=50, help="differing blocks listed per revision")
    a = ap.parse_args()

    # which setups: "ib,ii" or "ib, ii" or "ib ii"
    chosen = []
    for x in a.setups:
        for t in x.replace(",", " ").split():
            if t not in [n for n, _ in SETUPS]:
                sys.exit("*** Error: unknown setup '%s' (use b, ib, ii - e.g. ib,ii)" % t)
            if t not in chosen:
                chosen.append(t)
    if not chosen:
        chosen = [n for n, _ in SETUPS]
    if len(chosen) < 2:
        sys.exit("*** Error: choose at least two setups to compare (e.g. b,ii)")
    setups = [(n, p) for n, p in SETUPS if n in chosen]          # always in the order b, ib, ii
    names = [n for n, _ in setups]

    system = a.system.replace("\\", "/").rstrip("/")
    if system.startswith("/") and not os.path.isdir(system) and os.path.isdir(system.lstrip("/")):
        system = system.lstrip("/")                          # "\systems\greenshot" typed on Windows
    if not os.path.isdir(system):
        sys.exit("*** Error: %s not found (run from the NiCad folder)" % system)
    cfg = a.config
    if not cfg:
        cfgs = detect_config(system)
        if not cfgs:                                         # no baseline folder: look at the others
            for n, prefix in setups:
                cfgs += [d[len(prefix) + 1:] for d in sorted(os.listdir(system))
                         if d.startswith(prefix + "_") and os.path.isdir(os.path.join(system, d))]
            cfgs = sorted(set(cfgs))
        if len(cfgs) != 1:
            sys.exit("*** Error: give --config (found: %s)" % (", ".join(cfgs) or "no result folders"))
        cfg = cfgs[0]
    folders = [(n, os.path.join(system, "%s_%s" % (prefix, cfg))) for n, prefix in setups]
    for n, d in folders:
        if not os.path.isdir(d):
            print("*** Warning: %s not found" % d)

    tag = "%s_%s%s_%s_%d_%d" % (a.gran, cfg, "_norm" if a.stage == "norm" else "", "-".join(names), a.first, a.last)
    out_csv = os.path.join(system, "block_compare_%s.csv" % tag)
    out_det = os.path.join(system, "block_compare_%s_details.txt" % tag)
    pairs = [(x, y) for i, x in enumerate(names) for y in names[i + 1:]] if len(names) == 3 else []
    cols = (["rev"] + ["blocks_" + n for n in names] + ["matched_all"] + ["unique_" + n for n in names]
            + ["%s_%s_only" % p for p in pairs] + ["same_place_diff_text"] + ["twice_" + n for n in names] + ["result"])
    tot = Counter()
    ndiff = nsame = nmiss = 0
    det = open(out_det, "w", encoding="utf-8", errors="replace") if a.details else None
    sl = "/".join(names)
    print("comparing %s  (%s)" % (", ".join(names), ", ".join(d for _, d in folders)))
    print("rev     %s | matched | unique %s | twice %s | result" % (" ".join("%7s" % n for n in names), sl, sl))
    with open(out_csv, "w", newline="") as fo:
        w = csv.writer(fo, lineterminator="\n")
        w.writerow(cols)
        for rev in range(a.first, a.last + 1):
            files = [(n, find_file(d, rev, a.gran, a.stage)) for n, d in folders]
            missing = [n for n, f in files if f is None]
            if missing:
                nmiss += 1
                w.writerow([rev] + [""] * (len(cols) - 2) + ["missing: " + " ".join(missing)])
                print("r%-6d missing in: %s" % (rev, " ".join(missing)))
                continue
            # one revision at a time: a Counter of block keys per setup, then discarded
            C = {n: block_keys(f) for n, f in files}
            S = {n: set(C[n]) for n in names}
            allk = set.intersection(*S.values())
            row = {"rev": rev, "matched_all": sum(min(C[n][k] for n in names) for k in allk)}
            for n in names:
                others = set().union(*(S[m] for m in names if m != n))
                row["blocks_" + n] = sum(C[n].values())
                row["unique_" + n] = len(S[n] - others)
                row["twice_" + n] = sum(c - 1 for c in C[n].values() if c > 1)
            for x, y in pairs:
                z = [m for m in names if m not in (x, y)][0]
                row["%s_%s_only" % (x, y)] = len((S[x] & S[y]) - S[z])
            # same file and lines in two setups but a different text
            places = {}
            for n in names:
                for k in S[n]:
                    places.setdefault(k[:3], set()).add(k[3])
            row["same_place_diff_text"] = sum(1 for v in places.values() if len(v) > 1)
            same = all(C[n] == C[names[0]] for n in names[1:])
            row["result"] = "SAME" if same else "DIFF"
            if same:
                nsame += 1
            else:
                ndiff += 1
            w.writerow([row[c] for c in cols])
            fo.flush()
            for c in cols[1:-1]:
                tot[c] += row[c]
            print("r%-6d %s | %7d | %s | %s | %s" % (
                rev, " ".join("%7d" % row["blocks_" + n] for n in names), row["matched_all"],
                "/".join(str(row["unique_" + n]) for n in names).rjust(len(sl) + 7),
                "/".join(str(row["twice_" + n]) for n in names).rjust(len(sl) + 6), row["result"]))
            if det is not None and not same:
                det.write("r%d\n" % rev)
                cnt = 0
                for k in sorted(set().union(*S.values())):
                    ins = [n for n in names if k in S[n]]
                    if len(ins) < len(names):
                        det.write("  %-14s %s %d-%d (text %s)\n" % ("in " + "+".join(ins), k[0].decode("utf-8", "replace"),
                                                                    k[1], k[2], k[3].hex()[:10]))
                        cnt += 1
                        if cnt >= a.max_details:
                            det.write("  ...\n")
                            break
                for n in names:
                    twice = sorted((k, c) for k, c in C[n].items() if c > 1)
                    for k, c in twice[:a.max_details]:
                        det.write("  %-14s %s %d-%d (%d times)\n" % (n + " twice", k[0].decode("utf-8", "replace"), k[1], k[2], c))
            del C, S, allk, places
    if det is not None:
        det.close()
    print("-" * 72)
    print("revisions: %d same, %d different, %d missing" % (nsame, ndiff, nmiss))
    print("blocks: %s | matched in all %d setups %d" % (", ".join("%s %d" % (n, tot["blocks_" + n]) for n in names),
                                                       len(names), tot["matched_all"]))
    line = "unique: " + ", ".join("%s %d" % (n, tot["unique_" + n]) for n in names)
    if pairs:
        line += " | in two only: " + ", ".join("%s+%s %d" % (x, y, tot["%s_%s_only" % (x, y)]) for x, y in pairs)
    print(line + " | same place, different text %d" % tot["same_place_diff_text"])
    print("blocks that occur twice: " + ", ".join("%s %d" % (n, tot["twice_" + n]) for n in names))
    print("CSV: " + out_csv + ("\nDetails: " + out_det if a.details else ""))
    return 0 if ndiff == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
