#!/usr/bin/env python3
"""
git_downloader - Git repository -> revision snapshots + commits.xml for NiCad++

Run from the NiCad root (the folder that contains tools/, config/, scripts/, systems/):

    ./scripts/git_downloader <repo> [name] <from> <to> [options]

    <repo>   Git URL (https://github.com/laravel/framework.git) or a local clone
    [name]   folder name under systems/ (default: owner_repo from the URL)
    <from>   first revision number (1 = oldest commit of the analyzed history)
    <to>     last revision number

Examples:
    ./scripts/git_downloader https://github.com/laravel/framework.git laravel_framework 1 200
    ./scripts/git_downloader https://github.com/laravel/framework.git 1 200
    ./scripts/git_downloader https://github.com/laravel/framework.git --info
    ./scripts/git_downloader https://github.com/apache/cassandra.git 1 300 --lang java
    ./scripts/git_downloader https://github.com/laravel/framework.git 1 200 --name laravel_framework_full

Layout it creates under systems/:
    systems/.repos/<name>/      the Git clone (only if no existing clone is found)
    systems/<name>/r<N>/        exact snapshot of revision N (source files only)
    systems/<name>/commits.xml  per-revision change sets for scripts/NiCadInc
    systems/<name>/manifests/   r<N>.tsv: blob id <TAB> path of every source file
    systems/<name>/changes.csv  per-revision counts (files, lines, changes, churn)
    systems/<name>/full_commit.txt, commits.txt

Then run, e.g.:
    ./scripts/NiCadInc functions php systems/<name> type3 <from> <to>

Python API:
    import sys; sys.path.insert(0, "scripts")
    from git_downloader import download
    info = download("https://github.com/laravel/framework.git", 1, 200)
    print(info["out_dir"], info["language"])

Correctness (paper, Sec. IV-C, assumption A5):
  * History   : first-parent history of the ref (default), so consecutive
                revisions are consecutive states of one branch; merge commits
                are compared with their first parent.
  * Manifests : `git ls-tree -r` gives path -> blob id of every regular source
                file (symlinks and submodules excluded).
  * Changes   : computed by comparing manifests (blob ids):
                  modified = same path, different blob
                  added / deleted = path appears / disappears
                  renamed = new path whose blob was at a deleted path
                  copied  = new path whose blob exists at a remaining path
                A mode-only change (chmod +x) is not a content change.
  * Snapshots : written blob by blob with `git cat-file --batch` (not
                `git archive`, so .gitattributes export-ignore cannot drop
                files) and each file is verified against its blob id.
  * Clones    : an existing clone with the same origin URL is reused
                (systems/.repos/, the NiCad root, systems/, or --clone PATH);
                partial clones (--filter=blob:none) get their missing file
                contents fetched in one batch.
  * Re-runs   : snapshots whose manifest did not change are kept; for every
                snapshot that is rewritten, stale NiCad outputs r<N>_* are removed.
  * Windows   : on a case-insensitive disk (NTFS) two paths that differ only in
                case (gimp: plug-ins/Julia/Julia.c and plug-ins/Julia/julia.c)
                would overwrite each other. The first one (sorted) keeps its
                name, the others are written as <name>_case2<ext>, ... and
                directories that differ only in case are merged. The manifest,
                commits.xml and changes.csv use these on-disk paths, so they
                always match the snapshot; the renames are listed in
                case_renames.txt. (Also names Windows cannot create: aux.c,
                con.h, trailing dot/space, <>:"|?* characters.)
"""

import argparse
import csv
import hashlib
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import xml.etree.ElementTree as ET
from xml.dom import minidom

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SYSTEMS_DIR = os.path.normpath(os.path.join(SCRIPT_DIR, "..", "systems"))

REGULAR_FILE_MODES = {"100644", "100755"}          # not 120000 symlink / 160000 submodule

# NiCad language name -> source extensions
LANGUAGES = {
    "java": [".java"],
    "c": [".c", ".h"],
    "cs": [".cs"],
    "py": [".py"],
    "php": [".php"],
    "rb": [".rb"],
    "swift": [".swift"],
    "rust": [".rs"],
}
LANGUAGE_ALIASES = {"python": "py", "ruby": "rb", "csharp": "cs", "c#": "cs", "rs": "rust"}


# =====================================================
# UTILS
# =====================================================
class DownloadError(Exception):
    pass


def force_remove(path):
    """Windows-safe recursive delete of a file or directory."""
    def onerror(func, p, exc_info):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path, onerror=onerror)
    elif os.path.lexists(path):
        os.remove(path)


def git(args, repo, binary=False, check=True):
    r = subprocess.run(["git", "-C", repo] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        if check:
            raise DownloadError(f"git {' '.join(args)} failed: "
                                f"{r.stderr.decode('utf-8', errors='replace').strip()}")
        return None
    return r.stdout if binary else r.stdout.decode("utf-8", errors="surrogateescape")


def decode_path(b):
    return b.decode("utf-8", errors="surrogateescape")


def xml_safe(s):
    s = s.encode("utf-8", errors="surrogateescape").decode("utf-8", errors="replace")
    return "".join(ch for ch in s if ch in "\t\n\r" or ord(ch) >= 0x20)


def ext_of(path):
    return os.path.splitext(path)[1].lower()


class Progress:
    """Single-line progress bar on a terminal; plain periodic lines otherwise."""
    def __init__(self, total, label):
        self.total, self.label, self.n = max(total, 1), label, 0
        self.tty = sys.stderr.isatty()
        self.t0 = time.time()
        self.last = 0.0

    def step(self, note=""):
        self.n += 1
        now = time.time()
        if self.tty and (now - self.last > 0.1 or self.n == self.total):
            self.last = now
            w = 30
            f = self.n * w // self.total
            el = now - self.t0
            eta = el / self.n * (self.total - self.n)
            line = (f"  {self.label} [{'#' * f}{'-' * (w - f)}] {self.n}/{self.total} "
                    f"{100 * self.n // self.total:3d}%  {note}  elapsed {el:.0f}s  ETA {eta:.0f}s")
            cols = shutil.get_terminal_size((120, 20)).columns
            sys.stderr.write("\r\033[K" + line[:cols - 1])
            sys.stderr.flush()
        elif not self.tty and (self.n % 50 == 0 or self.n == self.total):
            print(f"  {self.label}: {self.n}/{self.total}")

    def done(self):
        if self.tty:
            sys.stderr.write("\n")
            sys.stderr.flush()


# =====================================================
# REPOSITORY
# =====================================================
def repo_name_from(repo):
    """https://github.com/laravel/framework.git -> laravel_framework ; /x/y/proj -> proj"""
    if os.path.isdir(repo):
        return os.path.basename(os.path.abspath(repo).rstrip("/\\"))
    s = repo.rstrip("/")
    s = re.sub(r"\.git$", "", s)
    parts = re.split(r"[/:]", s)
    parts = [p for p in parts if p]
    name = "_".join(parts[-2:]) if len(parts) >= 2 else parts[-1]
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)


def normalize_url(url):
    """https://github.com/a/b.git, git@github.com:a/b, ... -> github.com/a/b"""
    u = url.strip().lower().rstrip("/")
    u = re.sub(r"\.git$", "", u)
    u = re.sub(r"^[a-z+]+://", "", u)          # scheme
    u = re.sub(r"^[^@/]+@", "", u)             # user@
    u = u.replace(":", "/", 1) if re.match(r"^[^/]+:[^/]", u) else u
    return u


def is_usable_repo(path):
    return (os.path.isdir(path)
            and git(["rev-parse", "--verify", "--quiet", "HEAD^{commit}"], path, check=False) is not None)


def find_existing_clone(repo, name, systems_dir):
    """Look for a clone of the same repository (matching origin URL) in the usual places."""
    want = normalize_url(repo)
    root = os.path.dirname(systems_dir)
    tail = re.sub(r"\.git$", "", repo.rstrip("/")).split("/")[-1]
    cands = [os.path.join(systems_dir, ".repos", name), os.path.join(root, name),
             os.path.join(root, tail), os.path.join(os.getcwd(), name), os.path.join(os.getcwd(), tail)]
    for base in (root, os.getcwd(), systems_dir, os.path.join(systems_dir, ".repos")):
        try:
            for d in sorted(os.listdir(base)):
                p = os.path.join(base, d)
                if os.path.isdir(os.path.join(p, ".git")) or os.path.isfile(os.path.join(p, "HEAD")):
                    cands.append(p)
        except OSError:
            pass
    seen = set()
    for c in cands:
        c = os.path.abspath(c)
        if c in seen or not os.path.isdir(c):
            continue
        seen.add(c)
        origin = git(["config", "--get", "remote.origin.url"], c, check=False)
        if origin and normalize_url(origin) == want and is_usable_repo(c):
            return c
    return None


def prepare_repository(repo, clone_dir, update=False, systems_dir=None, name=None, clone_path=None):
    """Use a local clone (given, or found), or clone the URL into clone_dir."""
    if clone_path:
        if not is_usable_repo(clone_path):
            raise DownloadError(f"--clone {clone_path} is not a usable git repository")
        repo_dir = os.path.abspath(clone_path)
        print(f"[ok] Using clone {repo_dir} (--clone)")
    elif os.path.isdir(repo) and git(["rev-parse", "--git-dir"], repo, check=False) is not None:
        repo_dir = os.path.abspath(repo)
        print(f"[ok] Using local repository {repo_dir}")
    else:
        found = find_existing_clone(repo, name, systems_dir) if systems_dir else None
        repo_dir = found or clone_dir
        if os.path.isdir(repo_dir) and not found and not is_usable_repo(repo_dir):
            raise DownloadError(f"{repo_dir} exists but is not a usable clone "
                                f"(interrupted clone?). Delete it and run again.")
        if os.path.isdir(repo_dir):
            print(f"[ok] Using existing clone {repo_dir}")
            if update:
                print("[+] Fetching new commits (--update) ...")
                git(["fetch", "--prune", "origin"], repo_dir)
                branch = git(["symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
                             repo_dir, check=False)
                if branch:
                    git(["update-ref", "HEAD", branch.strip()], repo_dir)
        else:
            os.makedirs(os.path.dirname(repo_dir), exist_ok=True)
            print(f"[+] Cloning {repo} -> {repo_dir} (full history, all blobs) ...")
            r = subprocess.run(["git", "clone", "--no-checkout", repo, repo_dir])
            if r.returncode != 0:
                raise DownloadError("clone failed")

    if git(["rev-parse", "--is-shallow-repository"], repo_dir).strip() == "true":
        raise DownloadError(f"shallow clone (incomplete history): run "
                            f"'git -C {repo_dir} fetch --unshallow' first")
    return repo_dir


def is_partial_clone(repo_dir):
    p = git(["config", "--get", "remote.origin.promisor"], repo_dir, check=False)
    return bool(p and p.strip() == "true")


def prefetch_blobs(repo_dir, commits, needed):
    """
    Partial clone (--filter=blob:none): fetch all missing blobs of the selected
    revisions in a few batches instead of one lazy fetch per file.
    """
    missing = set()
    for i in range(0, len(commits), 100):
        out = git(["rev-list", "--objects", "--no-walk", "--missing=print"] + commits[i:i + 100],
                  repo_dir, check=False) or ""
        missing.update(l[1:41] for l in out.splitlines() if l.startswith("?"))
    missing &= needed
    if not missing:
        return 0
    print(f"      partial clone: fetching {len(missing)} missing file versions in one batch ...")
    oids = sorted(missing)
    for i in range(0, len(oids), 20000):
        r = subprocess.run(["git", "-C", repo_dir, "-c", "fetch.negotiationAlgorithm=noop", "fetch",
                            "--no-tags", "--no-write-fetch-head", "--recurse-submodules=no",
                            "--filter=blob:none", "--stdin", "origin"],
                           input=("\n".join(oids[i:i + 20000]) + "\n").encode(),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if r.returncode != 0:
            print("[!] batch fetch failed; missing blobs will be fetched one at a time (slow):\n    "
                  + r.stderr.decode("utf-8", "replace").strip()[:300])
            break
    return len(missing)


def list_history(repo_dir, ref, mode):
    args = ["log", "--reverse", "-z", "--format=%H%x1f%P%x1f%s"]
    if mode == "first-parent":
        args.append("--first-parent")
    args.append(ref)
    history = []
    for rec in git(args, repo_dir).split("\x00"):
        rec = rec.strip("\n")
        if rec:
            h, parents, subject = (rec.split("\x1f") + ["", ""])[:3]
            history.append((h, parents.split(), subject))
    return history


def detect_language(repo_dir, commit):
    """NiCad language with the most source files in the commit's tree."""
    out = git(["ls-tree", "-r", "-z", "--name-only", "--full-tree", commit], repo_dir, binary=True)
    counts = {lang: 0 for lang in LANGUAGES}
    for p in out.split(b"\x00"):
        e = ext_of(decode_path(p))
        for lang, exts in LANGUAGES.items():
            if e in exts:
                counts[lang] += 1
    lang = max(counts, key=counts.get)
    if counts[lang] == 0:
        raise DownloadError("no source files of a NiCad language found; use --lang or --ext")
    summary = ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=lambda x: -x[1]) if v)
    return lang, summary


# =====================================================
# MANIFESTS AND CHANGE CLASSIFICATION
# =====================================================
def get_manifest(repo_dir, commit, exts):
    out = git(["ls-tree", "-r", "-z", "--full-tree", commit], repo_dir, binary=True)
    manifest = {}
    for entry in out.split(b"\x00"):
        if not entry:
            continue
        meta, path_b = entry.split(b"\t", 1)
        mode, otype, oid = meta.decode().split(" ")
        if otype != "blob" or mode not in REGULAR_FILE_MODES:
            continue
        path = decode_path(path_b)
        if not exts or ext_of(path) in exts:
            manifest[path] = oid
    return manifest


def read_manifest_file(path):
    m = {}
    try:
        with open(path, encoding="utf-8", errors="surrogateescape") as f:
            for line in f:
                line = line.rstrip("\n")
                if line:
                    oid, p = line.split("\t", 1)
                    m[p] = oid
    except (OSError, ValueError):
        return None
    return m


def write_manifest_file(manifest, path):
    with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
        for p, oid in sorted(manifest.items()):
            f.write(f"{oid}\t{p}\n")


def classify(prev, cur):
    modified = sorted(p for p in cur if p in prev and prev[p] != cur[p])
    new_paths = sorted(p for p in cur if p not in prev)
    gone = sorted(p for p in prev if p not in cur)
    by_blob = {}
    for p, oid in prev.items():
        by_blob.setdefault(oid, []).append(p)
    gone_set, used = set(gone), set()
    added, renamed, copied = [], [], []
    for p in new_paths:
        cands = [q for q in sorted(by_blob.get(cur[p], [])) if ext_of(q) == ext_of(p)]
        src = next((q for q in cands if q in gone_set and q not in used), None)
        if src:
            used.add(src)
            renamed.append((p, src))
        elif cands:
            copied.append((p, cands[0]))
        else:
            added.append(p)
    deleted = [p for p in gone if p not in used]
    return {"added": added, "modified": modified, "deleted": deleted,
            "renamed": renamed, "copied": copied}


def line_churn(repo_dir, a, b, relevant, exts):
    spec = ["--"] + [f"*{e}" for e in exts] if exts else []
    out = git(["diff", "--numstat", "-z", "--no-renames", a, b] + spec, repo_dir, binary=True)
    add = dele = 0
    for rec in out.split(b"\x00"):
        parts = rec.split(b"\t", 2)
        if len(parts) == 3 and decode_path(parts[2]) in relevant and parts[0] != b"-":
            add += int(parts[0])
            dele += int(parts[1])
    return add, dele


# =====================================================
# SNAPSHOTS
# =====================================================
def count_lines(data):
    return data.count(b"\n") + (1 if data and not data.endswith(b"\n") else 0)


def fs_is_case_insensitive(folder):
    """True if 'A' and 'a' are the same file in this folder (Windows NTFS, macOS default)."""
    import tempfile
    os.makedirs(folder, exist_ok=True)
    fd, probe = tempfile.mkstemp(prefix=".CaseProbe_", dir=folder)
    os.close(fd)
    try:
        return os.path.exists(os.path.join(folder, os.path.basename(probe).swapcase()))
    finally:
        os.remove(probe)


WIN_RESERVED = {"con", "prn", "aux", "nul"} | {f"{d}{i}" for d in ("com", "lpt") for i in range(1, 10)}
WIN_BAD_CHARS = re.compile(r'[<>:"|?*\\\x00-\x1f]')


def win_safe_name(name):
    """A file/dir name Windows can create (native Windows Python only)."""
    new = WIN_BAD_CHARS.sub("_", name)
    new = new.rstrip(" .") or "_"
    if new.split(".")[0].lower() in WIN_RESERVED:
        new = "_" + new
    return new


def disk_safe_manifest(manifest, fold_case, windows_names):
    """Map repository paths to paths that can all exist side by side on this disk.

    fold_case     : paths equal ignoring case get distinct names (first sorted keeps
                    its name, the others become <stem>_case2<ext>, _case3 ...);
                    directories equal ignoring case use one spelling (first sorted).
    windows_names : names Windows cannot create are changed (see win_safe_name).
    Returns (manifest with on-disk paths, [(repo path, disk path), ...])."""
    if not fold_case and not windows_names:
        return manifest, []
    key = (lambda x: x.lower()) if fold_case else (lambda x: x)
    dirs = {}                                   # key(dir path) -> spelling used on disk
    taken = set()                               # key(file path) of files already placed
    wanted = set()
    for p in manifest:                          # every repo path (so a rename never takes a real name)
        parts = p.split("/")
        if windows_names:
            parts = [win_safe_name(c) for c in parts]
        wanted.add(key("/".join(parts)))
    out, renames = {}, []
    for p in sorted(manifest):
        parts = p.split("/")
        if windows_names:
            parts = [win_safe_name(c) for c in parts]
        d = ""
        for comp in parts[:-1]:
            nd = f"{d}/{comp}" if d else comp
            d = dirs.setdefault(key(nd), nd)
        name = parts[-1]
        q = f"{d}/{name}" if d else name
        if key(q) in taken or key(q) in dirs:
            e = ext_of(name)
            stem = name[:len(name) - len(e)] if e else name
            k = 2
            while True:
                q = f"{d}/{stem}_case{k}{e}" if d else f"{stem}_case{k}{e}"
                if key(q) not in taken and key(q) not in dirs and key(q) not in wanted:
                    break
                k += 1
        taken.add(key(q))
        out[q] = manifest[p]
        if q != p:
            renames.append((p, q))
    return out, renames


def files_on_disk(rev_dir):
    found = {}
    for root, _, files in os.walk(rev_dir):
        for fn in files:
            full = os.path.join(root, fn)
            found[os.path.relpath(full, rev_dir).replace(os.sep, "/")] = os.path.getsize(full)
    return found


def blob_sizes(repo_dir, oids):
    if not oids:
        return {}
    r = subprocess.run(["git", "-C", repo_dir, "cat-file", "--batch-check"],
                       input=("\n".join(oids) + "\n").encode(), stdout=subprocess.PIPE)
    sizes = {}
    for line in r.stdout.decode().splitlines():
        parts = line.split()
        if len(parts) == 3:
            sizes[parts[0]] = int(parts[2])
    return sizes


def snapshot_is_current(repo_dir, manifest, old_manifest, rev_dir):
    """Existing snapshot has the same manifest and the same files with the right sizes."""
    if old_manifest != manifest or not os.path.isdir(rev_dir):
        return False
    disk = files_on_disk(rev_dir)
    if set(disk) != set(manifest):
        return False
    sizes = blob_sizes(repo_dir, sorted(set(manifest.values())))
    return all(sizes.get(oid) == disk[p] for p, oid in manifest.items())


def write_snapshot(repo_dir, manifest, rev_dir):
    """Write every blob to rev_dir/<path>, verifying blob ids. Returns {path: lines}."""
    force_remove(rev_dir)
    os.makedirs(rev_dir, exist_ok=True)
    items = sorted(manifest.items())
    proc = subprocess.Popen(["git", "-C", repo_dir, "cat-file", "--batch"],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    def feed():
        try:
            for _, oid in items:
                proc.stdin.write(oid.encode() + b"\n")
            proc.stdin.close()
        except BrokenPipeError:
            pass

    writer = threading.Thread(target=feed, daemon=True)
    writer.start()
    lines = {}
    try:
        for path, oid in items:
            header = proc.stdout.readline().split()
            if len(header) != 3 or header[1] != b"blob":
                raise DownloadError(f"cat-file failed for {path} ({oid})")
            size = int(header[2])
            data = proc.stdout.read(size)
            proc.stdout.read(1)
            h = hashlib.sha1(b"blob %d\x00" % size)
            h.update(data)
            if h.hexdigest() != oid:
                raise DownloadError(f"blob id mismatch for {path}")
            dest = os.path.join(rev_dir, *path.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(data)
            lines[path] = count_lines(data)
    finally:
        writer.join()
        proc.stdout.close()
        proc.wait()
    disk = set(files_on_disk(rev_dir))
    if disk != set(manifest):
        missing = sorted(set(manifest) - disk)
        extra = sorted(disk - set(manifest))
        ex = (missing[:3] and f"; not on disk: {', '.join(missing[:3])}" or "") + \
             (extra[:3] and f"; not in manifest: {', '.join(extra[:3])}" or "")
        raise DownloadError(f"{rev_dir}: files on disk differ from manifest "
                            f"({len(missing)} missing, {len(extra)} extra{ex})")
    return lines


def lines_from_disk(rev_dir, manifest):
    out = {}
    for p in manifest:
        with open(os.path.join(rev_dir, *p.split("/")), "rb") as f:
            out[p] = count_lines(f.read())
    return out


def remove_stale_outputs(out_dir, rid):
    """Remove NiCad outputs of r<rid> (r<rid>_functions.xml, .fp, clone result folders ...)."""
    prefix = f"r{rid}_"
    removed = 0
    for name in os.listdir(out_dir):
        if name.startswith(prefix):
            force_remove(os.path.join(out_dir, name))
            removed += 1
    return removed


# =====================================================
# XML / CSV
# =====================================================
def write_xml(path, meta, revisions):
    root = ET.Element("commits", {k: xml_safe(str(v)) for k, v in meta.items()})
    for r in revisions:
        attrs = {"id": str(r["id"]), "hash": r["hash"], "parent": r["parent"],
                 "parents": str(len(r["parents"])),
                 "merge": "true" if len(r["parents"]) > 1 else "false",
                 "type": r["type"], "message": xml_safe(r["message"])}
        if r["type"] == "full":
            attrs["files"] = str(r["files"])
        rev = ET.SubElement(root, "revision", attrs)
        if r["type"] == "full":
            continue
        ch = r["changes"]
        for kind in ("added", "modified", "deleted"):
            if ch[kind]:
                e = ET.SubElement(rev, kind)
                for p in ch[kind]:
                    ET.SubElement(e, "file", path=xml_safe(p))
        if ch["renamed"]:
            e = ET.SubElement(rev, "renamed")
            for p, old in ch["renamed"]:
                ET.SubElement(e, "file", path=xml_safe(p), old_path=xml_safe(old))
        if ch["copied"]:
            e = ET.SubElement(rev, "copied")
            for p, src in ch["copied"]:
                ET.SubElement(e, "file", path=xml_safe(p), source=xml_safe(src))
    pretty = minidom.parseString(ET.tostring(root, encoding="utf-8")).toprettyxml(indent="  ")
    with open(path, "w", encoding="utf-8") as f:
        f.write(pretty)


def write_changes_csv(path, revisions, line_counts):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rev", "hash", "merge", "files", "lines", "added", "modified", "deleted",
                    "renamed", "copied", "changed_files", "lines_in_changed_files",
                    "churn_added", "churn_deleted"])
        for r in revisions:
            lc = line_counts[r["id"]]
            row = [r["id"], r["hash"], len(r["parents"]) > 1, len(lc), sum(lc.values())]
            if r["type"] == "full":
                w.writerow(row + [""] * 9)
                continue
            c = r["changes"]
            changed = c["added"] + c["modified"] + [p for p, _ in c["renamed"]] + [p for p, _ in c["copied"]]
            w.writerow(row + [len(c["added"]), len(c["modified"]), len(c["deleted"]),
                              len(c["renamed"]), len(c["copied"]), len(changed),
                              sum(lc[p] for p in changed), r["churn"][0], r["churn"][1]])


# =====================================================
# API
# =====================================================
def download(repo, start=None, end=None, *, language=None, ext=None, name=None,
             systems_dir=None, ref="HEAD", history="first-parent", workers=8,
             update=False, force=False, info_only=False, interactive=True, clone_path=None,
             case_fold="auto"):
    """
    Create systems/<name>/r<start>..r<end> + commits.xml for NiCad++.

    repo        Git URL or path to a local clone
    start, end  revision numbers (1 = oldest commit of the analyzed history);
                asked interactively if None and interactive=True
    language    NiCad language (java, c, cs, py, php, rb, swift, rust);
                detected from the repository if None
    ext         explicit list of extensions (overrides language), e.g. [".php"]
    name        output name under systems/ (default: owner_repo from the URL)
    ref         branch/tag/commit whose history is analyzed (default HEAD)
    history     "first-parent" (default) or "all"
    update      fetch new commits into an existing clone first
    clone_path  use this existing clone (otherwise an existing clone with the
                same origin URL is searched in systems/.repos, the NiCad root
                and systems/; if none is found, the URL is cloned)
    force       rewrite every snapshot even if it is already up to date
    info_only   only print the number of revisions and the detected language
    case_fold   "auto" (default: test the disk), "on" or "off": give paths that
                differ only in case distinct names on disk (see Windows above)

    Returns a dict with out_dir, repo_dir, language, extensions, start, end,
    total, head, written, kept.
    """
    systems_dir = os.path.abspath(systems_dir or DEFAULT_SYSTEMS_DIR)
    name = name or repo_name_from(repo)
    out_dir = os.path.join(systems_dir, name)
    clone_dir = os.path.join(systems_dir, ".repos", name)
    os.makedirs(systems_dir, exist_ok=True)

    print("=" * 64)
    print("  git_downloader  (NiCad++ revision snapshots)")
    print("=" * 64)
    print(f"Repository : {repo}")
    print(f"Output     : {out_dir}")

    repo_dir = prepare_repository(repo, clone_dir, update=update, systems_dir=systems_dir,
                                  name=name, clone_path=clone_path)
    head = git(["rev-parse", ref], repo_dir).strip()
    hist = list_history(repo_dir, head, history)
    total = len(hist)

    if ext:
        exts = [e if e.startswith(".") else "." + e for e in (x.lower() for x in ext)]
        lang = language or "?"
    else:
        if language:
            lang = LANGUAGE_ALIASES.get(language.lower(), language.lower())
            if lang not in LANGUAGES:
                raise DownloadError(f"unknown language '{language}'; use one of {', '.join(LANGUAGES)} or --ext")
        else:
            lang, summary = detect_language(repo_dir, head)
            print(f"Language   : {lang} (detected; files at HEAD: {summary})")
        exts = LANGUAGES[lang]
    print(f"Extensions : {' '.join(exts)}")
    print(f"History    : {history} of {ref} ({head[:10]}), {total} revisions")

    os.makedirs(out_dir, exist_ok=True)
    full_file = os.path.join(out_dir, "full_commit.txt")
    with open(full_file, "w", encoding="utf-8", errors="replace") as f:
        f.write(f"# ref={ref} head={head} history={history}\n# revision | hash | message\n")
        for i, (h, _, s) in enumerate(hist, start=1):
            f.write(f"{i} | {h} | {s}\n")

    if info_only:
        print(f"[i] Revisions 1..{total}; list in {full_file}")
        return {"out_dir": out_dir, "repo_dir": repo_dir, "language": lang, "extensions": exts,
                "total": total, "head": head}

    if start is None or end is None:
        if not interactive:
            raise DownloadError("start and end revision are required")
        print(f"\n[i] Revisions are numbered 1 (oldest) .. {total} (newest); see {full_file}")
        while True:
            try:
                start = int(input(f"  From revision (1-{total}): ").strip())
                end = int(input(f"  To revision (1-{total}): ").strip())
            except ValueError:
                print("  [x] Please enter numbers")
                continue
            except (KeyboardInterrupt, EOFError):
                raise DownloadError("cancelled")
            if 1 <= start <= end <= total:
                break
            print(f"  [x] Need 1 <= from <= to <= {total}")
    if not (1 <= start <= end <= total):
        raise DownloadError(f"range {start}..{end} is outside 1..{total}")

    selected = [(start + i, *hist[start - 1 + i]) for i in range(end - start + 1)]
    with open(os.path.join(out_dir, "commits.txt"), "w", encoding="utf-8", errors="replace") as f:
        for rid, h, _, s in selected:
            f.write(f"{rid} | {h} | {s}\n")

    t0 = time.time()
    man_dir = os.path.join(out_dir, "manifests")
    os.makedirs(man_dir, exist_ok=True)

    # STEP 1: manifests and change sets
    fold_case = fs_is_case_insensitive(out_dir) if case_fold == "auto" else case_fold == "on"
    windows_names = os.name == "nt"
    print(f"\n[1/3] Manifests and change sets for r{start}..r{end}"
          + ("  (case-insensitive disk: case-only name clashes are renamed)" if fold_case else ""))
    revisions, manifests, repo_paths, current, all_renames = [], {}, {}, {}, []
    bar = Progress(len(selected), "manifests")
    for rid, h, parents, subject in selected:
        m = get_manifest(repo_dir, h, exts)
        repo_paths[rid] = set(m)
        manifests[rid], ren = disk_safe_manifest(m, fold_case, windows_names)
        all_renames += [(rid, a, b) for a, b in ren]
        bar.step(f"r{rid}")
    bar.done()
    ren_file = os.path.join(out_dir, "case_renames.txt")
    if all_renames:
        with open(ren_file, "w", encoding="utf-8", errors="surrogateescape") as f:
            f.write("# revision <TAB> path in the repository <TAB> path written to disk\n")
            for rid, a, b in all_renames:
                f.write(f"r{rid}\t{a}\t{b}\n")
        revs = sorted({r for r, _, _ in all_renames})
        uniq = sorted({(a, b) for _, a, b in all_renames})
        print(f"      [!] {len(uniq)} path(s) clash on this disk (differ only in case / not allowed on "
              f"Windows) in {len(revs)} revision(s); written under a new name, e.g.")
        for a, b in uniq[:4]:
            print(f"          {a}  ->  {b}")
        print(f"          full list: {ren_file}")
    elif os.path.exists(ren_file):
        os.remove(ren_file)
    if is_partial_clone(repo_dir):
        needed = set(oid for m in manifests.values() for oid in m.values())
        prefetch_blobs(repo_dir, [h for _, h, _, _ in selected], needed)
    prev_hash, prev_manifest, prev_repo_paths = "", None, set()
    bar = Progress(len(selected), "changes  ")
    for rid, h, parents, subject in selected:
        m = manifests[rid]
        man_path = os.path.join(man_dir, f"r{rid}.tsv")
        old = read_manifest_file(man_path)
        current[rid] = (not force) and snapshot_is_current(repo_dir, m, old, os.path.join(out_dir, f"r{rid}"))
        write_manifest_file(m, man_path)
        rec = {"id": rid, "hash": h, "parents": parents, "message": subject,
               "parent": prev_hash, "files": len(m)}
        if prev_manifest is None:
            rec.update(type="full", changes=None)
        else:
            rec.update(type="incremental", changes=classify(prev_manifest, m))
            rec["churn"] = line_churn(repo_dir, prev_hash, h, repo_paths[rid] | prev_repo_paths, exts)
        revisions.append(rec)
        prev_hash, prev_manifest, prev_repo_paths = h, m, repo_paths[rid]
        bar.step(f"r{rid}")
    bar.done()

    # STEP 2: snapshots (only those that changed), verified against manifests
    todo = [rid for rid, *_ in selected if not current[rid]]
    kept = len(selected) - len(todo)
    print(f"[2/3] Snapshots: writing {len(todo)}, keeping {kept} up-to-date ({workers} workers)")
    line_counts, failures, stale = {}, [], 0
    for rid in todo:
        stale += remove_stale_outputs(out_dir, rid)
    if stale:
        print(f"      removed {stale} stale NiCad output(s) of rewritten revisions")
    bar = Progress(len(todo), "snapshots")
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(write_snapshot, repo_dir, manifests[rid],
                          os.path.join(out_dir, f"r{rid}")): rid for rid in todo}
        for fut in as_completed(futs):
            rid = futs[fut]
            try:
                line_counts[rid] = fut.result()
            except Exception as e:
                failures.append((rid, str(e)))
            bar.step(f"r{rid}")
    bar.done()
    if failures:
        for rid, e in sorted(failures):
            print(f"  [x] r{rid}: {e}")
        raise DownloadError(f"{len(failures)} snapshot(s) failed; commits.xml not written")
    for rid, *_ in selected:
        if rid not in line_counts:
            line_counts[rid] = lines_from_disk(os.path.join(out_dir, f"r{rid}"), manifests[rid])

    # STEP 3: commits.xml + changes.csv
    print("[3/3] commits.xml and changes.csv")
    meta = {"repository": repo, "ref": ref, "head": head, "history": history,
            "language": lang, "extensions": " ".join(exts), "from": start, "to": end,
            "generator": "git_downloader.py"}
    write_xml(os.path.join(out_dir, "commits.xml"), meta, revisions)
    write_changes_csv(os.path.join(out_dir, "changes.csv"), revisions, line_counts)

    inc = [r for r in revisions if r["type"] == "incremental"]
    tot = {k: sum(len(r["changes"][k]) for r in inc) for k in ("added", "modified", "deleted", "renamed", "copied")}
    rel = os.path.relpath(out_dir, os.path.dirname(systems_dir)).replace(os.sep, "/")
    print("=" * 64)
    print(f"[ok] r{start}..r{end}: {len(selected)} revisions "
          f"({sum(1 for r in revisions if len(r['parents']) > 1)} merges) in {time.time() - t0:.1f}s")
    print("     changes: " + ", ".join(f"{k} {v}" for k, v in tot.items()))
    print(f"     output : {out_dir}")
    print("\n  Next:")
    print(f"    ./scripts/NiCadInc functions {lang if lang != '?' else '<language>'} {rel} <config> {start} {end}")
    print("=" * 64)
    return {"out_dir": out_dir, "repo_dir": repo_dir, "language": lang, "extensions": exts,
            "start": start, "end": end, "total": total, "head": head,
            "written": len(todo), "kept": kept}


# =====================================================
# CLI
# =====================================================
def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="git_downloader",
        description="Git repository -> systems/<name>/r<N> snapshots + commits.xml for NiCad++",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage="git_downloader <repo> [name] <from> <to> [options]",
        epilog="Examples:\n"
               "  ./scripts/git_downloader https://github.com/laravel/framework.git laravel_framework 1 200\n"
               "  ./scripts/git_downloader https://github.com/laravel/framework.git 1 200\n"
               "  ./scripts/git_downloader https://github.com/laravel/framework.git --info\n"
               "  ./scripts/git_downloader https://github.com/apache/cassandra.git 1 300 --lang java\n")
    ap.add_argument("repo", help="Git URL or path to a local clone")
    ap.add_argument("args", nargs="*", metavar="[name] from to",
                    help="optional folder name under systems/, then first and last revision")
    ap.add_argument("--lang", help="NiCad language: " + ", ".join(LANGUAGES) + " (default: detect)")
    ap.add_argument("--ext", nargs="+", help="explicit extensions, e.g. --ext .php (overrides --lang)")
    ap.add_argument("--name", help="output folder name under systems/ (default: owner_repo)")
    ap.add_argument("--systems", help=f"systems folder (default: {DEFAULT_SYSTEMS_DIR})")
    ap.add_argument("--ref", default="HEAD", help="branch/tag/commit to analyze (default HEAD)")
    ap.add_argument("--history", choices=["first-parent", "all"], default="first-parent")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--clone", dest="clone_path", help="use this existing clone of the repository")
    ap.add_argument("--update", action="store_true", help="fetch new commits into an existing clone")
    ap.add_argument("--force", action="store_true", help="rewrite all snapshots")
    ap.add_argument("--info", action="store_true", help="only show number of revisions and language")
    ap.add_argument("--case-fold", choices=["auto", "on", "off"], default="auto",
                    help="rename paths that differ only in case (auto: if the disk is case-insensitive)")
    a = ap.parse_args(argv)
    # positional forms:  repo | repo name | repo from to | repo name from to
    pos, name, start, end = list(a.args), a.name, None, None
    if pos and not pos[0].lstrip("-").isdigit():
        if name and name != pos[0]:
            ap.error("folder name given twice")
        name = pos.pop(0)
    if len(pos) == 2 and all(p.isdigit() for p in pos):
        start, end = int(pos[0]), int(pos[1])
    elif pos:
        ap.error("expected: <repo> [name] <from> <to>")
    try:
        download(a.repo, start, end, language=a.lang, ext=a.ext, name=name,
                 systems_dir=a.systems, ref=a.ref, history=a.history, workers=a.workers,
                 update=a.update, force=a.force, info_only=a.info, clone_path=a.clone_path,
                 case_fold=a.case_fold)
    except DownloadError as e:
        sys.exit(f"[x] {e}")
    except KeyboardInterrupt:
        sys.exit("\n[x] Interrupted")


if __name__ == "__main__":
    main()
